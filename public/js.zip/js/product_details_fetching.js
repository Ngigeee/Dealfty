//hold the images and emojis
let images = [];
let currentIdx = 0;
let fallbackEmoji = "📦";

//fetch the images
async function initGallery() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  if (!id) {
    console.error("Missing ID");
    return;
  }

  try {
    const res = await fetch(`/listing/images?id=${id}`);
    const data = await res.json();

    images = data.images || [];
    fallbackEmoji = data.emoji || "📦";

    renderGallery();
  } catch (err) {
    console.error("Error loading gallery:", err);
  }
}

initGallery();
//render th images in gallery
function renderGallery() {
  const container = document.getElementById("gallery-container");

  // ✅ No images → use category emoji from backend
  if (!images.length) {
    container.innerHTML = `
      <div class="img-box">${fallbackEmoji}</div>
    `;
    return;
  }

  const imgCount = images.length;

  container.innerHTML = `
    <div class="gallery-wrap">

      <div class="gallery-main" onclick="openLightbox(currentIdx)">
        <img src="${images[0]}" id="main-img"/>

        <div class="zoom-hint">🔍 Tap to zoom</div>

        ${imgCount > 1 ? `
          <div class="photo-pill">📷 <span id="photo-num">1</span>/${imgCount}</div>

          <div class="gallery-dots">
            ${images.slice(0, 7).map((_, i) => `
              <div class="gdot ${i === 0 ? "active" : ""}"
                   onclick="event.stopPropagation(); goToImg(${i})"></div>
            `).join("")}
          </div>
        ` : ""}
      </div>

      ${imgCount > 1 ? `
        <div class="gallery-thumbs">
          ${images.map((img, i) => `
            <div class="thumb ${i === 0 ? "active" : ""}"
                 onclick="goToImg(${i})">
              <img src="${img}" />
            </div>
          `).join("")}
        </div>
      ` : ""}

    </div>
  `;
}

//switch between images
function goToImg(index) {
  currentIdx = index;

  const mainImg = document.getElementById("main-img");
  if (mainImg) mainImg.src = images[index];

  const counter = document.getElementById("photo-num");
  if (counter) counter.textContent = index + 1;

  document.querySelectorAll(".gdot").forEach((dot, i) => {
    dot.classList.toggle("active", i === index);
  });

  document.querySelectorAll(".thumb").forEach((thumb, i) => {
    thumb.classList.toggle("active", i === index);
  });
}

//light box
function openLightbox(index) {
  console.log("Open lightbox at:", index);
}




//other data data
function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function timeAgo(dateStr) {
  const ts = new Date(dateStr).getTime();
  if (Number.isNaN(ts)) return "Unknown time";

  let diff = Math.floor((Date.now() - ts) / 1000);

  if (diff < 0) {
    diff = Math.abs(diff);
    if (diff < 60) return `in ${diff} sec`;
    if (diff < 3600) return `in ${Math.floor(diff / 60)} min`;
    if (diff < 86400) return `in ${Math.floor(diff / 3600)} hr`;
    return `in ${Math.floor(diff / 86400)} day`;
  }

  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)} min ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} hr ago`;
  if (diff < 604800) return `${Math.floor(diff / 86400)} day ago`;

  return new Date(ts).toLocaleDateString();
}

function getStockText(stock) {
  const stk = Number(stock ?? 1);
  if (stk <= 0) return "";
  return stk === 1 ? "1 available" : `${stk} in stock`;
}

async function renderListingData() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  if (!id) {
    console.error("Missing ID");
    return;
  }

  try {
    const res = await fetch(`/listing/details?id=${encodeURIComponent(id)}`);
    const data = await res.json();

    if (!res.ok) {
      console.error(data?.error || "Failed to load listing");
      return;
    }

    const listing = data.listing || {};
    const emoji = data.emoji || "📦";
    const attributes = data.attributes && typeof data.attributes === "object" ? data.attributes : {};

    const container = document.getElementById("infor_cont");
    if (!container) return;

    const category = listing.category || "General";
    const condition = listing.condition || "";
    const status = listing.status || "inactive";
    const price = Number(listing.price || 0);
    const stockText = getStockText(listing.stock);
    const negotiable = !!listing.negotiable;

    const condCssMap = {
      New: "background:#dcfce7;color:#15803d",
      "Like New": "background:#dbeafe;color:#1d4ed8",
      Good: "background:#fef9c3;color:#a16207",
      Fair: "background:#fee2e2;color:#b91c1c",
      Used: "background:#f3f4f6;color:#374151"
    };
    const condCss = condCssMap[condition] || "background:#f3f4f6;color:#374151";

    const phone = String(listing.contact_phone ?? "").replace(/[^0-9+]/g, "");
    const isOwner = !!data.isOwner;      // not returned by your route unless you add it
    const saved = !!data.saved;          // not returned by your route unless you add it
    const sellerRating = data.sellerRating || null; // not returned by your route unless you add it

    const attrsHtml = Object.entries(attributes)
      .map(([key, val]) => `
        <div style="display:flex;align-items:flex-start;gap:10px">
          <div style="font-weight:700;color:var(--text);min-width:110px;text-align:right">${escapeHtml(key)}:</div>
          <div style="color:var(--text-2)">${escapeHtml(val)}</div>
        </div>
      `)
      .join("");

    container.innerHTML = `
      <div class="content-wrap">

        <div class="tags-row">
          <span class="tag tag-cat">${escapeHtml(emoji)} ${escapeHtml(category)}</span>
          ${condition ? `<span class="cond-badge" style="${condCss}">${escapeHtml(condition)}</span>` : ""}
          <span class="tag ${status === "active" ? "tag-active" : "tag-inactive"}">
            ${status === "active" ? "⚫ Active" : "⚫ Inactive"}
          </span>
        </div>

        <h1 class="listing-title">${escapeHtml(listing.title)}</h1>

        <div class="price-row">
          <div class="price-main">KSh ${price.toLocaleString("en-KE")}</div>
          ${negotiable ? `<span class="price-neg">🤝 Negotiable</span>` : ""}
        </div>

        <div class="info-chips">
          ${listing.location ? `
            <div class="chip"><span class="chip-icon">📍</span>${escapeHtml(listing.location)}</div>
          ` : ""}

          <div class="chip"><span class="chip-icon">🕒</span>${escapeHtml(timeAgo(listing.created_at))}</div>

          ${stockText ? `
            <div class="chip"><span class="chip-icon">📦</span><strong>${escapeHtml(stockText)}</strong></div>
          ` : ""}

          ${listing.sku ? `
            <div class="chip"><span class="chip-icon">🏷️</span>SKU: ${escapeHtml(listing.sku)}</div>
          ` : ""}

          ${listing.contact_phone && !isOwner ? `
            <div class="chip" style="background:var(--green-light);border-color:var(--green);color:var(--green-dark);cursor:pointer"
                 onclick="openSafetyModal('tel:${phone}','tel')"
                 title="Click Call Now to reveal and dial">
              <span class="chip-icon">📞</span>
              <strong>Phone Available</strong>
              <span style="font-size:11px;color:var(--green);margin-left:2px">· Tap Call Now</span>
            </div>
          ` : ""}
        </div>

        <div class="desc-label">📋 Description</div>
        <div class="desc-text">${escapeHtml(listing.description)}</div>

        ${Object.keys(attributes).length ? `
          <div style="margin:24px 0 16px">
            <div class="desc-label">Additional Details</div>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px 16px;">
              ${attrsHtml}
            </div>
          </div>
        ` : ""}

        ${!isOwner ? `
          <div style="text-align:right;margin:12px 0 20px">
            <a href="report.php?listing=${encodeURIComponent(listing.id)}"
               style="font-size:12px;color:var(--red);display:inline-flex;align-items:center;gap:5px;background:#FEE2E2;border:1.5px solid #fca5a5;padding:5px 13px;border-radius:20px;font-weight:600;transition:all .15s"
               onmouseover="this.style.background='var(--red)';this.style.color='#fff';this.style.borderColor='var(--red)'"
               onmouseout="this.style.background='#FEE2E2';this.style.color='var(--red)';this.style.borderColor='#fca5a5'">
              ⛳ Report Listing
            </a>
          </div>
        ` : ""}

        <div class="seller-section">
          <div class="seller-label">Sold by</div>
          <a class="seller-inner"
             href="chat.php?user=${encodeURIComponent(listing.seller_id)}&listing=${encodeURIComponent(listing.id)}"
             style="display:flex;align-items:center;gap:14px;background:var(--white);border:1px solid var(--border);border-radius:var(--radius);padding:16px;box-shadow:var(--shadow);transition:box-shadow .15s">
            <div class="seller-av ${listing.seller_type === 'business' ? 'biz' : ''}">
              ${(listing.seller_name || "U").charAt(0).toUpperCase()}
            </div>

            <div style="flex:1;min-width:0">
              <div class="seller-name">${escapeHtml(listing.seller_name || "Unknown seller")}</div>
              <span class="seller-type-pill">${listing.seller_type === "business" ? "🏢 Business" : "👤 Individual"}</span>

              ${sellerRating && sellerRating.count > 0 ? `
                <div class="seller-rating-inline">
                  <div class="seller-rating-stars">⭐ ${escapeHtml(sellerRating.avg)}</div>
                  <span class="seller-rating-val">${escapeHtml(sellerRating.avg)}</span>
                  <span class="seller-rating-cnt">(${sellerRating.count} review${sellerRating.count !== 1 ? "s" : ""})</span>
                </div>
              ` : `
                <div style="font-size:11px;color:var(--gray);margin-top:3px">No reviews yet</div>
              `}
            </div>

            <div class="seller-arrow">›</div>
          </a>
        </div>

        <div class="desktop-action-card">
          ${!isOwner ? `
            <div style="font-family:Nunito,sans-serif;font-weight:900;font-size:30px;color:var(--green-dark);margin-bottom:16px">
              KSh ${price.toLocaleString("en-KE")}
            </div>

            <button
               onclick="handleProtectedAction(event,'chat',${encodeURIComponent(listing.seller_id)},${encodeURIComponent(listing.id)})" 
               style="width:100%;border:none;display:flex;align-items:center;justify-content:center;gap:8px;background:var(--green);color:#fff;border-radius:50px;padding:14px;font-family:Nunito,sans-serif;font-weight:800;font-size:15px;margin-bottom:10px;box-shadow:0 4px 16px rgba(46,158,62,.3)">
              💬 Message Seller
            </button>

            ${listing.contact_phone ? `
              <a href="tel:${phone}"
                 onclick="event.preventDefault();openSafetyModal(this.href,'tel')"
                 style="display:flex;align-items:center;justify-content:center;gap:8px;background:linear-gradient(135deg,#16a34a,#15803d);color:#fff;border-radius:50px;padding:14px;font-family:Nunito,sans-serif;font-weight:800;font-size:15px;margin-bottom:10px;box-shadow:0 4px 16px rgba(22,163,74,.35);text-decoration:none">
                📞 Call Now
              </a>
            ` : `
              <button 
                 onclick="handleProtectedAction(event,'buy',${encodeURIComponent(listing.seller_id)},${encodeURIComponent(listing.id)})" 
                 style="width:100%;border:none;display:flex;align-items:center;justify-content:center;gap:8px;background:var(--yellow);color:#fff;border-radius:50px;padding:14px;font-family:Nunito,sans-serif;font-weight:800;font-size:15px;margin-bottom:10px;box-shadow:0 4px 16px rgba(245,166,35,.3)">
                🛒 Buy Now
              </button>
            `}

            
              
              <button  onclick="handleProtectedAction(event,'save',${encodeURIComponent(listing.seller_id)},${encodeURIComponent(listing.id)})" 
                      style="display:flex;align-items:center;justify-content:center;gap:8px;width:100%;background:var(--white);border:2px solid ${saved ? "var(--yellow)" : "var(--border)"};border-radius:50px;padding:13px;font-family:Nunito,sans-serif;font-weight:700;font-size:14px;cursor:pointer;color:${saved ? "var(--yellow-dark)" : "var(--text-2)"}">
                🔖 ${saved ? "Saved — Click to Unsave" : "Save Item"}
              </button>
            
          ` : `
            <a href="edit_listing.php?id=${encodeURIComponent(listing.id)}"
               style="display:flex;align-items:center;justify-content:center;gap:8px;background:var(--blue);color:#fff;border-radius:50px;padding:14px;font-family:Nunito,sans-serif;font-weight:800;font-size:15px;margin-bottom:10px">
              ✎ Edit Listing
            </a>

            <a href="delete_listing.php?id=${encodeURIComponent(listing.id)}"
               onclick="return confirm('Delete this listing? This cannot be undone.')"
               style="display:flex;align-items:center;justify-content:center;gap:8px;background:#fff;color:var(--red);border:2px solid var(--red);border-radius:50px;padding:13px;font-family:Nunito,sans-serif;font-weight:800;font-size:15px">
              🗑 Delete Listing
            </a>
          `}
        </div>

      </div>
    `;
  } catch (err) {
    console.error("Error loading listing data:", err);
  }
}

renderListingData();

//handle reviews



async function renderReviewsData() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  if (!id) {
    console.error("Missing ID");
    return;
  }

  try {
    const res = await fetch(`/seller/reviews?id=${encodeURIComponent(id)}`);
    const data = await res.json();

    if (!res.ok) {
      console.error(data?.error || "Failed to load listing");
      return;
    }

    const listing = data.listing || {};
    

    container.innerHTML = `
      <div class="reviews-head-row">
        <span class="reviews-title">&#11088; Seller Reviews</span>
        <?php if ($seller_rating['count'] > 0): ?>
        <span class="reviews-count-pill"><?= $seller_rating['count'] ?> review<?= $seller_rating['count']!==1?'s':'' ?></span>
        <?php endif; ?>
    </div>

    <?php if ($seller_rating['count'] > 0): ?>
    <!-- Aggregate summary -->
    <div class="rev-summary">
        <div class="rev-big-score"><?= $seller_rating['avg'] ?></div>
        <div class="rev-summary-right">
            <div class="rev-stars-row"><?= render_stars($seller_rating['avg'], 18) ?></div>
            <div class="rev-total-lbl"><?= $seller_rating['count'] ?> review<?= $seller_rating['count']!==1?'s':'' ?></div>
            <div style="margin-top:8px">
            <?php for ($si=5;$si>=1;$si--):
                $cnt  = $seller_rating['dist'][$si];
                $pct  = $seller_rating['count'] > 0 ? round($cnt / $seller_rating['count'] * 100) : 0;
            ?>
            <div class="rev-bar-row">
                <span class="rev-bar-lbl"><?=$si?></span>
                <div class="rev-bar-track"><div class="rev-bar-fill" style="width:<?=$pct?>%"></div></div>
                <span class="rev-bar-cnt"><?=$cnt?></span>
            </div>
            <?php endfor; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    

    <?php if (!$is_owner): ?>
    <!-- Write / edit review form -->
    <div class="rev-form-card">
        <div class="rev-form-title"><?= $my_review ? '&#9998; Edit Your Review' : '&#128396; Write a Review for this Seller' ?></div>
        <?php if ($review_success): ?>
        <div class="rev-alert success">&#9989; <?= htmlspecialchars($review_success) ?></div>
        <?php endif; ?>
        <?php if ($review_error): ?>
        <div class="rev-alert error">&#9888; <?= htmlspecialchars($review_error) ?></div>
        <?php endif; ?>
        <form method="POST" action="#reviews">
            <input type="hidden" name="submit_review" value="1"/>
            <div style="font-size:12px;font-weight:700;color:var(--text-2);margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px">Your Rating</div>
            <div class="star-picker" id="star-picker">
                <?php for ($si=1;$si<=5;$si++): $sel = ($my_review['rating'] ?? 0) >= $si; ?>
                <button type="button" class="star-btn" data-val="<?=$si?>" onclick="pickStar(<?=$si?>)" title="<?=$si?> star<?=$si>1?'s':''?>">
                    <svg width="32" height="32" viewBox="0 0 24 24" id="star-svg-<?=$si?>">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
                              fill="<?=$sel?'#F5A623':'#E2E6EE'?>"
                              stroke="<?=$sel?'#F5A623':'#D0D4DC'?>" stroke-width="1"/>
                    </svg>
                </button>
                <?php endfor; ?>
            </div>
            <input type="hidden" name="r_stars" id="r_stars" value="<?= (int)($my_review['rating'] ?? 0) ?>"/>
            <textarea name="r_text" class="rev-textarea" placeholder="Share your experience with this seller — was the product as described? How was communication? Would you buy again?" maxlength="600"><?= htmlspecialchars($my_review['review'] ?? '') ?></textarea>
            <div style="font-size:11px;color:var(--gray);margin-top:4px;text-align:right"><span id="rev-char-count"><?= strlen($my_review['review'] ?? '') ?></span>/600</div>
            <button type="submit" class="rev-submit-btn">&#9733; <?= $my_review ? 'Update Review' : 'Submit Review' ?></button>
        </form>
    </div>
    <?php endif; ?>

    <!-- Reviews list -->
    <?php if (empty($reviews)): ?>
    <div class="rev-no-reviews">
        <div style="font-size:40px;margin-bottom:8px">&#128220;</div>
        <div style="font-weight:700;margin-bottom:4px">No reviews yet</div>
        <div>Be the first to review this seller!</div>
    </div>
    <?php else: ?>
    <div class="rev-list">
        <?php foreach ($reviews as $rev):
            $initials = strtoupper(substr($rev['reviewer_name'] ?? 'U', 0, 1));
        ?>
        <div class="rev-card">
            <div class="rev-card-top">
                <div class="rev-av"><?= $initials ?></div>
                <div class="rev-meta">
                    <div class="rev-reviewer-name"><?= htmlspecialchars($rev['reviewer_name']) ?></div>
                    <div class="rev-date"><?= date('M j, Y', strtotime($rev['created_at'])) ?></div>
                </div>
                <div class="rev-inline-stars"><?= render_stars((float)$rev['rating'], 14) ?></div>
            </div>
            <?php if (!empty(trim($rev['review']))): ?>
            <div class="rev-text"><?= nl2br(htmlspecialchars($rev['review'])) ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    `;
  } catch (err) {
    console.error("Error loading listing data:", err);
  }
}

//handle reviews

//render stars
function renderStars(rating, size = 16) {
  let html = "";

  for (let i = 1; i <= 5; i++) {
    const active = Number(rating) >= i;

    html += `
      <svg width="${size}" height="${size}" viewBox="0 0 24 24" aria-hidden="true">
        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
              fill="${active ? "#F5A623" : "#E2E6EE"}"
              stroke="${active ? "#F5A623" : "#D0D4DC"}"
              stroke-width="1"/>
      </svg>
    `;
  }

  return html;
}
//pick star
function pickStar(value) {
  selectedStars = value;

  const hidden = document.getElementById("r_stars");
  if (hidden) hidden.value = value;

  for (let i = 1; i <= 5; i++) {
    const svg = document.getElementById(`star-svg-${i}`);
    if (!svg) continue;

    const path = svg.querySelector("path");
    if (!path) continue;

    const active = i <= value;
    path.setAttribute("fill", active ? "#F5A623" : "#E2E6EE");
    path.setAttribute("stroke", active ? "#F5A623" : "#D0D4DC");
  }
}
//calculate review stats
function calculateReviewStats(reviews) {
  const stats = { avg: 0, count: 0, dist: { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 } };

  if (!Array.isArray(reviews) || !reviews.length) return stats;

  let total = 0;

  for (const review of reviews) {
    const rating = Number(review.rating || 0);
    if (stats.dist[rating] !== undefined) stats.dist[rating]++;
    total += rating;
  }

  stats.count = reviews.length;
  stats.avg = Math.round((total / reviews.length) * 10) / 10;

  return stats;
}
//render reviews data
async function renderReviewsData() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  if (!id) {
    console.error("Missing ID");
    return;
  }

  try {
    const listingRes = await fetch(`/listing/details?id=${encodeURIComponent(id)}`);
    const listingData = await listingRes.json();

    if (!listingRes.ok) {
      console.error(listingData?.error || "Failed to load listing");
      return;
    }

    const listing = listingData.listing || {};
    const sellerId = listing.seller_id;
    const listingId = listing.id;
    const isOwner = !!listingData.isOwner;

    const [reviewsRes, mineRes] = await Promise.all([
      fetch(`/seller/reviews?id=${encodeURIComponent(sellerId)}`),
      fetch(`/reviews/mine?seller_id=${encodeURIComponent(sellerId)}&listing_id=${encodeURIComponent(listingId)}`)
    ]);

    const reviewsData = await reviewsRes.json();
    const mineData = await mineRes.json();

    if (!reviewsRes.ok) {
      console.error(reviewsData?.error || "Failed to load reviews");
      return;
    }

    const reviews = Array.isArray(reviewsData) ? reviewsData : [];
    const myReview = mineData?.review || null;
    const stats = calculateReviewStats(reviews);

    const container = document.getElementById("reviews_cont");
    if (!container) return;

    const summaryHtml = stats.count > 0 ? `
      <div class="rev-summary">
        <div class="rev-big-score">${stats.avg}</div>
        <div class="rev-summary-right">
          <div class="rev-stars-row">${renderStars(stats.avg, 18)}</div>
          <div class="rev-total-lbl">${stats.count} review${stats.count !== 1 ? "s" : ""}</div>
          <div style="margin-top:8px">
            ${[5, 4, 3, 2, 1].map(si => {
              const cnt = stats.dist[si];
              const pct = stats.count > 0 ? Math.round((cnt / stats.count) * 100) : 0;
              return `
                <div class="rev-bar-row">
                  <span class="rev-bar-lbl">${si}</span>
                  <div class="rev-bar-track"><div class="rev-bar-fill" style="width:${pct}%"></div></div>
                  <span class="rev-bar-cnt">${cnt}</span>
                </div>
              `;
            }).join("")}
          </div>
        </div>
      </div>
    ` : "";

    const formHtml = !isOwner ? `
      <div class="rev-form-card">
        <div class="rev-form-title">${myReview ? "✎ Edit Your Review" : "📝 Write a Review for this Seller"}</div>
        <div id="review-msg"></div>

        <form id="review-form">
          <input type="hidden" name="seller_id" value="${escapeHtml(sellerId)}">
          <input type="hidden" name="listing_id" value="${escapeHtml(listingId)}">
          <input type="hidden" name="r_stars" id="r_stars" value="${myReview?.rating || 0}">

          <div style="font-size:12px;font-weight:700;color:var(--text-2);margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px">
            Your Rating
          </div>

          <div class="star-picker" id="star-picker">
            ${[1, 2, 3, 4, 5].map(si => {
              const sel = (myReview?.rating || 0) >= si;
              return `
                <button type="button" class="star-btn" data-val="${si}" onclick="pickStar(${si})" title="${si} star${si > 1 ? "s" : ""}">
                  <svg width="32" height="32" viewBox="0 0 24 24" id="star-svg-${si}">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
                          fill="${sel ? "#F5A623" : "#E2E6EE"}"
                          stroke="${sel ? "#F5A623" : "#D0D4DC"}"
                          stroke-width="1"/>
                  </svg>
                </button>
              `;
            }).join("")}
          </div>

          <textarea name="review" class="rev-textarea" placeholder="Share your experience with this seller..." maxlength="600">${escapeHtml(myReview?.review || "")}</textarea>

          <div style="font-size:11px;color:var(--gray);margin-top:4px;text-align:right">
            <span id="rev-char-count">${String(myReview?.review || "").length}</span>/600
          </div>

          <button type="submit" class="rev-submit-btn">
            ★ ${myReview ? "Update Review" : "Submit Review"}
          </button>
        </form>
      </div>
    ` : "";

    const listHtml = reviews.length === 0 ? `
      <div class="rev-no-reviews">
        <div style="font-size:40px;margin-bottom:8px">📄</div>
        <div style="font-weight:700;margin-bottom:4px">No reviews yet</div>
        <div>Be the first to review this seller!</div>
      </div>
    ` : `
      <div class="rev-list">
        ${reviews.map(rev => `
          <div class="rev-card">
            <div class="rev-card-top">
              <div class="rev-av">${escapeHtml((rev.reviewer_name || "U").charAt(0).toUpperCase())}</div>
              <div class="rev-meta">
                <div class="rev-reviewer-name">${escapeHtml(rev.reviewer_name || "Unknown")}</div>
                <div class="rev-date">${rev.created_at ? new Date(rev.created_at).toLocaleDateString("en-KE") : ""}</div>
              </div>
              <div class="rev-inline-stars">${renderStars(Number(rev.rating || 0), 14)}</div>
            </div>
            ${String(rev.review || "").trim() ? `<div class="rev-text">${escapeHtml(rev.review).replace(/\n/g, "<br>")}</div>` : ""}
          </div>
        `).join("")}
      </div>
    `;

    container.innerHTML = `
      <div class="reviews-head-row">
        <span class="reviews-title">⭐ Seller Reviews</span>
        ${stats.count > 0 ? `<span class="reviews-count-pill">${stats.count} review${stats.count !== 1 ? "s" : ""}</span>` : ""}
      </div>

      ${summaryHtml}
      ${formHtml}
      ${listHtml}
    `;

    const form = document.getElementById("review-form");
    if (form) form.addEventListener("submit", submitReview);

    const textarea = document.querySelector(".rev-textarea");
    if (textarea) {
      textarea.addEventListener("input", () => {
        const counter = document.getElementById("rev-char-count");
        if (counter) counter.textContent = String(textarea.value.length);
      });
    }

    if (selectedStars > 0) pickStar(selectedStars);
  } catch (err) {
    console.error("Error loading reviews data:", err);
  }
}

//submit review
async function submitReview(event) {
  event.preventDefault();

  const form = event.currentTarget;
  const msgBox = document.getElementById("review-msg");

  const seller_id = Number(form.seller_id.value);
  const listing_id = Number(form.listing_id.value);
  const rating = Number(form.r_stars.value);
  const review = String(form.review.value || "").trim();

  if (!rating || rating < 1 || rating > 5) {
    if (msgBox) msgBox.innerHTML = `<div class="rev-alert error">⚠️ Please select a star rating.</div>`;
    return;
  }

  try {
    const res = await fetch("/reviews", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        seller_id,
        listing_id,
        rating,
        review
      })
    });

    const data = await res.json();

    if (!res.ok) {
      if (msgBox) msgBox.innerHTML = `<div class="rev-alert error">⚠️ ${escapeHtml(data?.error || "Failed to save review")}</div>`;
      return;
    }

    if (msgBox) msgBox.innerHTML = `<div class="rev-alert success">✅ Review saved</div>`;
    await renderReviewsData();
  } catch (err) {
    if (msgBox) msgBox.innerHTML = `<div class="rev-alert error">⚠️ Network error</div>`;
    console.error("Review submit error:", err);
  }
}

//calling the functio to handle reviews
renderReviewsData();


//related listings
async function renderRelatedData() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  if (!id) {
    console.error("Missing ID");
    return;
  }

  try {
    const res = await fetch(`/listing/related?id=${encodeURIComponent(id)}`);
    const related = await res.json();

    if (!res.ok) {
      console.error(related?.error || "Failed to load related listings");
      return;
    }

    const container = document.getElementById("related_cont");
    if (!container) return;

    if (!Array.isArray(related) || related.length === 0) {
      container.innerHTML = "";
      return;
    }

    container.innerHTML = `
      <div class="related-outer">
        <div class="related-title">🔗 You may also like</div>
        <div class="related-grid">
          ${related.map(rel => `
            <a class="related-card" href="listing_detail.php?id=${encodeURIComponent(rel.id)}">
              <div class="related-img">
                ${rel.first_image
                  ? `<img src="${escapeHtml(rel.first_image)}" alt="" loading="lazy"/>`
                  : `${escapeHtml(rel.emoji || "📦")}`
                }
              </div>
              <div class="related-body">
                <div class="related-name">${escapeHtml(rel.title)}</div>
                <div class="related-price">KSh ${Number(rel.price || 0).toLocaleString("en-KE")}</div>
                <div class="related-cat">${escapeHtml(rel.category || "")}</div>
              </div>
            </a>
          `).join("")}
        </div>
      </div>
    `;
  } catch (err) {
    console.error("Error loading related listings:", err);
  }
}
//calling the function
renderRelatedData();

//interested listings
async function renderInterestedData() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  if (!id) {
    console.error("Missing ID");
    return;
  }

  try {
    const res = await fetch(`/listing/interested?id=${encodeURIComponent(id)}`);
    const interested = await res.json();

    if (!res.ok) {
      console.error(interested?.error || "Failed to load interested listings");
      return;
    }

    const container = document.getElementById("interested_cont");
    if (!container) return;

    if (!Array.isArray(interested) || interested.length === 0) {
      container.innerHTML = "";
      return;
    }

    container.innerHTML = `
      <div class="interested-outer">
        <div class="interested-header">
          <div class="interested-title">
            <span class="interested-title-icon">✨</span>
            You might be interested in
          </div>
          <a class="interested-see-all" href="marketplace.php">See all &rsaquo;</a>
        </div>
        <div class="int-list">
          ${interested.map(int => `
            <a class="int-row" href="listing_detail.php?id=${encodeURIComponent(int.id)}">
              <div class="int-thumb">
                ${int.first_image
                  ? `<img src="${escapeHtml(int.first_image)}" alt="" loading="lazy"/>`
                  : `${escapeHtml(int.emoji || "📦")}`
                }
              </div>
              <div class="int-info">
                <div class="int-tag-row">
                  <span class="int-tag int-tag-cat">${escapeHtml(int.emoji || "📦")} ${escapeHtml(int.category || "")}</span>
                  ${Number(int.same_seller) === 1 ? `<span class="int-tag int-tag-seller">👤 Same seller</span>` : ""}
                </div>
                <div class="int-name">${escapeHtml(int.title)}</div>
                <div class="int-bottom-row">
                  <div class="int-price">KSh ${Number(int.price || 0).toLocaleString("en-KE")}</div>
                  <div class="int-seller-name">${escapeHtml(int.seller_name || "")}</div>
                </div>
              </div>
              <div class="int-arrow">›</div>
            </a>
          `).join("")}
        </div>
      </div>
    `;
  } catch (err) {
    console.error("Error loading interested listings:", err);
  }
}

//calling the function
renderInterestedData();


//display overlay


function showOverlay() {
  document.getElementById('authOverlay').classList.remove('hidden');
}

function closeOverlay() {
  document.getElementById('authOverlay').classList.add('hidden');
}

function handleProtectedAction(e, action, seller_id, listing_id) {
  if (!isLoggedIn) {
    e.preventDefault();
    showOverlay();
    return;
  }

  let url = "";

  if (action === "chat") {
    url = `/chat?user=${encodeURIComponent(seller_id)}&listing=${encodeURIComponent(listing_id)}`;
  }

  else if (action === "buy") {
    url = `/checkout?listing=${encodeURIComponent(listing_id)}`;
  }

  else if (action === "save") {
    url = `/save?listing=${encodeURIComponent(listing_id)}`;
  }

  if (url) {
    window.location.href = url;
  }
}
