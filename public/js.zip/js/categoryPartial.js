async function loadCategories(config = {}) {
    const {
        containerId = 'cat-grid',
        selectedCat = '',
        searchQuery = ''
    } = config;

    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = 'Loading...';

    try {
        const res = await fetch('/services/categories');
        if (!res.ok) throw new Error('Failed to fetch categories');

        const { categories } = await res.json();
        container.innerHTML = '';

        if (!categories.length) {
            container.innerHTML = '<p>No categories found</p>';
            return;
        }

        const iconMap = {
            home: "wrench",
            skilled: "hard-hat",
            transport: "truck",
            tech: "cpu",
            beauty: "heart",
            tutoring: "graduation-cap",
            business: "briefcase",
            "": "grid"
        };

        categories.forEach(cat => {
            const selected = (selectedCat === cat.key && cat.key) ? 'selected' : '';
            const iconName = iconMap[cat.key] || 'circle';

            let link = `/services?cat=${encodeURIComponent(cat.key)}`;
            if (searchQuery) {
                link += `&q=${encodeURIComponent(searchQuery)}`;
            }

            const card = document.createElement('a');
            card.href = link;
            card.className = `cat-item ${cat.color} ${selected}`;

            card.innerHTML = `
                <span class="cat-icon">
                    <i data-lucide="${iconName}" color="grey"></i>
                </span>
                <span class="cat-label" style="color:grey;">${cat.label}</span>
            `;

            container.appendChild(card);
        });

        if (window.lucide) {
            lucide.createIcons();
        }

    } catch (err) {
        container.innerHTML = `<p style="color:red;">Error: ${err.message}</p>`;
        console.error(err);
    }
}

// Auto-init if config exists
document.addEventListener("DOMContentLoaded", () => {
    if (window.__CAT_GRID_CONFIG__) {
        loadCategories(window.__CAT_GRID_CONFIG__);
    }
});
