document.addEventListener("DOMContentLoaded", () => {
    // ================= DEMO DATA =================
    let PRODUCTS = [];

    // ================= STATE =================
    let selectedCategory = null;
    let selectedPrice = null;
    let selectedRating = null;

    const searchInput = document.getElementById("mkt-search");

    // ❗ FIX 1: safe fallback instead of crashing
    const resultsContainer = document.getElementById(RESULTS_ID);

    const filterModal = document.getElementById("filter-modal");
    const filterDot = document.getElementById("filter-dot");

    if (!resultsContainer) return;

    // ================= FETCH PRODUCTS =================
    fetch('/api/all_listings')
        .then(res => res.json())
        .then(data => {
            PRODUCTS = data.items || [];
            updateResults(); // ❗ FIX 2: render AFTER data loads
        })
        .catch(err => {
            console.error('Error fetching products:', err);
            resultsContainer.innerHTML = "Failed to load products";
        });

    // ================= MODAL OPEN/CLOSE =================
    document.getElementById("filter-open").addEventListener("click", () => {
        filterModal.classList.add("open");
    });

    document.getElementById("modal-close-btn").addEventListener("click", () => {
        filterModal.classList.remove("open");
    });

    filterModal.addEventListener("click", (e) => {
        if (e.target === filterModal) {
            filterModal.classList.remove("open");
        }
    });

    // ================= CHIP HELPERS =================
    function setupChips(containerId, setter) {
        const chips = document.querySelectorAll(`#${containerId} .chip`);

        chips.forEach(chip => {
            chip.addEventListener("click", () => {
                chips.forEach(c => c.classList.remove("active"));
                chip.classList.add("active");
                setter(chip.dataset.val);
                filterDot.classList.add("active");
            });
        });
    }

    setupChips("cat-chips", val => selectedCategory = val);
    setupChips("price-chips", val => selectedPrice = val);
    setupChips("rating-chips", val => selectedRating = val);

    // ================= FILTER FUNCTION =================
    function filterProducts() {
        const query = (searchInput.value || "").toLowerCase().trim();

        return PRODUCTS.filter(p => {
            const name = (p.title || "").toLowerCase();
            const category = (p.category || "").toLowerCase();

            const matchText =
                name.includes(query) ||
                category.includes(query) ||
                String(p.price || "").includes(query);

                const matchCategory =
           !selectedCategory ||
             p.category.toLowerCase() === selectedCategory.toLowerCase();

            let matchPrice = true;
            if (selectedPrice) {
                const [minRaw, maxRaw] = selectedPrice.split("-");
                const min = minRaw !== "" ? Number(minRaw) : null;
                const max = maxRaw !== "" ? Number(maxRaw) : null;

                if (min !== null && max !== null) {
                    matchPrice = p.price >= min && p.price <= max;
                } else if (min !== null) {
                    matchPrice = p.price >= min;
                } else if (max !== null) {
                    matchPrice = p.price <= max;
                }
            }

            const matchRating =
                !selectedRating || (p.rating || 0) >= parseFloat(selectedRating);

            return matchText && matchCategory && matchPrice && matchRating;
        });
    }

    // ================= CATEGORY ICONS =================
    const catIcons = {
        Electronics: '💻',
        Clothing: '👕',
        Fashion: '👗',
        Furniture: '🪑',
        Vehicles: '🚗',
        Services: '🔧',
        Books: '📚',
        Beauty: '💄',
        Sports: '⚽',
        Other: '📦'
    };

    // ================= RENDER =================
    function renderProducts(items, container) {
        container.innerHTML = '';

        if (!items || !items.length) {
            container.innerHTML = '<p>No trending items available.</p>';
            return;
        }

        items.forEach(item => {
            const catIcon = catIcons[item.category] || '💻';
            const heat = (item.order_count || 0) + (item.save_count || 0);
            const isHot = heat >= 5;
            const isBusiness = item.account_type === 'business';
            const isVerified = item.biz_verified === 'yes';
            const displayName =
                (isBusiness && item.business_name)
                    ? item.business_name
                    : item.seller_name;

            const a = document.createElement('a');
            a.className = `offer-card ${isBusiness ? 'biz' : 'ind'}`;
            a.href = `/product_details?id=${encodeURIComponent(item.id)}`;

            let imgSrc = item.thumb;

            if (!imgSrc && item.images) {
                try {
                    const imgs = JSON.parse(item.images);
                    if (Array.isArray(imgs) && imgs.length) {
                        imgSrc = imgs[0];
                    }
                } catch (e) {}
            }

            const placeholder = document.createElement('div');
            placeholder.className = 'offer-img-placeholder';
            placeholder.textContent = catIcon;

            if (imgSrc) {
                const img = document.createElement('img');
                img.className = 'offer-img';
                img.src = imgSrc;
                img.alt = item.title || '';
                img.loading = 'lazy';

                img.onerror = function () {
                    this.remove();
                    placeholder.style.display = 'flex';
                };

                a.appendChild(img);
            }

            if (imgSrc) placeholder.style.display = 'none';
            a.appendChild(placeholder);

            const body = document.createElement('div');
            body.className = 'offer-body';

            const badgeRow = document.createElement('div');
            badgeRow.className = 'card-type-row';

            if (isBusiness) {
                const bizBadge = document.createElement('span');
                bizBadge.className = 'badge-biz';
                bizBadge.textContent = '🏢 Business';
                badgeRow.appendChild(bizBadge);

                if (isVerified) {
                    const verifiedBadge = document.createElement('span');
                    verifiedBadge.className = 'badge-verified';
                    verifiedBadge.textContent = '✓ Verified';
                    badgeRow.appendChild(verifiedBadge);
                }
            } else {
                const indBadge = document.createElement('span');
                indBadge.className = 'badge-ind';
                indBadge.textContent = '👤 Individual';
                badgeRow.appendChild(indBadge);
            }

            if (isHot) {
                const hotBadge = document.createElement('span');
                hotBadge.className = 'badge-hot';
                hotBadge.textContent = '🔥 Hot';
                badgeRow.appendChild(hotBadge);
            }

            body.appendChild(badgeRow);

            const price = document.createElement('div');
            price.className = 'offer-price';
            price.innerHTML =
                `<span class="from">KSh</span> ${(item.price || 0).toLocaleString()}`;
            body.appendChild(price);

            const title = document.createElement('div');
            title.className = 'offer-title';
            title.textContent = item.title || '';
            body.appendChild(title);

            const seller = document.createElement('div');
            seller.className = 'offer-seller';
            seller.innerHTML = `
                <span class="seller-dot ${isBusiness ? 'dot-biz' : 'dot-ind'}"></span>
                <span class="${isBusiness ? 'seller-biz' : ''}">
                    ${displayName || 'Unknown'}
                </span>
            `;
            body.appendChild(seller);

            const stars = document.createElement('div');
            stars.className = 'offer-stars';

            const rating = Math.max(0, Math.min(5, parseFloat(item.rating || 0)));
            const fullStars = Math.floor(rating);
            const hasHalf = rating - fullStars >= 0.5;

            let starHtml = '★'.repeat(fullStars);
            if (hasHalf) starHtml += '⯨';
            starHtml += '☆'.repeat(5 - fullStars - (hasHalf ? 1 : 0));

            stars.innerHTML = `
                ${starHtml}
                <span style="color:var(--gray);margin-left:3px">
                    ${rating.toFixed(1)}
                </span>
                ${item.location
                    ? `<span class="offer-loc">${item.location}</span>`
                    : ''}
            `;

            body.appendChild(stars);

            a.appendChild(body);
            container.appendChild(a);
        });
    }

    // ================= UPDATE UI =================
    function updateResults() {
        renderProducts(filterProducts(), resultsContainer);
    }
    
    
    //filter using external buttons
    document.querySelectorAll(".cat-item").forEach(item => {
    item.addEventListener("click", (e) => {
        e.preventDefault();

        const label = item.querySelector(".cat-label").textContent.trim();

        selectedCategory = label;
        updateResults();
    });
});

    // live typing
    searchInput.addEventListener("input", updateResults);

    document.getElementById("search-btn").addEventListener("click", updateResults);

    document.getElementById("apply-filters-btn").addEventListener("click", () => {
        filterModal.classList.remove("open");
        updateResults();
    });

    document.getElementById("reset-filters-btn").addEventListener("click", () => {
        selectedCategory = null;
        selectedPrice = null;
        selectedRating = null;

        document.querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
        filterDot.classList.remove("active");

        searchInput.value = "";
        updateResults();
    });
});



