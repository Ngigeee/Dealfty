// ════════════════════════════════════════════════════
//  PRICING (KSh)
// ════════════════════════════════════════════════════
const BASE   = { motorcycle:{standard:300,express:500}, car_van:{standard:800,express:1300}, truck:{standard:1500,express:2500} };
const PER_KM = { motorcycle:{standard:35,express:55},   car_van:{standard:60,express:90},    truck:{standard:100,express:150}  };
const SIZE_M = { small:1, medium:1.3, large:1.7, xl:2.5 };
const V_LABEL= { motorcycle:'Motorcycle', car_van:'Car / Van', truck:'Pickup Truck' };

let CUR_V    = 'motorcycle';
let CUR_S    = 'standard';
let CUR_SIZE = 'small';
let DIST_KM  = 0;

let mapObj, dirService, dirRenderer, geocoderObj, acService;

// ════════════════════════════════════════════════════
//  GOOGLE MAPS
// ════════════════════════════════════════════════════
function initMap() {
    document.getElementById('map-loader').style.display = 'none';

    mapObj = new google.maps.Map(document.getElementById('map'), {
        center: { lat: -1.2921, lng: 36.8219 }, // Nairobi CBD
        zoom: 13,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: false,
        zoomControl: true,
        styles: [
            { featureType:'poi.business', stylers:[{visibility:'off'}] },
            { featureType:'transit',      stylers:[{visibility:'off'}] }
        ]
    });

    dirService  = new google.maps.DirectionsService();
    dirRenderer = new google.maps.DirectionsRenderer({
        map: mapObj,
        suppressMarkers: false,
        polylineOptions: { strokeColor:'#2E9E3E', strokeWeight:5, strokeOpacity:.85 }
    });
    geocoderObj = new google.maps.Geocoder();
    acService   = new google.maps.places.AutocompleteService();

    // Idle fires after map stops moving — used for draggable pin
    mapObj.addListener('idle', onMapIdle);

    // Auto-calc if values exist (form re-load)
    const p = document.getElementById('pickup-input').value.trim();
    const d = document.getElementById('dropoff-input').value.trim();
    if (p && d) calcRoute();
}

// ── ROUTE CALCULATION ────────────────────────────────
function calcRoute() {
    const p = document.getElementById('pickup-input').value.trim();
    const d = document.getElementById('dropoff-input').value.trim();
    if (!p || !d || !dirService) return;

    dirService.route({
        origin: p, destination: d,
        travelMode: google.maps.TravelMode.DRIVING,
        region: 'KE'
    }, (result, status) => {
        if (status === 'OK') {
            dirRenderer.setDirections(result);
            const leg = result.routes[0].legs[0];
            DIST_KM = leg.distance.value / 1000;
            document.getElementById('route-distance').textContent = leg.distance.text;
            document.getElementById('route-duration').textContent = leg.duration.text;
        } else {
            DIST_KM = 0;
            document.getElementById('route-distance').textContent = 'N/A';
            document.getElementById('route-duration').textContent = 'N/A';
        }
        updateCost();
    });
}

// ── AUTOCOMPLETE ─────────────────────────────────────
function acSearch(input, listId) {
    const val = input.value.trim();
    const list = document.getElementById(listId);
    if (!val || !acService) { list.classList.remove('show'); return; }

    acService.getPlacePredictions(
        { input: val, componentRestrictions: { country: 'ke' } },
        (preds, status) => {
            if (status !== 'OK' || !preds) { list.classList.remove('show'); return; }
            list.innerHTML = preds.slice(0,5).map(p =>
                `<div class="ac-item" onmousedown="fillLoc('${input.id}','${listId}','${p.description.replace(/'/g,"\\'").replace(/"/g,"&quot;")}')">
                    <span class="ac-icon">📍</span>${p.description}
                 </div>`
            ).join('');
            list.classList.add('show');
        }
    );
}

function fillLoc(inputId, listId, val) {
    document.getElementById(inputId).value = val;
    document.getElementById(listId).classList.remove('show');
    const type = inputId === 'pickup-input' ? 'pickup' : 'dropoff';
    showConfirmed(type, true, val);
    calcRoute();
}

function hideAc(listId) {
    document.getElementById(listId).classList.remove('show');
}

// ── GPS ───────────────────────────────────────────────
function getMyLocation(btn, inputId, acId) {
    if (!navigator.geolocation) {
        alert('Geolocation is not supported by your browser.');
        return;
    }

    // Show spinner in button
    const origHTML = btn.innerHTML;
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" style="animation:spin .7s linear infinite"><circle cx="12" cy="12" r="9" fill="none" stroke="#2E9E3E" stroke-width="3" stroke-dasharray="28" stroke-dashoffset="10"/></svg>';
    btn.disabled = true;

    const opts = { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 };

    navigator.geolocation.getCurrentPosition(
        pos => {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;

            // Try Google Maps geocoder first, fall back to Nominatim
            if (geocoderObj) {
                geocoderObj.geocode(
                    { location: new google.maps.LatLng(lat, lng), region: 'ke' },
                    (results, status) => {
                        btn.innerHTML = origHTML; btn.disabled = false;
                        if (status === 'OK' && results[0]) {
                            const addr = results[0].formatted_address;
                            document.getElementById(inputId).value = addr;
                            document.getElementById(acId).classList.remove('show');
                            const type = inputId === 'pickup-input' ? 'pickup' : 'dropoff';
                            showConfirmed(type, true, addr);
                            calcRoute();
                        } else {
                            nominatimReverse(lat, lng, inputId, acId);
                        }
                    }
                );
            } else {
                // Maps not loaded — use OpenStreetMap Nominatim (free, no key)
                btn.innerHTML = origHTML; btn.disabled = false;
                nominatimReverse(lat, lng, inputId, acId);
            }
        },
        err => {
            btn.innerHTML = origHTML; btn.disabled = false;
            let msg = 'Could not get your location.';
            if (err.code === 1) msg = 'Location access denied.\nPlease allow location in your browser settings, then try again.';
            else if (err.code === 2) msg = 'Location unavailable. Check your GPS is on.';
            else if (err.code === 3) msg = 'Location request timed out. Try again.';
            alert(msg);
        },
        opts
    );
}

function nominatimReverse(lat, lng, inputId, acId) {
    fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&addressdetails=1`)
        .then(r => r.json())
        .then(data => {
            const addr = data.display_name || `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
            document.getElementById(inputId).value = addr;
            if (acId && document.getElementById(acId)) document.getElementById(acId).classList.remove('show');
            const type = inputId === 'pickup-input' ? 'pickup' : 'dropoff';
            showConfirmed(type, true, addr);
            if (typeof placeMarker === 'function') placeMarker(type, lat, lng);
            calcRoute();
        })
        .catch(() => {
            const addr = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
            document.getElementById(inputId).value = addr;
            calcRoute();
        });
}

// ── MAP MODE (route / pickup pin / dropoff pin) ──────
// mapMode, pickupMarker, dropoffMarker defined in Leaflet section below

function setMapMode(mode) {
    mapMode = mode;
    ['route','pickup','dropoff'].forEach(m => {
        document.getElementById('mode-'+m).classList.toggle('active', m === mode);
    });

    const pinOverlay = document.getElementById('map-pin-overlay');
    const dragHint   = document.getElementById('map-drag-hint');
    const pinFill    = document.getElementById('pin-fill');
    const pinInner   = document.getElementById('pin-inner');

    if (mode === 'route') {
        pinOverlay.style.display = 'none';
        dragHint.style.display   = 'none';
        if (mapObj) dirRenderer.setMap(mapObj);
    } else {
        pinOverlay.style.display = 'flex';
        dragHint.style.display   = 'flex';
        if (mapObj) dirRenderer.setMap(null); // hide route in pin mode

        // Colour pin by mode
        const colour = mode === 'pickup' ? '#2E9E3E' : '#D94040';
        if (pinFill)  pinFill.setAttribute('fill', colour);
        if (pinInner) pinInner.setAttribute('fill', colour);
    }
}

function onMapIdle() {
    if (!mapObj || mapMode === 'route') return;
    const centre = mapObj.getCenter();
    const inputId = mapMode === 'pickup' ? 'pickup-input' : 'dropoff-input';
    const acId    = mapMode === 'pickup' ? 'pickup-ac'    : 'dropoff-ac';

    // Reverse-geocode the centre
    if (geocoderObj) {
        geocoderObj.geocode({ location: centre, region: 'ke' }, (results, status) => {
            if (status === 'OK' && results[0]) {
                const addr = results[0].formatted_address;
                document.getElementById(inputId).value = addr;
                showConfirmed(mapMode, true, addr);
                hideAc(acId);
                if (mapMode === 'pickup' || mapMode === 'dropoff') calcRoute();
            }
        });
    } else {
        nominatimReverse(centre.lat(), centre.lng(), inputId, acId);
    }
}

// ── CONFIRMED ADDRESS DISPLAY ────────────────────────
function showConfirmed(type, show, addr) {
    const box  = document.getElementById(type+'-confirmed');
    const text = document.getElementById(type+'-confirmed-text');
    if (show && addr) {
        text.textContent = addr;
        box.classList.add('show');
    } else {
        box.classList.remove('show');
    }
}

function clearConfirmed(type) {
    document.getElementById(type+'-confirmed').classList.remove('show');
    document.getElementById(type+'-input').value = '';
    document.getElementById(type+'-input').focus();
}

// ── COUNTY / SUB-COUNTY PICKER ───────────────────────
const SUB_COUNTIES = <?php
$all = [];
foreach(getKenyaCounties() as $c) { $subs = getSubCounties($c); if($subs) $all[$c]=$subs; }
echo json_encode($all);
?>;

function togglePickerSection(id) {
    const el = document.getElementById(id);
    el.classList.toggle('show');
    if (el.classList.contains('show')) el.scrollIntoView({ behavior:'smooth', block:'nearest' });
}

function loadSubCounties(county, selectId) {
    const sel  = document.getElementById(selectId);
    const subs = SUB_COUNTIES[county] || [];
    sel.innerHTML = '<option value="">— Select Sub-County —</option>' +
        subs.map(s => `<option value="${s}">${s}</option>`).join('');
}

function buildAddressFromPicker(type) {
    const county   = document.getElementById(type+'-county').value;
    const subcounty= document.getElementById(type+'-subcounty').value;
    const town     = document.querySelector(`[name="${type}_town"]`).value.trim();
    const village  = document.querySelector(`[name="${type}_village"]`).value.trim();

    const parts = [village, town, subcounty, county, 'Kenya'].filter(Boolean);
    if (parts.length < 2) { alert('Please select at least a county and enter a location.'); return; }

    const addr = parts.join(', ');
    document.getElementById(type+'-input').value = addr;
    showConfirmed(type, true, addr);
    document.getElementById(type+'-county-wrap').classList.remove('show');
    calcRoute();
}

// ── CALL WHEN ARRIVE ────────────────────────────────
// (handled by native checkbox + toggle CSS — no extra JS needed)

function swapLocs() {
    const p = document.getElementById('pickup-input');
    const d = document.getElementById('dropoff-input');
    [p.value, d.value] = [d.value, p.value];
    if (p.value && d.value) calcRoute();
}

// ── VEHICLE / SERVICE ────────────────────────────────
function selectVehicle(v) {
    document.querySelectorAll('.vehicle-row').forEach(r => r.classList.remove('selected'));
    document.getElementById('vrow-' + v).classList.add('selected');
    document.getElementById('vehicle-hidden').value = v;
    CUR_V = v;
    // reset service to standard for new vehicle
    document.querySelectorAll(`.svc-pill[data-v="${v}"]`).forEach(p => {
        p.classList.toggle('active', p.dataset.s === 'standard');
    });
    document.getElementById('service-hidden').value = 'standard';
    CUR_S = 'standard';
    updateCost();
}

function setSvc(pill) {
    const v = pill.dataset.v;
    const s = pill.dataset.s;
    document.querySelectorAll(`.svc-pill[data-v="${v}"]`).forEach(p => p.classList.remove('active'));
    pill.classList.add('active');
    if (CUR_V === v) {
        document.getElementById('service-hidden').value = s;
        CUR_S = s;
        updateCost();
    }
}

// ── SIZE ──────────────────────────────────────────────
function setSize(label, size) {
    document.querySelectorAll('.size-opt').forEach(o => o.classList.remove('active'));
    label.classList.add('active');
    CUR_SIZE = size;
    updateCost();
}

// ── COST ──────────────────────────────────────────────
function updateCost() {
    const base  = BASE[CUR_V]?.[CUR_S]   || 300;
    const perKm = PER_KM[CUR_V]?.[CUR_S] || 35;
    const mult  = SIZE_M[CUR_SIZE]        || 1;
    const dist  = Math.max(DIST_KM, 0);
    const total = Math.round((base + perKm * dist) * mult);

    const fmt = total.toLocaleString('en-KE');
    document.getElementById('cost-display').textContent = 'KSh ' + fmt;
    document.getElementById('route-cost').textContent   = 'KSh ' + fmt;
    document.getElementById('estimated-cost-hidden').value = total;

    const vl = V_LABEL[CUR_V] || CUR_V;
    const sl = CUR_S.charAt(0).toUpperCase() + CUR_S.slice(1);
    const dl = dist > 0 ? ` · ${dist.toFixed(1)} km` : ' · Base rate';
    document.getElementById('cost-breakdown').textContent = `${vl} · ${sl}${dl}`;

    // Update price labels on each vehicle row
    Object.keys(BASE).forEach(v => {
        const activeSvc = document.querySelector(`.svc-pill[data-v="${v}"].active`)?.dataset.s || 'standard';
        const b = BASE[v]?.[activeSvc] || 0;
        const el = document.getElementById('price-' + v);
        if (el) el.textContent = 'KSh ' + b.toLocaleString('en-KE') + '+';
    });
}

// ── FORM VALIDATION ──────────────────────────────────
document.getElementById('delivery-form').addEventListener('submit', function(e) {
    const p = document.getElementById('pickup-input').value.trim();
    const d = document.getElementById('dropoff-input').value.trim();
    const desc   = this.querySelector('[name=package_desc]').value.trim();
    const rName  = this.querySelector('[name=recipient_name]').value.trim();
    const rPhone = this.querySelector('[name=recipient_phone]').value.trim();

    if (!p)      { e.preventDefault(); alert('⚠️ Please enter a pickup location.'); return; }
    if (!d)      { e.preventDefault(); alert('⚠️ Please enter a drop-off location.'); return; }
    if (!desc)   { e.preventDefault(); alert('⚠️ Please describe what you are sending.'); return; }
    if (!rName)  { e.preventDefault(); alert('⚠️ Please enter the recipient name.'); return; }
    if (!rPhone) { e.preventDefault(); alert('⚠️ Please enter the recipient phone number.'); return; }

    const btn = document.getElementById('submit-btn');
    btn.disabled = true;
    btn.textContent = '⏳ Submitting...';
});

// ════════════════════════════════════════════════════
//  LEAFLET MAP (free, no API key needed)
// ════════════════════════════════════════════════════
let leafletMap, pickupMarker, dropoffMarker, routeLayer;
let mapMode = 'route';
let mapIdleTimer = null;

function initLeafletMap() {
    // Load Leaflet JS
    const s = document.createElement('script');
    s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    s.onload = function() {
        // Init map centered on Nairobi
        leafletMap = L.map('leaflet-map', {
            center: [-1.2921, 36.8219],
            zoom: 13,
            zoomControl: true
        });

        // OpenStreetMap tiles (free, no key)
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 19
        }).addTo(leafletMap);

        // Custom pin icons
        const greenIcon = L.divIcon({
            html: '<svg width="28" height="36" viewBox="0 0 24 30"><path d="M12 0C5.37 0 0 5.37 0 12c0 9 12 18 12 18S24 21 24 12C24 5.37 18.63 0 12 0z" fill="#2E9E3E"/><circle cx="12" cy="12" r="4" fill="white"/></svg>',
            className: '', iconSize:[28,36], iconAnchor:[14,36], popupAnchor:[0,-36]
        });
        const redIcon = L.divIcon({
            html: '<svg width="28" height="36" viewBox="0 0 24 30"><path d="M12 0C5.37 0 0 5.37 0 12c0 9 12 18 12 18S24 21 24 12C24 5.37 18.63 0 12 0z" fill="#D94040"/><circle cx="12" cy="12" r="4" fill="white"/></svg>',
            className: '', iconSize:[28,36], iconAnchor:[14,36], popupAnchor:[0,-36]
        });

        window._greenIcon = greenIcon;
        window._redIcon   = redIcon;

        // Map idle — used for drag-to-set-pin
        leafletMap.on('moveend', function() {
            if (mapMode === 'route') return;
            clearTimeout(mapIdleTimer);
            mapIdleTimer = setTimeout(() => {
                const c = leafletMap.getCenter();
                nominatimReverse(c.lat, c.lng,
                    mapMode === 'pickup' ? 'pickup-input' : 'dropoff-input',
                    mapMode === 'pickup' ? 'pickup-ac'    : 'dropoff-ac'
                );
            }, 800);
        });

        // Pre-fill markers if values exist
        const p = document.getElementById('pickup-input').value.trim();
        const d = document.getElementById('dropoff-input').value.trim();
        if (p && d) calcRoute();
        else if (p)  geocodeAndMark(p, 'pickup');
        else if (d)  geocodeAndMark(d, 'dropoff');
    };
    document.head.appendChild(s);
}

// ── GEOCODE ADDRESS → MARKER ─────────────────────────
function geocodeAndMark(addr, type) {
    fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(addr)}&format=json&limit=1&countrycodes=ke`)
        .then(r => r.json())
        .then(data => {
            if (!data.length) return;
            const lat = parseFloat(data[0].lat);
            const lng = parseFloat(data[0].lon);
            placeMarker(type, lat, lng);
        }).catch(() => {});
}

// ── PLACE MARKER ─────────────────────────────────────
function placeMarker(type, lat, lng) {
    if (!leafletMap) return;
    if (type === 'pickup') {
        if (pickupMarker) leafletMap.removeLayer(pickupMarker);
        pickupMarker = L.marker([lat, lng], { icon: window._greenIcon })
            .addTo(leafletMap).bindPopup('📍 Pickup').openPopup();
    } else {
        if (dropoffMarker) leafletMap.removeLayer(dropoffMarker);
        dropoffMarker = L.marker([lat, lng], { icon: window._redIcon })
            .addTo(leafletMap).bindPopup('🚩 Drop-off').openPopup();
    }
    fitMapToMarkers();
}

// ── FIT MAP TO MARKERS ───────────────────────────────
function fitMapToMarkers() {
    const markers = [pickupMarker, dropoffMarker].filter(Boolean);
    if (markers.length === 2) {
        const group = L.featureGroup(markers);
        leafletMap.fitBounds(group.getBounds().pad(0.2));
        drawRoute();
    } else if (markers.length === 1) {
        leafletMap.setView(markers[0].getLatLng(), 14);
    }
}

// ── DRAW ROUTE LINE ───────────────────────────────────
function drawRoute() {
    if (!pickupMarker || !dropoffMarker) return;
    const p = pickupMarker.getLatLng();
    const d = dropoffMarker.getLatLng();

    // Straight-line for now; OSRM for actual road route
    if (routeLayer) leafletMap.removeLayer(routeLayer);

    // Use OSRM (free routing API)
    const url = `https://router.project-osrm.org/route/v1/driving/${p.lng},${p.lat};${d.lng},${d.lat}?overview=full&geometries=geojson`;
    fetch(url)
        .then(r => r.json())
        .then(data => {
            if (data.code === 'Ok' && data.routes.length) {
                const route = data.routes[0];
                DIST_KM = route.distance / 1000;
                const mins = Math.round(route.duration / 60);

                document.getElementById('route-distance').textContent = DIST_KM.toFixed(1) + ' km';
                document.getElementById('route-duration').textContent = mins > 60
                    ? `${Math.floor(mins/60)}h ${mins%60}m`
                    : `${mins} min`;

                routeLayer = L.geoJSON(route.geometry, {
                    style: { color:'#2E9E3E', weight:5, opacity:.85 }
                }).addTo(leafletMap);

                leafletMap.fitBounds(routeLayer.getBounds().pad(0.15));
                updateCost();
            }
        }).catch(() => {
            // Fallback: straight line
            if (routeLayer) leafletMap.removeLayer(routeLayer);
            routeLayer = L.polyline([[p.lat,p.lng],[d.lat,d.lng]], {
                color:'#2E9E3E', weight:4, opacity:.7, dashArray:'8,6'
            }).addTo(leafletMap);
            // Estimate distance (haversine)
            DIST_KM = leafletMap.distance(p, d) / 1000;
            document.getElementById('route-distance').textContent = DIST_KM.toFixed(1) + ' km';
            document.getElementById('route-duration').textContent = '~' + Math.round(DIST_KM * 3) + ' min';
            updateCost();
        });
}

// ── CALC ROUTE (called when inputs change) ───────────
function calcRoute() {
    const p = document.getElementById('pickup-input').value.trim();
    const d = document.getElementById('dropoff-input').value.trim();
    if (!p || !d || !leafletMap) return;
    geocodeAndMark(p, 'pickup');
    setTimeout(() => geocodeAndMark(d, 'dropoff'), 300);
}

// ── MAP MODE ──────────────────────────────────────────
function setMapMode(mode) {
    mapMode = mode;
    ['route','pickup','dropoff'].forEach(m => {
        document.getElementById('mode-'+m).classList.toggle('active', m === mode);
    });

    const pinOverlay = document.getElementById('map-pin-overlay');
    const dragHint   = document.getElementById('map-drag-hint');
    const pinFill    = document.getElementById('pin-fill');
    const pinInner   = document.getElementById('pin-inner');

    const show = mode !== 'route';
    pinOverlay.style.display = show ? 'flex' : 'none';
    dragHint.style.display   = show ? 'flex' : 'none';

    if (show) {
        const colour = mode === 'pickup' ? '#2E9E3E' : '#D94040';
        if (pinFill)  pinFill.setAttribute('fill', colour);
        if (pinInner) pinInner.setAttribute('fill', colour);
        // Scroll map into view
        document.getElementById('map-section-wrap').scrollIntoView({behavior:'smooth',block:'center'});
    }
}

// Init Leaflet on DOM ready
document.addEventListener('DOMContentLoaded', initLeafletMap);

// Init cost immediately
updateCost();


// Leaflet needs to be loaded before we can call initLeafletMap if called inline
// DOMContentLoaded handles it above


// ── SERVICES MENU ────────────────────────────────
function toggleSvcMenu(){
    var popup=document.getElementById('svc-popup');
    var scrim=document.getElementById('svc-scrim');
    var btn=document.querySelector('.bnav-svc-btn');
    if(!popup||!scrim)return;
    var open=popup.classList.contains('open');
    popup.classList.toggle('open',!open);
    scrim.classList.toggle('open',!open);
    if(btn)btn.classList.toggle('menu-open',!open);
}
function closeSvcMenu(){
    var popup=document.getElementById('svc-popup');
    var scrim=document.getElementById('svc-scrim');
    if(popup)popup.classList.remove('open');
    if(scrim)scrim.classList.remove('open');
    document.querySelectorAll('.bnav-svc-btn').forEach(function(b){b.classList.remove('menu-open');});
}
document.addEventListener('keydown',function(e){if(e.key==='Escape')closeSvcMenu();});
// ── END SERVICES MENU ─────────────────────────────

// ══ DEALFITY FAB ══════════════════════════════════════════
(function(){
var _open = false;
var _pages = {
    ai:       {name:'AI Assistant',  badge:'AI',      badgeColor:'#7B3FBE', badgeBg:'#F3EFFE', src:'ai.php'},
    messages: {name:'Messages',      badge:'Chat',    badgeColor:'#1A5FA8', badgeBg:'#E3EEF9', src:'messages.php'},
    support:  {name:'Support',       badge:'Help',    badgeColor:'#0D9488', badgeBg:'#E1F5EE', src:'support.php'},
};

window.dfabToggle = function(){
    _open = !_open;
    document.getElementById('dfab-wrap').classList.toggle('open',_open);
    document.getElementById('dfab-btn').classList.toggle('open',_open);
    document.getElementById('dfab-scrim').classList.toggle('open',_open);
};
window.dfabClose = function(){
    _open = false;
    document.getElementById('dfab-wrap').classList.remove('open');
    document.getElementById('dfab-btn').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
};
window.dfabOpen = function(type){
    dfabClose();
    var p = _pages[type];
    if(!p) return;
    document.getElementById('dfab-page-name').textContent = p.name;
    var badge = document.getElementById('dfab-page-badge');
    badge.textContent = p.badge;
    badge.style.background = p.badgeBg;
    badge.style.color = p.badgeColor;
    // Load iframe with ?panel=1 so the page hides its own nav/footer
    var iframe = document.getElementById('dfab-iframe');
    var panelSrc = p.src + (p.src.indexOf('?') === -1 ? '?panel=1' : '&panel=1');
    if(iframe.dataset.loaded !== panelSrc){
        iframe.src = panelSrc;
        iframe.dataset.loaded = panelSrc;
    }
    document.getElementById('dfab-menu').style.display = 'none';
    document.getElementById('dfab-page').classList.add('show');
    document.getElementById('dfab-panel').classList.add('open');
    document.getElementById('dfab-panel-scrim').classList.add('open');
};
window.dfabBack = function(){
    document.getElementById('dfab-menu').style.display = 'block';
    document.getElementById('dfab-page').classList.remove('show');
    document.getElementById('dfab-iframe').src = 'about:blank';
    document.getElementById('dfab-iframe').dataset.loaded = '';
    document.getElementById('dfab-panel-scrim').classList.remove('open');
};
window.dfabPanelClose = function(){
    document.getElementById('dfab-panel').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
    document.getElementById('dfab-panel-scrim').classList.remove('open');
    setTimeout(function(){
        document.getElementById('dfab-menu').style.display = 'block';
        document.getElementById('dfab-page').classList.remove('show');
        document.getElementById('dfab-iframe').src = 'about:blank';
        document.getElementById('dfab-iframe').dataset.loaded = '';
    }, 320);
};
document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){dfabClose();dfabPanelClose();}
});
})();
// ══ END DEALFITY FAB ══════════════════════════════════════

// ══ LIVE NOTIFICATION BADGE POLLING ══════════════════════
<?php if (!empty($_SESSION['user_id'])): ?>
(function(){
var lastMsgId = <?= (int)$last_msg_id_init ?>;
var totalUnread = <?= (int)$unread_notif_count ?>;

function setAllBadges(count) {
    var tb = document.getElementById('topbar-notif-badge');
    if (tb) { tb.textContent = count > 99 ? '99+' : count; tb.style.display = count > 0 ? 'flex' : 'none'; }
    var fb = document.getElementById('fab-msg-badge');
    if (fb) { fb.textContent = count > 99 ? '99+' : count; fb.style.display = count > 0 ? 'flex' : 'none'; }
    var pb = document.getElementById('fab-panel-msg-badge');
    if (pb) { pb.textContent = count > 99 ? '99+' : count; pb.style.display = count > 0 ? 'inline-flex' : 'none'; }
    var btn = document.getElementById('dfab-btn');
    if (btn) { btn.style.boxShadow = count > 0 ? '0 4px 20px rgba(30,122,44,.45),0 0 0 4px rgba(217,64,64,.3)' : '0 4px 20px rgba(30,122,44,.45)'; }
}
function pollNotifications() {
    fetch('notifications.php?poll_messages=1&since=' + lastMsgId)
        .then(function(r){ return r.json(); })
        .then(function(d) {
            if (!d.messages || !d.messages.length) return;
            var n = d.messages.filter(function(m){ return m.id > lastMsgId; });
            if (!n.length) return;
            n.forEach(function(m){ if (m.id > lastMsgId) lastMsgId = m.id; });
            totalUnread += n.length;
            setAllBadges(totalUnread);
        }).catch(function(){});
}
setAllBadges(totalUnread);
setInterval(pollNotifications, 10000);
})();
