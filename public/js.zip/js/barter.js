
function openModal()  { document.getElementById('post-modal').classList.add('open');  document.body.style.overflow='hidden'; }
function closeModal() { document.getElementById('post-modal').classList.remove('open'); document.body.style.overflow=''; }

function previewImg(input) {
    if (!input.files || !input.files[0]) return;
    const reader = new FileReader();
    reader.onload = e => {
        document.getElementById('upload-preview').innerHTML =
            `<img src="${e.target.result}" style="width:100%;height:120px;object-fit:cover;border-radius:8px;display:block"/>`;
    };
    reader.readAsDataURL(input.files[0]);
}


// ══ DEALFITY FAB ══════════════════════════════════════════
(function(){
var _open = false;
var _pages = {
    ai:       {name:'AI Assistant',  badge:'AI',      badgeColor:'#7B3FBE', badgeBg:'#F3EFFE', src:'ai.php'},
    messages: {name:'Messages',      badge:'Chat',    badgeColor:'#1A5FA8', badgeBg:'#E3EEF9', src:'messages.php'},
    support:  {name:'Support',       badge:'Help',    badgeColor:'#0D9488', badgeBg:'#E1F5EE', src:'support.php'},
};

window.dfabToggle = function(){
    _open = !_open;
    document.getElementById('dfab-wrap').classList.toggle('open',_open);
    document.getElementById('dfab-btn').classList.toggle('open',_open);
    document.getElementById('dfab-scrim').classList.toggle('open',_open);
};
window.dfabClose = function(){
    _open = false;
    document.getElementById('dfab-wrap').classList.remove('open');
    document.getElementById('dfab-btn').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
};
window.dfabOpen = function(type){
    dfabClose();
    var p = _pages[type];
    if(!p) return;
    document.getElementById('dfab-page-name').textContent = p.name;
    var badge = document.getElementById('dfab-page-badge');
    badge.textContent = p.badge;
    badge.style.background = p.badgeBg;
    badge.style.color = p.badgeColor;
    // Load iframe with ?panel=1 so the page hides its own nav/footer
    var iframe = document.getElementById('dfab-iframe');
    var panelSrc = p.src + (p.src.indexOf('?') === -1 ? '?panel=1' : '&panel=1');
    if(iframe.dataset.loaded !== panelSrc){
        iframe.src = panelSrc;
        iframe.dataset.loaded = panelSrc;
    }
    document.getElementById('dfab-menu').style.display = 'none';
    document.getElementById('dfab-page').classList.add('show');
    document.getElementById('dfab-panel').classList.add('open');
    document.getElementById('dfab-panel-scrim').classList.add('open');
};
window.dfabBack = function(){
    document.getElementById('dfab-menu').style.display = 'block';
    document.getElementById('dfab-page').classList.remove('show');
    document.getElementById('dfab-iframe').src = 'about:blank';
    document.getElementById('dfab-iframe').dataset.loaded = '';
    document.getElementById('dfab-panel-scrim').classList.remove('open');
};
window.dfabPanelClose = function(){
    document.getElementById('dfab-panel').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
    document.getElementById('dfab-panel-scrim').classList.remove('open');
    setTimeout(function(){
        document.getElementById('dfab-menu').style.display = 'block';
        document.getElementById('dfab-page').classList.remove('show');
        document.getElementById('dfab-iframe').src = 'about:blank';
        document.getElementById('dfab-iframe').dataset.loaded = '';
    }, 320);
};
document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){dfabClose();dfabPanelClose();}
});
})();
// ══ END DEALFITY FAB ══════════════════════════════════

// ══ LIVE NOTIFICATION BADGE POLLING ══════════════════════
<?php if (!empty($_SESSION['user_id'])): ?>
(function(){
var lastMsgId = <?= (int)$last_msg_id_init ?>;
var totalUnread = <?= (int)$unread_notif_count ?>;
function setAllBadges(count) {
    var tb = document.getElementById('topbar-notif-badge');
    if (tb) { tb.textContent = count > 99 ? '99+' : count; tb.style.display = count > 0 ? 'flex' : 'none'; }
    var fb = document.getElementById('fab-msg-badge');
    if (fb) { fb.textContent = count > 99 ? '99+' : count; fb.style.display = count > 0 ? 'flex' : 'none'; }
    var pb = document.getElementById('fab-panel-msg-badge');
    if (pb) { pb.textContent = count > 99 ? '99+' : count; pb.style.display = count > 0 ? 'inline-flex' : 'none'; }
    var btn = document.getElementById('dfab-btn');
    if (btn) { btn.style.boxShadow = count > 0 ? '0 4px 20px rgba(30,122,44,.45),0 0 0 4px rgba(217,64,64,.3)' : '0 4px 20px rgba(30,122,44,.45)'; }
}
function pollNotifications() {
    fetch('notifications.php?poll_messages=1&since=' + lastMsgId)
        .then(function(r){ return r.json(); })
        .then(function(d) {
            if (!d.messages || !d.messages.length) return;
            var n = d.messages.filter(function(m){ return m.id > lastMsgId; });
            if (!n.length) return;
            n.forEach(function(m){ if (m.id > lastMsgId) lastMsgId = m.id; });
            totalUnread += n.length;
            setAllBadges(totalUnread);
        }).catch(function(){});
}
setAllBadges(totalUnread);
setInterval(pollNotifications, 10000);
})();
