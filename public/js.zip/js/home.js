//overlay reusable function
/**
 * Generic reusable overlay function
 * @param {Array} data - Array of items to display
 * @param {Function} renderFn - Function that takes (item, container) and renders it
 */
function displayOverlay(url, renderFn) {
    // Inject overlay styles once
    if (!document.getElementById('overlay-styles')) {
        const style = document.createElement('style');
        style.id = 'overlay-styles';
        style.textContent = `
            .overlay {
                position: fixed;
                display: none;
                width: 100%;
                height: 100%;
                top: 0;
                left: 0;
                background-color: rgba(0,0,0,0.5);
                z-index: 9999;
            }
            .overlay-content {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                max-height: 90%;
                width:90%;
                display:flex;
                flex-wrap:wrap;
                gap:12px;
                overflow-y: auto;
                background:white;
                padding: 20px;
                border-radius: 10px;
                color: white;
            }
            .overlay-content::-webkit-scrollbar {
               display:none;
            }
        `;
        document.head.appendChild(style);
    }

    // Create overlay container
    let overlay = document.querySelector('.overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'overlay';
        document.body.appendChild(overlay);
    }

    // Create overlay content container
    let overlayContent = document.querySelector('.overlay-content');
    if (!overlayContent) {
        overlayContent = document.createElement('div');
        overlayContent.className = 'overlay-content';
        overlay.appendChild(overlayContent);
    }

    // Clear previous content
    overlayContent.innerHTML = '';

    // Fetch data
    fetch(url)
        .then(res => res.json())
        .then(data => {
            if (!data || !data.items) {
                overlayContent.innerHTML = '<p>No items found</p>';
                return;
            }
            // Call the reusable render function
            renderFn(data.items, overlayContent);
        })
        .catch(err => {
            console.error('Error fetching overlay data:', err);
            overlayContent.innerHTML = '<p>Error loading data</p>';
        });

    // Show overlay
    overlay.style.display = 'block';

    // Hide overlay on click
    overlay.onclick = () => {
        overlay.style.display = 'none';
    };
}

//calling it to show all the products



 
 
 
 
 
//render auctions
function renderAuctions(items,container) {
    
    container.innerHTML = '';

    if (!items || !items.length) {
        container.innerHTML = '<p>No live auctions.</p>';
        return;
    }

    const timers = [];

    items.forEach((item, index) => {
        // Unique timer IDs per card
        const hId = `t${index}h`;
        const mId = `t${index}m`;
        const sId = `t${index}s`;

        // Total seconds (you can pass from backend)
        const totalSeconds = item.time_left || 3600;

        // Card
        const a = document.createElement('a');
        a.className = 'auc-card';
        a.href = '#';

        // Image / placeholder
        const img = document.createElement('div');
        img.className = 'auc-img';
        img.textContent = item.icon || '🎧';

        // LIVE badge
        const liveBadge = document.createElement('div');
        liveBadge.className = 'auc-live-badge';
        liveBadge.innerHTML = `<div class="auc-live-dot"></div>LIVE`;
        img.appendChild(liveBadge);

        // Body
        const body = document.createElement('div');
        body.className = 'auc-body';

        const title = document.createElement('div');
        title.className = 'auc-title';
        title.textContent = item.title;

        const bid = document.createElement('div');
        bid.className = 'auc-bid';
        bid.innerHTML = `Bid: <strong>KSh ${parseFloat(item.bid || 0).toLocaleString()}</strong>`;

        // Timer UI (exact structure like your HTML)
        const timer = document.createElement('div');
        timer.className = 'auc-timer';
        timer.innerHTML = `
            <span id="${hId}" class="t-block">00</span><span class="t-sep">:</span>
            <span id="${mId}" class="t-block">00</span><span class="t-sep">:</span>
            <span id="${sId}" class="t-block">00</span>
        `;

        body.appendChild(title);
        body.appendChild(bid);
        body.appendChild(timer);

        a.appendChild(img);
        a.appendChild(body);
        container.appendChild(a);

        // Store timer config
        timers.push({ h: hId, m: mId, s: sId, total: totalSeconds });
    });

    // Start timer loop
    startAuctionTimers(timers);
}
//timers for auction
function startAuctionTimers(timers) {
    setInterval(() => {
        timers.forEach(t => {
            if (t.total <= 0) return;

            t.total--;

            const h = Math.floor(t.total / 3600);
            const m = Math.floor((t.total % 3600) / 60);
            const s = t.total % 60;

            const he = document.getElementById(t.h);
            const me = document.getElementById(t.m);
            const se = document.getElementById(t.s);

            if (he) he.textContent = String(h).padStart(2, '0');
            if (me) me.textContent = String(m).padStart(2, '0');
            if (se) se.textContent = String(s).padStart(2, '0');
        });
    }, 1000);
}

//call the auction function
const container = document.getElementById('auctions-scroll');
renderAuctions([
    { title: 'Sony WH-1000XM5', bid: 19000, time_left: 3600, icon: '🎧' },
    { title: 'iPhone 14 Pro', bid: 85000, time_left: 1800, icon: '📱' }
],container);

//create the moving brands
//data to use

const brands = [
  { name: "Samsung", color: "#1428A0" },
  { name: "Apple", color: "#000" },
  { name: "Tecno", color: "#0052CC" },
  { name: "Infinix", color: "#FF0000" },
  { name: "Sony", color: "#000" },
  { name: "LG", color: "#A50034" },
  { name: "Xiaomi", color: "#FF6900" },
  { name: "HP", color: "#0096D6" },
  { name: "Dell", color: "#007DB8" },
  { name: "Itel", color: "#00A651" },
  { name: "Nike", color: "#000" },
  { name: "Adidas", color: "#000" },
  { name: "Toyota", color: "#EB0A1E" },
  { name: "Huawei", color: "#CF0A2C" }
];
//data for second strip
const brands2 = [
  { name: "Vivo", color: "#415FFF" },
  { name: "OPPO", color: "#1C4DA1" },
  { name: "Nokia", color: "#124191" },
  { name: "Lenovo", color: "#E2231A" },
  { name: "Canon", color: "#CC0000" },
  { name: "Hisense", color: "#003087" },
  { name: "Von", color: "#D4002D" },
  { name: "Bruhm", color: "#1B6EC2" },
  { name: "Puma", color: "#000" },
  { name: "Nikon", color: "#FFD700", textColor: "black" },
  { name: "Bosch", color: "#EB0028" },
  { name: "Jumia", color: "#F68B1E" },
  { name: "Safaricom", color: "#00A551" },
  { name: "Airtel", color: "#E40000" }
];
//actual functions

function createBrandsStrip(containerId, brandsData) {
  const container = document.getElementById(containerId);

  const track = document.createElement("div");
  track.className = "brands-track";

  const inner = document.createElement("div");
  inner.className = "brands-inner";

  brandsData.forEach((brand, index) => {
    // Brand item
    const item = document.createElement("div");
    item.className = "brand-logo-item";

    // Icon
    const icon = document.createElement("div");
    icon.className = "brand-logo-icon";
    icon.style.background = brand.color;

    // Text inside icon (acts like logo fallback)
    const text = document.createElement("span");
    text.textContent = brand.name.toUpperCase();
    text.style.color = "white";
    text.style.fontWeight = "bold";
    text.style.fontSize = "12px";

    icon.appendChild(text);

    // Name below
    const name = document.createElement("span");
    name.className = "brand-logo-name";
    name.textContent = brand.name;

    item.appendChild(icon);
    item.appendChild(name);

    inner.appendChild(item);

    // Separator (except last)
    if (index !== brandsData.length - 1) {
      const sep = document.createElement("div");
      sep.className = "brand-sep";
      inner.appendChild(sep);
    }
  });

  track.appendChild(inner);
  container.appendChild(track);
}
//calling the functions

createBrandsStrip("brands-container", brands);
createBrandsStrip("brands-container2", brands2);
//end of function





///get all  products
fetch('/api/popular')   // Your server endpoint that returns JSON array
    .then(res => res.json())
    .then(data => {
    const container = document.getElementById('offers-scroll');
        renderOffers(data.items, container);
    })
    .catch(err => console.error('Error fetching popular items:', err));



// Category icons
const catIcons = {
    Electronics: '💻',
    Clothing: '👕',
    Fashion: '👗',
    Furniture: '🪑',
    Vehicles: '🚗',
    Services: '🔧',
    Books: '📚',
    Beauty: '💄',
    Sports: '⚽',
    Other: '📦'
};

/**
 * Render trending/popular items into a container
 * @param {Array} items - Array of objects with item info from server
 * @param {boolean} loggedIn - whether user is logged in
 */
function renderOffers(items, container) {
     
    
    container.innerHTML = '';

    if (!items || !items.length) {
        container.innerHTML = '<p>No trending items available.</p>';
        return;
    }

    items.forEach(item => {
        const catIcon = catIcons[item.category] || '💻';
        const heat = (item.order_count || 0) + (item.save_count || 0);
        const isHot = heat >= 5;
        const isBusiness = item.account_type === 'business';
        const isVerified = item.biz_verified === 'yes';
        const displayName = (isBusiness && item.business_name) ? item.business_name : item.seller_name;

        const a = document.createElement('a');
        a.className = `offer-card ${isBusiness ? 'biz' : 'ind'}`;
        a.href = `/product_details?id=${encodeURIComponent(item.id)}`;
        let imgSrc = item.thumb;
        if (!imgSrc && item.images) {
            try {
                const imgs = JSON.parse(item.images);
                if (Array.isArray(imgs) && imgs.length) imgSrc = imgs[0];
            } catch (e) {}
        }

        if (imgSrc) {
            const img = document.createElement('img');
            img.className = 'offer-img';
            img.src = imgSrc;
            img.alt = item.title || '';
            img.loading = 'lazy';
            img.onerror = function () {
                this.remove();
                placeholder.style.display = 'flex';
            };
            a.appendChild(img);
        }

        const placeholder = document.createElement('div');
        placeholder.className = 'offer-img-placeholder';
        placeholder.textContent = catIcon;
        if (imgSrc) placeholder.style.display = 'none';
        a.appendChild(placeholder);

        const body = document.createElement('div');
        body.className = 'offer-body';

        const badgeRow = document.createElement('div');
        badgeRow.className = 'card-type-row';

        if (isBusiness) {
            const bizBadge = document.createElement('span');
            bizBadge.className = 'badge-biz';
            bizBadge.textContent = '🏢 Business';
            badgeRow.appendChild(bizBadge);

            if (isVerified) {
                const verifiedBadge = document.createElement('span');
                verifiedBadge.className = 'badge-verified';
                verifiedBadge.textContent = '✓ Verified';
                badgeRow.appendChild(verifiedBadge);
            }
        } else {
            const indBadge = document.createElement('span');
            indBadge.className = 'badge-ind';
            indBadge.textContent = '👤 Individual';
            badgeRow.appendChild(indBadge);
        }

        if (isHot) {
            const hotBadge = document.createElement('span');
            hotBadge.className = 'badge-hot';
            hotBadge.textContent = '🔥 Hot';
            badgeRow.appendChild(hotBadge);
        }

        body.appendChild(badgeRow);
        
        const price = document.createElement('div');
        price.className = 'offer-price';
        price.innerHTML = `<span class="from">KSh</span> ${parseFloat(item.price || 0).toLocaleString()}`;
        body.appendChild(price);

        const title = document.createElement('div');
        title.className = 'offer-title';
        title.textContent = item.title || '';
        body.appendChild(title);

        

        const seller = document.createElement('div');
        seller.className = 'offer-seller';
        seller.innerHTML = `
            <span class="seller-dot ${isBusiness ? 'dot-biz' : 'dot-ind'}"></span>
            <span class="${isBusiness ? 'seller-biz' : ''}">${displayName || 'Unknown'}</span>
        `;
        body.appendChild(seller);

        const stars = document.createElement('div');
        stars.className = 'offer-stars';

        const rating = Math.max(0, Math.min(5, parseFloat(item.rating || 0)));
        const fullStars = Math.floor(rating);
        const hasHalf = rating - fullStars >= 0.5;

        let starHtml = '★'.repeat(fullStars);
        if (hasHalf) starHtml += '⯨';
        starHtml += '☆'.repeat(5 - fullStars - (hasHalf ? 1 : 0));

        stars.innerHTML = `
            ${starHtml} <span style="color:var(--gray);margin-left:3px">${rating.toFixed(1)}</span>
            ${item.location ? `<span class="offer-loc">${item.location}</span>` : ''}
        `;
        body.appendChild(stars);

        a.appendChild(body);
        container.appendChild(a);
    });
}


///end of my written functions






/// ── Services Menu ────────────────────────────────────────────────────────────
function toggleSvcMenu(){
    var popup=document.getElementById('svc-popup');
    var scrim=document.getElementById('svc-scrim');
    var btn=document.querySelector('.bnav-svc-btn');
    if(!popup||!scrim)return;
    var open=popup.classList.contains('open');
    popup.classList.toggle('open',!open);
    scrim.classList.toggle('open',!open);
    if(btn)btn.classList.toggle('menu-open',!open);
}
function closeSvcMenu(){
    var popup=document.getElementById('svc-popup');
    var scrim=document.getElementById('svc-scrim');
    if(popup)popup.classList.remove('open');
    if(scrim)scrim.classList.remove('open');
    document.querySelectorAll('.bnav-svc-btn').forEach(function(b){b.classList.remove('menu-open');});
}
document.addEventListener('keydown',function(e){if(e.key==='Escape')closeSvcMenu();});

// ── Auction Countdown Timers ─────────────────────────────────────────────────
(function(){
    const cards=document.querySelectorAll('.auc-card'),timers=[];
    cards.forEach(c=>{
        const h=parseInt(c.querySelector('[data-type="h"]')?.textContent||0);
        const m=parseInt(c.querySelector('[data-type="m"]')?.textContent||0);
        const s=parseInt(c.querySelector('[data-type="s"]')?.textContent||0);
        timers.push(h*3600+m*60+s);
    });
    setInterval(()=>{
        cards.forEach((c,i)=>{
            if(timers[i]<=0)return;timers[i]--;
            const t=timers[i],hh=Math.floor(t/3600),mm=Math.floor((t%3600)/60),ss=t%60;
            const p=n=>String(n).padStart(2,'0');
            const bl=c.querySelectorAll('.t-block');
            if(bl[0])bl[0].textContent=p(hh);if(bl[1])bl[1].textContent=p(mm);if(bl[2])bl[2].textContent=p(ss);
            if(t<60)bl.forEach(b=>b.style.background='#D94040');
        });
    },1000);
})();

// ── Search ───────────────────────────────────────────────────────────────
function handleSearchSubmit(e) {
    const q = document.getElementById('hsrch').value.trim();
    if (!q) {
        e.preventDefault();
        document.getElementById('hsrch').focus();
        return false;
    }
    // Allow native form submit to marketplace.php?q=...
    return true;
}

// Also handle Enter key explicitly (redundant but safe fallback)
document.getElementById('hsrch').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        const q = this.value.trim();
        if (q) location.href = 'marketplace.php?q=' + encodeURIComponent(q);
        else this.focus();
    }
});

// ── Voice search ─────────────────────────────────────────────────────────
document.getElementById('h-mic').addEventListener('click', function() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { alert('Voice search is not supported in this browser.'); return; }
    const btn = this;
    const r   = new SR();
    r.lang    = 'en-US';
    btn.classList.add('listening');
    r.start();
    r.onresult = ev => {
        document.getElementById('hsrch').value = ev.results[0][0].transcript;
        btn.classList.remove('listening');
        const q = ev.results[0][0].transcript.trim();
        if (q) location.href = 'marketplace.php?q=' + encodeURIComponent(q);
    };
    r.onerror = () => btn.classList.remove('listening');
    r.onend   = () => btn.classList.remove('listening');
});

// ── Newsletter ────────────────────────────────────────────────────────────
function handleNewsletter(e) {
    e.preventDefault();
    const email = document.getElementById('nl-email').value.trim();
    if (!email || !email.includes('@')) return;
    const btn = e.target.querySelector('button');
    btn.textContent = '✓ Subscribed!';
    btn.style.background = '#1e7a2c';
    btn.disabled = true;
}

// Hero banner carousel — image crossfade + text fade
const banners = [
    {
        title : 'Your Marketplace<br>for <span style="color:var(--yellow)">Deals</span> &amp; Services',
        sub   : 'Buy, sell, &amp; hire trusted pros—<br>all in one place!',
        cta   : 'Get Started',
        href  : '<?= $logged_in ? "marketplace.php" : "register.php" ?>'
    },
    {
        title : 'Find Trusted <span style="color:var(--yellow)">Professionals</span><br>Near You',
        sub   : 'Verified pros for every job—<br>home, tech, transport &amp; more.',
        cta   : 'Get Started',
        href  : 'hire.php'
    },
    {
        title : 'Ship &amp; Deliver<br><span style="color:var(--yellow)">Anything</span>, Anywhere',
        sub   : 'Fast, reliable transport services<br>at the best rates.',
        cta   : 'Get Started',
        href  : 'transport.php'
    }
];

let current      = 0;
let autoTimer    = null;
const slides     = document.querySelectorAll('.slide-bg');
const dots       = document.querySelectorAll('.dot');
const titleEl    = document.getElementById('hero-title');
const subEl      = document.getElementById('hero-sub');
const ctaEl      = document.getElementById('hero-cta');

function showBanner(i, skipFade) {
    // Crossfade images
    slides.forEach((s, idx) => s.classList.toggle('active', idx === i));
    dots.forEach((d, idx)   => d.classList.toggle('active', idx === i));

    if (skipFade) {
        titleEl.innerHTML = banners[i].title;
        subEl.innerHTML   = banners[i].sub;
        ctaEl.href        = banners[i].href;
    } else {
        // Fade text out, swap, fade back in
        titleEl.classList.add('fading');
        subEl.classList.add('fading');
        setTimeout(() => {
            titleEl.innerHTML = banners[i].title;
            subEl.innerHTML   = banners[i].sub;
            ctaEl.href        = banners[i].href;
            titleEl.classList.remove('fading');
            subEl.classList.remove('fading');
        }, 380);
    }
    current = i;
}

function startAuto() {
    clearInterval(autoTimer);
    autoTimer = setInterval(() => showBanner((current + 1) % banners.length), 7000);
}

// Dot click
dots.forEach(d => d.addEventListener('click', () => {
    showBanner(+d.dataset.i);
    startAuto(); // reset timer on manual click
}));

// Touch/swipe support
(function() {
    const banner = document.getElementById('hero-banner');
    let sx = 0;
    banner.addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true });
    banner.addEventListener('touchend',   e => {
        const dx = e.changedTouches[0].clientX - sx;
        if (Math.abs(dx) > 40) {
            const next = dx < 0
                ? (current + 1) % banners.length
                : (current - 1 + banners.length) % banners.length;
            showBanner(next);
            startAuto();
        }
    }, { passive: true });
})();

showBanner(0, true);
startAuto();



// ══ DEALFITY FAB ══════════════════════════════════════════
(function(){
var _open = false;
var _pages = {
    ai:       {name:'AI Assistant',  badge:'AI',      badgeColor:'#7B3FBE', badgeBg:'#F3EFFE', src:'ai.php'},
    messages: {name:'Messages',      badge:'Chat',    badgeColor:'#1A5FA8', badgeBg:'#E3EEF9', src:'messages.php'},
    support:  {name:'Support',       badge:'Help',    badgeColor:'#0D9488', badgeBg:'#E1F5EE', src:'support.php'},
};

window.dfabToggle = function(){
    _open = !_open;
    document.getElementById('dfab-wrap').classList.toggle('open',_open);
    document.getElementById('dfab-btn').classList.toggle('open',_open);
    document.getElementById('dfab-scrim').classList.toggle('open',_open);
};
window.dfabClose = function(){
    _open = false;
    document.getElementById('dfab-wrap').classList.remove('open');
    document.getElementById('dfab-btn').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
};
window.dfabOpen = function(type){
    dfabClose();
    var p = _pages[type];
    if(!p) return;
    document.getElementById('dfab-page-name').textContent = p.name;
    var badge = document.getElementById('dfab-page-badge');
    badge.textContent = p.badge;
    badge.style.background = p.badgeBg;
    badge.style.color = p.badgeColor;
    // Load iframe with ?panel=1 so the page hides its own nav/footer
    var iframe = document.getElementById('dfab-iframe');
    var panelSrc = p.src + (p.src.indexOf('?') === -1 ? '?panel=1' : '&panel=1');
    if(iframe.dataset.loaded !== panelSrc){
        iframe.src = panelSrc;
        iframe.dataset.loaded = panelSrc;
    }
    document.getElementById('dfab-menu').style.display = 'none';
    document.getElementById('dfab-page').classList.add('show');
    document.getElementById('dfab-panel').classList.add('open');
    document.getElementById('dfab-panel-scrim').classList.add('open');
};
window.dfabBack = function(){
    document.getElementById('dfab-menu').style.display = 'block';
    document.getElementById('dfab-page').classList.remove('show');
    document.getElementById('dfab-iframe').src = 'about:blank';
    document.getElementById('dfab-iframe').dataset.loaded = '';
    document.getElementById('dfab-panel-scrim').classList.remove('open');
};
window.dfabPanelClose = function(){
    document.getElementById('dfab-panel').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
    document.getElementById('dfab-panel-scrim').classList.remove('open');
    setTimeout(function(){
        document.getElementById('dfab-menu').style.display = 'block';
        document.getElementById('dfab-page').classList.remove('show');
        document.getElementById('dfab-iframe').src = 'about:blank';
        document.getElementById('dfab-iframe').dataset.loaded = '';
    }, 320);
};
document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){dfabClose();dfabPanelClose();}
});
})();
// ══ END DEALFITY FAB ══════════════════════════════════

// ══ LIVE NOTIFICATION BADGE POLLING ══════════════════════


