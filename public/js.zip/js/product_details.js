var IMAGES = <?= json_encode($images) ?>;
var currentIdx = 0;

function goToImg(idx) {
    currentIdx = idx;
    var mi = document.getElementById('main-img');
    if (mi) mi.src = IMAGES[idx];
    document.querySelectorAll('.thumb').forEach(function(t,i){ t.classList.toggle('active', i===idx); });
    document.querySelectorAll('.gdot').forEach(function(d,i){ d.classList.toggle('active', i===idx); });
    var pn = document.getElementById('photo-num');
    if (pn) pn.textContent = idx + 1;
}

// Touch swipe
(function(){
    var el = document.getElementById('gallery-main');
    if (!el || IMAGES.length < 2) return;
    var sx = 0;
    el.addEventListener('touchstart', function(e){ sx = e.touches[0].clientX; }, {passive:true});
    el.addEventListener('touchend', function(e){
        var dx = e.changedTouches[0].clientX - sx;
        if (Math.abs(dx) > 40) goToImg(dx < 0 ? (currentIdx+1)%IMAGES.length : (currentIdx-1+IMAGES.length)%IMAGES.length);
    }, {passive:true});
})();

// Lightbox functions
function openLightbox(idx){ currentIdx=idx; updateLb(); document.getElementById('lightbox').classList.add('open'); document.body.style.overflow='hidden'; }
function closeLightbox(){ document.getElementById('lightbox').classList.remove('open'); document.body.style.overflow=''; }
function lightboxNav(d){ currentIdx=(currentIdx+d+IMAGES.length)%IMAGES.length; updateLb(); }
function updateLb(){
    document.getElementById('lightbox-img').src = IMAGES[currentIdx];
    document.getElementById('lb-counter').textContent = (currentIdx+1)+' / '+IMAGES.length;
}
document.addEventListener('keydown', function(e){
    if (!document.getElementById('lightbox')?.classList.contains('open')) return;
    if (e.key==='Escape') closeLightbox();
    if (e.key==='ArrowLeft') lightboxNav(-1);
    if (e.key==='ArrowRight') lightboxNav(1);
});

// ── STAR PICKER ────────────────────────────────────────
function pickStar(val) {
    document.getElementById('r_stars').value = val;
    for (var i = 1; i <= 5; i++) {
        var svg = document.getElementById('star-svg-' + i);
        if (!svg) continue;
        var path = svg.querySelector('path');
        if (i <= val) {
            path.setAttribute('fill', '#F5A623');
            path.setAttribute('stroke', '#F5A623');
        } else {
            path.setAttribute('fill', '#E2E6EE');
            path.setAttribute('stroke', '#D0D4DC');
        }
    }
}

// Star hover effect
(function(){
    var picker = document.getElementById('star-picker');
    if (!picker) return;
    picker.addEventListener('mouseover', function(e) {
        var btn = e.target.closest('.star-btn');
        if (!btn) return;
        var hov = parseInt(btn.dataset.val);
        for (var i = 1; i <= 5; i++) {
            var svg = document.getElementById('star-svg-' + i);
            if (!svg) continue;
            var path = svg.querySelector('path');
            path.setAttribute('fill', i <= hov ? '#fbbf24' : '#E2E6EE');
            path.setAttribute('stroke', i <= hov ? '#fbbf24' : '#D0D4DC');
        }
    });
    picker.addEventListener('mouseleave', function() {
        var sel = parseInt(document.getElementById('r_stars').value) || 0;
        for (var i = 1; i <= 5; i++) {
            var svg = document.getElementById('star-svg-' + i);
            if (!svg) continue;
            var path = svg.querySelector('path');
            path.setAttribute('fill', i <= sel ? '#F5A623' : '#E2E6EE');
            path.setAttribute('stroke', i <= sel ? '#F5A623' : '#D0D4DC');
        }
    });
})();

// Review char counter
(function(){
    var ta = document.querySelector('textarea[name="r_text"]');
    var cc = document.getElementById('rev-char-count');
    if (ta && cc) {
        ta.addEventListener('input', function(){ cc.textContent = this.value.length; });
    }
})();
// ── END STAR PICKER ─────────────────────────────────────

// ══ SAFETY MODAL ═══════════════════════════════════════════
var _safetyTarget = null;
var _safetyType   = 'url';

function openSafetyModal(target, type) {
    _safetyTarget = target;
    _safetyType   = type || 'url';
    var btn = document.getElementById('safety-proceed-btn');
    var sub = document.querySelector('.safety-header-text p');
    if (type === 'tel') {
        if (btn) btn.textContent = '📞 Call Seller';
        if (sub) sub.textContent = 'Read before calling this seller';
    } else {
        if (btn) btn.textContent = 'Continue →';
        if (sub) sub.textContent = 'Please read before contacting this seller';
    }
    document.getElementById('safety-overlay').classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeSafetyModal() {
    document.getElementById('safety-overlay').classList.remove('open');
    document.body.style.overflow = '';
    _safetyTarget = null;
}
function proceedAfterSafety() {
    var target = _safetyTarget;
    var type   = _safetyType;
    closeSafetyModal();
    if (!target) return;
    if (type === 'tel') {
        window.location.href = target;
    } else {
        window.location.href = target;
    }
}
// ══ END SAFETY MODAL ════════════════════════════════════════

// Share
function shareItem(){
    var title = <?= json_encode($listing['title']) ?>;
    var price = 'KSh <?= number_format($listing['price']) ?>';
    if (navigator.share) {
        navigator.share({ title: title, text: 'Check out this listing on Dealfity \u2014 '+price, url: location.href }).catch(function(){});
    } else {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(location.href).then(function(){ showToast('Link copied!'); });
        } else { showToast('Copy: ' + location.href); }
    }
}

// Toast
function showToast(msg){
    var t = document.createElement('div');
    t.textContent = msg;
    Object.assign(t.style,{position:'fixed',bottom:'140px',left:'50%',transform:'translateX(-50%) translateY(10px)',background:'#18191F',color:'#fff',padding:'10px 20px',borderRadius:'50px',fontSize:'13px',fontWeight:'700',zIndex:'9999',opacity:'0',transition:'all .25s',whiteSpace:'nowrap',boxShadow:'0 4px 20px rgba(0,0,0,.3)'});
    document.body.appendChild(t);
    requestAnimationFrame(function(){ t.style.opacity='1'; t.style.transform='translateX(-50%) translateY(0)'; });
    setTimeout(function(){ t.style.opacity='0'; setTimeout(function(){ t.remove(); },300); },2500);
}

// ══ DEALFITY FAB ══════════════════════════════════════════
(function(){
var _open = false;
var _pages = {
    ai:       {name:'AI Assistant',  badge:'AI',      badgeColor:'#7B3FBE', badgeBg:'#F3EFFE', src:'ai.php'},
    messages: {name:'Messages',      badge:'Chat',    badgeColor:'#1A5FA8', badgeBg:'#E3EEF9', src:'messages.php'},
    support:  {name:'Support',       badge:'Help',    badgeColor:'#0D9488', badgeBg:'#E1F5EE', src:'support.php'},
};

window.dfabToggle = function(){
    _open = !_open;
    document.getElementById('dfab-wrap').classList.toggle('open',_open);
    document.getElementById('dfab-btn').classList.toggle('open',_open);
    document.getElementById('dfab-scrim').classList.toggle('open',_open);
};
window.dfabClose = function(){
    _open = false;
    document.getElementById('dfab-wrap').classList.remove('open');
    document.getElementById('dfab-btn').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
};
window.dfabOpen = function(type){
    dfabClose();
    var p = _pages[type];
    if(!p) return;
    document.getElementById('dfab-page-name').textContent = p.name;
    var badge = document.getElementById('dfab-page-badge');
    badge.textContent = p.badge;
    badge.style.background = p.badgeBg;
    badge.style.color = p.badgeColor;
    // Load iframe with ?panel=1 so the page hides its own nav/footer
    var iframe = document.getElementById('dfab-iframe');
    var panelSrc = p.src + (p.src.indexOf('?') === -1 ? '?panel=1' : '&panel=1');
    if(iframe.dataset.loaded !== panelSrc){
        iframe.src = panelSrc;
        iframe.dataset.loaded = panelSrc;
    }
    document.getElementById('dfab-menu').style.display = 'none';
    document.getElementById('dfab-page').classList.add('show');
    document.getElementById('dfab-panel').classList.add('open');
    document.getElementById('dfab-panel-scrim').classList.add('open');
};
window.dfabBack = function(){
    document.getElementById('dfab-menu').style.display = 'block';
    document.getElementById('dfab-page').classList.remove('show');
    document.getElementById('dfab-iframe').src = 'about:blank';
    document.getElementById('dfab-iframe').dataset.loaded = '';
    document.getElementById('dfab-panel-scrim').classList.remove('open');
};
window.dfabPanelClose = function(){
    document.getElementById('dfab-panel').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
    document.getElementById('dfab-panel-scrim').classList.remove('open');
    setTimeout(function(){
        document.getElementById('dfab-menu').style.display = 'block';
        document.getElementById('dfab-page').classList.remove('show');
        document.getElementById('dfab-iframe').src = 'about:blank';
        document.getElementById('dfab-iframe').dataset.loaded = '';
    }, 320);
};
document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){dfabClose();dfabPanelClose();}
});
})();

(function(){
var lastMsgId = <?= (int)$last_msg_id_init ?>;
var totalUnread = <?= (int)$unread_notif_count ?>;
function setAllBadges(count) {
    var tb = document.getElementById('topbar-notif-badge');
    if (tb) { tb.textContent = count > 99 ? '99+' : count; tb.style.display = count > 0 ? 'flex' : 'none'; }
    var fb = document.getElementById('fab-msg-badge');
    if (fb) { fb.textContent = count > 99 ? '99+' : count; fb.style.display = count > 0 ? 'flex' : 'none'; }
    var pb = document.getElementById('fab-panel-msg-badge');
    if (pb) { pb.textContent = count > 99 ? '99+' : count; pb.style.display = count > 0 ? 'inline-flex' : 'none'; }
    var btn = document.getElementById('dfab-btn');
    if (btn) { btn.style.boxShadow = count > 0 ? '0 4px 20px rgba(30,122,44,.45),0 0 0 4px rgba(217,64,64,.3)' : '0 4px 20px rgba(30,122,44,.45)'; }
}
function pollNotifications() {
    fetch('notifications.php?poll_messages=1&since=' + lastMsgId)
        .then(function(r){ return r.json(); })
        .then(function(d) {
            if (!d.messages || !d.messages.length) return;
            var n = d.messages.filter(function(m){ return m.id > lastMsgId; });
            if (!n.length) return;
            n.forEach(function(m){ if (m.id > lastMsgId) lastMsgId = m.id; });
            totalUnread += n.length;
            setAllBadges(totalUnread);
        }).catch(function(){});
}
setAllBadges(totalUnread);
setInterval(pollNotifications, 10000);
