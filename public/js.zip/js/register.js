async function registerUser() {
  let ok = true;

  const name = document.getElementById('name');
  const email = document.getElementById('email');
  const pw = document.getElementById('password');
  const cpw = document.getElementById('confirm_password');
  const phone = document.getElementById('phone');
  const terms = document.getElementById('terms');
  const age = document.getElementById('age');
  const marketing = document.getElementById('marketing');

  const errName = document.getElementById('err-name');
  const errEmail = document.getElementById('err-email');
  const errPw = document.getElementById('err-password');
  const errConfirm = document.getElementById('err-confirm');
  const errTerms = document.getElementById('err-terms');

  const errEmailMsg = document.getElementById('err-email-msg');
  const errPwMsg = document.getElementById('err-password-msg');
  const errConfirmMsg = document.getElementById('err-confirm-msg');
  const errTermsMsg = document.getElementById('err-terms-msg');

  [name, email, pw, cpw].forEach(el => el.classList.remove('invalid'));
  [errName, errEmail, errPw, errConfirm, errTerms].forEach(el => el.classList.remove('show'));

  if (!name.value.trim()) {
    name.classList.add('invalid');
    errName.classList.add('show');
    ok = false;
  }

  if (!email.value.trim()) {
    errEmailMsg.textContent = 'Email address is required.';
    email.classList.add('invalid');
    errEmail.classList.add('show');
    ok = false;
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
    errEmailMsg.textContent = 'Please enter a valid email address.';
    email.classList.add('invalid');
    errEmail.classList.add('show');
    ok = false;
  }

  if (!pw.value) {
    errPwMsg.textContent = 'Password is required (min. 6 characters).';
    pw.classList.add('invalid');
    errPw.classList.add('show');
    ok = false;
  } else if (pw.value.length < 6) {
    errPwMsg.textContent = 'Password must be at least 6 characters.';
    pw.classList.add('invalid');
    errPw.classList.add('show');
    ok = false;
  }

  if (!cpw.value) {
    errConfirmMsg.textContent = 'Please confirm your password.';
    cpw.classList.add('invalid');
    errConfirm.classList.add('show');
    ok = false;
  } else if (cpw.value !== pw.value) {
    errConfirmMsg.textContent = 'Passwords do not match.';
    cpw.classList.add('invalid');
    errConfirm.classList.add('show');
    ok = false;
  }

  if (!terms.checked || !age.checked) {
    errTermsMsg.textContent = !terms.checked
      ? 'You must agree to the Terms & Conditions.'
      : 'You must confirm you are at least 18 years old.';
    errTerms.classList.add('show');
    ok = false;
  }

  if (!ok) return;

  const spinner = document.getElementById('spinner');
  const btnText = document.getElementById('btnText');
  const btnArrow = document.getElementById('btnArrow');
  const submitBtn = document.getElementById('submitBtn');

  spinner.style.display = 'inline-block';
  btnText.textContent = 'Creating account…';
  btnArrow.style.display = 'none';
  submitBtn.disabled = true;

  try {
    const res = await fetch('/register_user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: name.value.trim(),
        email: email.value.trim(),
        password: pw.value,
        phone: phone.value.trim(),
        terms: terms.checked,
        age: age.checked,
        marketing: marketing.checked
      })
    });

    const data = await res.json();

    if (res.ok && data.success) {
      window.location.href = '/login';
      return;
    }

    if (data.error) alert(data.error);

  } catch (err) {
    console.error(err);
    alert('Server error');
  } finally {
    spinner.style.display = 'none';
    btnText.textContent = 'Create My Free Account';
    btnArrow.style.display = 'inline';
    submitBtn.disabled = false;
  }
}

function togglePw(inputId, iconId) {
  const inp = document.getElementById(inputId);
  const ico = document.getElementById(iconId);
  const show = inp.type === 'password';
  inp.type = show ? 'text' : 'password';
  ico.innerHTML = show
    ? '<path stroke-linecap="round" stroke-linejoin="round" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>'
    : '<path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>';
}

function checkStrength(pw) {
  const fill = document.getElementById('strength-fill');
  const text = document.getElementById('strength-text');

  let score = 0;
  if (pw.length >= 6) score++;
  if (pw.length >= 10) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;

  const levels = [
    ['0%', '', ''],
    ['25%', '#ef4444', 'Weak password'],
    ['50%', '#f59e0b', 'Fair — add numbers or symbols'],
    ['75%', '#3b82f6', 'Good password'],
    ['100%', '#c9920a', '✓ Strong password']
  ];

  const l = levels[Math.min(score, 4)];
  fill.style.width = pw.length ? l[0] : '0%';
  fill.style.background = l[1];
  text.textContent = pw.length ? l[2] : '';
  text.style.color = l[1] || '#6b7280';
}

document.querySelectorAll('input[type=email], input[type=password], input[type=text], input[type=tel]').forEach(inp => {
  inp.addEventListener('focus', () => {
    const ic = inp.closest('.iwrap')?.querySelector('.iicon');
    if (ic) ic.style.color = '#c9920a';
  });

  inp.addEventListener('blur', () => {
    const ic = inp.closest('.iwrap')?.querySelector('.iicon');
    if (ic) ic.style.color = '#b8c0cc';
  });
});
