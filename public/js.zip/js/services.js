async function loadServices() {
    const container = document.getElementById('services-list');
    container.innerHTML = 'Loading...';

    try {
        // Fetch services from your Express API
        const res = await fetch('/api/services');
        if (!res.ok) throw new Error('Failed to fetch services');
        const services = await res.json();

        container.innerHTML = '';

        if (!services.length) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">🔍</div>
                    <p>No services found.<br>Try a different search or category.</p>
                </div>
            `;
            return;
        }

        const accentColors = ['green','yellow','blue','purple','red','teal','green','blue'];
        const btnAlts = [false, true, false, false, true, false, false, true];

        services.forEach((svc, idx) => {
            const accent = accentColors[idx % accentColors.length];
            const altBtn = btnAlts[idx % btnAlts.length];
            const thumb = svc.thumb || svc.image || '';
            const icon = svc.icon || '🔧';
            const loggedIn = svc.logged_in || false; // set this from session if available
            const link = loggedIn ? (svc.id ? `/service_detail/${svc.id}` : '#') : '/login';
            const isBiz = svc.account_type === 'business';
            const rateLbl = svc.rate_type || '';
            const price = Number(svc.price || 0).toLocaleString();

            // Create card
            const card = document.createElement('a');
            card.href = link;
            card.className = `svc-card accent-${accent}`;
            card.innerHTML = `
                <div class="svc-thumb">
                    ${thumb ? `<img src="${thumb}" alt="" loading="lazy"/>` : icon}
                </div>
                <div class="svc-body">
                    <div class="svc-title-row">
                        <span class="svc-title">${svc.title}</span>
                        ${isBiz ? `<span class="biz-badge">🏪 Business</span>` : ''}
                    </div>
                    <div class="svc-seller">👤 ${svc.seller_name || ''}</div>
                    <div class="svc-desc">${svc.description || ''}</div>
                    ${rateLbl ? `<span class="rate-chip">⏱️ ${rateLbl}</span>` : ''}
                </div>
                <div class="svc-right">
                    <div class="svc-price">
                        <div class="from-label">From</div>
                        <div class="amount">KSh ${price}</div>
                    </div>
                    <span class="book-btn ${altBtn ? 'yellow' : ''}" onclick="event.preventDefault();event.stopPropagation();location.href='${link}'">
                        Book Now
                    </span>
                </div>
            `;
            container.appendChild(card);
        });

    } catch (err) {
        container.innerHTML = `<p style="color:red;">Error loading services: ${err.message}</p>`;
        console.error(err);
    }
}

// Initial load
loadServices();


//render categories
async function loadCategories(selectedCat = '', searchQuery = '') {
    const container = document.getElementById('cat-grid');
    container.innerHTML = 'Loading...';

    try {
        const res = await fetch('/services/categories');
        if (!res.ok) throw new Error('Failed to fetch categories');

        const { categories } = await res.json();
        container.innerHTML = '';

        if (!categories.length) {
            container.innerHTML = '<p>No categories found</p>';
            return;
        }

        // Map category keys → Lucide icons (Cloudflare style)
        const iconMap = {
            home: "wrench",
            skilled: "hard-hat",
            transport: "truck",
            tech: "cpu",
            beauty: "heart",
            tutoring: "graduation-cap",
            business: "briefcase",
            "": "grid" // "More"
        };

        categories.forEach(cat => {
            const selected = (selectedCat === cat.key && cat.key) ? 'selected' : '';
            const iconName = iconMap[cat.key] || 'circle';

            let link = `/services?cat=${encodeURIComponent(cat.key)}`;
            if (searchQuery) {
                link += `&q=${encodeURIComponent(searchQuery)}`;
            }

            const card = document.createElement('a');
            card.href = link;
            card.className = `cat-item ${cat.color} ${selected}`;

            card.innerHTML = `
                <span class="cat-icon" >
                    <i data-lucide="${iconName}" color="grey"></i>
                </span>
                <span class="cat-label" style="color:grey;">${cat.label}</span>
            `;

            container.appendChild(card);
        });

        // Render Lucide icons
        if (window.lucide) {
            lucide.createIcons();
        }

    } catch (err) {
        container.innerHTML = `<p style="color:red;">Error: ${err.message}</p>`;
        console.error(err);
    }
}

// Load on page
loadCategories();


// ── Search: Enter key OR icon click ──────────────────────────────────────
function doSearch() {
    const q = document.getElementById('svc-search').value.trim();
    if (q) location.href = 'services.php?q=' + encodeURIComponent(q)
                         + '<?= $filter_cat ? "&cat=".urlencode($filter_cat) : "" ?>';
}
document.getElementById('svc-search').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });
document.getElementById('search-icon-btn').addEventListener('click', doSearch);

// ── Remove individual active filter pill ──────────────────────────────────
function removeFilter(key) {
    const url = new URL(location.href);
    url.searchParams.delete(key);
    location.href = url.toString();
}

// ── Filter modal open / close ──────────────────────────────────────────
const overlay  = document.getElementById('filter-modal');
const openBtn  = document.getElementById('filter-open-btn');
const applyBtn = document.getElementById('filter-apply-btn');
const resetBtn = document.getElementById('filter-reset-btn');

openBtn.addEventListener('click', () => overlay.classList.add('open'));
overlay.addEventListener('click', e => { if (e.target === overlay) overlay.classList.remove('open'); });

// Single-select within each chip group
document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', function() {
        this.closest('.filter-chips').querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
        this.classList.toggle('active');
    });
});

// FIX: Apply now includes cat, price, AND search query
applyBtn.addEventListener('click', () => {
    const catChip   = document.querySelector('#filter-cat-chips .chip.active');
    const priceChip = document.querySelector('#filter-price-chips .chip.active');
    const q = document.getElementById('svc-search').value.trim();

    const params = new URLSearchParams();
    if (catChip)   params.set('cat',   catChip.dataset.cat);
    if (priceChip) params.set('price', priceChip.dataset.price);
    if (q)         params.set('q',     q);
    location.href = 'services.php?' + params.toString();
});

// FIX: Reset clears everything
resetBtn.addEventListener('click', () => { location.href = 'services.php'; });


// ── SERVICES MENU ────────────────────────────────
function toggleSvcMenu(){
    var popup=document.getElementById('svc-popup');
    var scrim=document.getElementById('svc-scrim');
    var btn=document.querySelector('.bnav-svc-btn');
    if(!popup||!scrim)return;
    var open=popup.classList.contains('open');
    popup.classList.toggle('open',!open);
    scrim.classList.toggle('open',!open);
    if(btn)btn.classList.toggle('menu-open',!open);
}
function closeSvcMenu(){
    var popup=document.getElementById('svc-popup');
    var scrim=document.getElementById('svc-scrim');
    if(popup)popup.classList.remove('open');
    if(scrim)scrim.classList.remove('open');
    document.querySelectorAll('.bnav-svc-btn').forEach(function(b){b.classList.remove('menu-open');});
}
document.addEventListener('keydown',function(e){if(e.key==='Escape')closeSvcMenu();});
// ── END SERVICES MENU ─────────────────────────────

// ══ DEALFITY FAB ══════════════════════════════════════════
(function(){
var _open = false;
var _pages = {
    ai:       {name:'AI Assistant',  badge:'AI',      badgeColor:'#7B3FBE', badgeBg:'#F3EFFE', src:'ai.php'},
    messages: {name:'Messages',      badge:'Chat',    badgeColor:'#1A5FA8', badgeBg:'#E3EEF9', src:'messages.php'},
    support:  {name:'Support',       badge:'Help',    badgeColor:'#0D9488', badgeBg:'#E1F5EE', src:'support.php'},
};

window.dfabToggle = function(){
    _open = !_open;
    document.getElementById('dfab-wrap').classList.toggle('open',_open);
    document.getElementById('dfab-btn').classList.toggle('open',_open);
    document.getElementById('dfab-scrim').classList.toggle('open',_open);
};
window.dfabClose = function(){
    _open = false;
    document.getElementById('dfab-wrap').classList.remove('open');
    document.getElementById('dfab-btn').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
};
window.dfabOpen = function(type){
    dfabClose();
    var p = _pages[type];
    if(!p) return;
    document.getElementById('dfab-page-name').textContent = p.name;
    var badge = document.getElementById('dfab-page-badge');
    badge.textContent = p.badge;
    badge.style.background = p.badgeBg;
    badge.style.color = p.badgeColor;
    // Load iframe with ?panel=1 so the page hides its own nav/footer
    var iframe = document.getElementById('dfab-iframe');
    var panelSrc = p.src + (p.src.indexOf('?') === -1 ? '?panel=1' : '&panel=1');
    if(iframe.dataset.loaded !== panelSrc){
        iframe.src = panelSrc;
        iframe.dataset.loaded = panelSrc;
    }
    document.getElementById('dfab-menu').style.display = 'none';
    document.getElementById('dfab-page').classList.add('show');
    document.getElementById('dfab-panel').classList.add('open');
    document.getElementById('dfab-panel-scrim').classList.add('open');
};
window.dfabBack = function(){
    document.getElementById('dfab-menu').style.display = 'block';
    document.getElementById('dfab-page').classList.remove('show');
    document.getElementById('dfab-iframe').src = 'about:blank';
    document.getElementById('dfab-iframe').dataset.loaded = '';
    document.getElementById('dfab-panel-scrim').classList.remove('open');
};
window.dfabPanelClose = function(){
    document.getElementById('dfab-panel').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
    document.getElementById('dfab-panel-scrim').classList.remove('open');
    setTimeout(function(){
        document.getElementById('dfab-menu').style.display = 'block';
        document.getElementById('dfab-page').classList.remove('show');
        document.getElementById('dfab-iframe').src = 'about:blank';
        document.getElementById('dfab-iframe').dataset.loaded = '';
    }, 320);
};
document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){dfabClose();dfabPanelClose();}
});
})();
// ══ END DEALFITY FAB ══════════════════════════════════════
