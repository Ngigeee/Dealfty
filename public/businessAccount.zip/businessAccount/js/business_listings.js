let curView = localStorage.getItem('biz-lv') || 'grid';
setView(curView, false);

function setView(v, save=true) {
    curView = v;
    document.getElementById('view-grid').style.display = v==='grid' ? '' : 'none';
    document.getElementById('view-list').style.display = v==='list' ? '' : 'none';
    document.getElementById('vt-g').classList.toggle('on', v==='grid');
    document.getElementById('vt-l').classList.toggle('on', v==='list');
    if (save) localStorage.setItem('biz-lv', v);
}

function liveFilter(q) {
    q = q.toLowerCase();
    document.querySelectorAll('[data-title]').forEach(el => {
        el.style.display = el.dataset.title.includes(q) ? '' : 'none';
    });
}
