// ── ORDER DETAIL MODAL ────────────────────────
function showOrderDetail(o) {
    const ts = new Date(o.created_at).toLocaleString('en-KE',{dateStyle:'medium',timeStyle:'short'});
    document.getElementById('modal-title').textContent = 'Order #' + String(o.id).padStart(4,'0');
    document.getElementById('modal-body').innerHTML = `
        <div class="modal-row"><span class="modal-row-lbl">Product</span><span class="modal-row-val">${esc(o.listing_title)}</span></div>
        <div class="modal-row"><span class="modal-row-lbl">Buyer</span><span class="modal-row-val">${esc(o.buyer_name)}</span></div>
        ${o.buyer_phone ? `<div class="modal-row"><span class="modal-row-lbl">Phone</span><span class="modal-row-val">${esc(o.buyer_phone)}</span></div>` : ''}
        <div class="modal-row"><span class="modal-row-lbl">Amount</span><span class="modal-row-val" style="color:var(--green-dark);font-size:16px">KSh ${parseFloat(o.total_amount).toLocaleString('en-KE',{minimumFractionDigits:2})}</span></div>
        <div class="modal-row"><span class="modal-row-lbl">Status</span><span class="modal-row-val">${o.status.charAt(0).toUpperCase()+o.status.slice(1)}</span></div>
        <div class="modal-row"><span class="modal-row-lbl">Ordered</span><span class="modal-row-val">${ts}</span></div>
        <div style="margin-top:18px;display:flex;gap:8px;flex-wrap:wrap">
            <a href="business_listing_detail.php?id=${o.listing_id}" class="biz-btn biz-btn-outline biz-btn-sm">📦 View Listing</a>
            <a href="business_chat.php?user=${o.buyer_id}&listing=${o.listing_id}" class="biz-btn biz-btn-green biz-btn-sm">💬 Message Buyer</a>
        </div>
    `;
    document.getElementById('order-modal').classList.add('open');
}
function closeModal() { document.getElementById('order-modal').classList.remove('open'); }
document.addEventListener('keydown', e => { if(e.key==='Escape') closeModal(); });

// ── STATUS UPDATE ─────────────────────────────
function updateOrder(orderId, action, btn) {
    const label = {confirm:'Confirm',ship:'Ship',complete:'Complete',cancel:'Cancel'}[action];
    if (!confirm('Are you sure you want to ' + label.toLowerCase() + ' this order?')) return;

    btn.disabled = true;
    btn.textContent = '…';

    const fd = new FormData();
    fd.append('action', action);
    fd.append('order_id', orderId);

    fetch('business_orders.php', {
        method: 'POST',
        headers: {'X-Requested-With':'XMLHttpRequest'},
        body: fd
    })
    .then(r => r.json())
    .then(data => {
        if (data.ok) {
            // Reload to reflect new state
            location.reload();
        } else {
            btn.disabled = false;
            btn.textContent = label;
            alert('Could not update order. Please try again.');
        }
    })
    .catch(() => location.reload());
}

function esc(t){ const d=document.createElement('div');d.textContent=t;return d.innerHTML; }
