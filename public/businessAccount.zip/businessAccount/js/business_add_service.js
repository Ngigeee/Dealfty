// ── CATEGORY ────────────────────────────────────
function pickCat(val, el) {
    document.querySelectorAll('.cat-opt').forEach(o=>o.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('cat-h').value = val;
    document.getElementById('cat-hint').classList.remove('show');
    const emoji = el.querySelector('.c-emoji').textContent;
    const name  = el.querySelector('.c-name').textContent;
    document.getElementById('pv-cat').innerHTML = `<span class="prev-cat-pill">${emoji} ${esc(name)}</span>`;
    stepMark(2,'done'); stepSync();
}

// ── RATE TYPE ────────────────────────────────────
function pickRT(val, el) {
    document.querySelectorAll('.rt-pill').forEach(o=>o.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('rt-h').value = val;
    document.getElementById('pv-rt').textContent = val;
    stepSync();
}

// ── NEGOTIABLE ───────────────────────────────────
function togNeg() {
    const c = document.getElementById('neg-chk');
    c.checked = !c.checked;
    document.getElementById('neg-tog').classList.toggle('on', c.checked);
}

// ── PHONE CONSENT ────────────────────────────────
function toggleSvcConsent() {
    const wrap    = document.getElementById('svc-consent-wrap');
    const hidden  = document.getElementById('svc-phone-consent-hidden');
    const body    = document.getElementById('svc-consent-body');
    const chevron = document.getElementById('svc-consent-chevron');
    const isOn    = wrap.classList.toggle('checked');
    hidden.value  = isOn ? '1' : '';
    // Expand details when checked
    if (body) body.style.display = isOn ? 'block' : 'none';
    if (chevron) chevron.style.transform = isOn ? 'rotate(180deg)' : '';
    updatePhonePreview();
    stepSync();
}

function clearPhone() {
    const inp = document.getElementById('svc-phone-inp');
    inp.value = '';
    document.getElementById('svc-phone-clear').style.display = 'none';
    updatePhonePreview();
}

function updatePhonePreview() {
    const phone   = document.getElementById('svc-phone-inp').value.trim();
    const consent = document.getElementById('svc-phone-consent-hidden').value === '1';
    const preview = document.getElementById('svc-phone-preview');
    const numEl   = document.getElementById('svc-phone-preview-num');
    const clearBtn = document.getElementById('svc-phone-clear');
    // Show/hide clear button
    if (clearBtn) clearBtn.style.display = phone ? 'flex' : 'none';
    // Show/hide preview
    if (phone && consent) {
        numEl.textContent = phone;
        preview.classList.add('visible');
    } else {
        preview.classList.remove('visible');
    }
    stepSync();
}

// On page load — restore consent body state if checked
(function(){
    const wrap = document.getElementById('svc-consent-wrap');
    const body = document.getElementById('svc-consent-body');
    const chevron = document.getElementById('svc-consent-chevron');
    if (wrap && wrap.classList.contains('checked')) {
        if (body) body.style.display = 'block';
        if (chevron) chevron.style.transform = 'rotate(180deg)';
    }
})();


// ── LIVE PREVIEW ─────────────────────────────────
function updatePrev() {
    const title = document.getElementById('t-inp').value.trim();
    const rate  = parseFloat(document.getElementById('r-inp').value)||0;
    const rt    = document.getElementById('rt-h').value;
    document.getElementById('pv-title').innerHTML = title
        ? `<strong>${esc(title)}</strong>`
        : `<span class="prev-empty">Your title will appear here…</span>`;
    document.getElementById('pv-price').textContent = rate > 0 ? 'KSh ' + rate.toLocaleString('en-KE') : 'KSh —';
    document.getElementById('pv-rt').textContent = rt || '';
    stepSync();
}

// ── STEP INDICATORS ──────────────────────────────
function stepMark(n, state) {
    const el = document.getElementById('si-'+n);
    if (el) el.className = 'step-item ' + state;
}
function stepSync() {
    const t = document.getElementById('t-inp').value.trim();
    const d = document.getElementById('d-inp').value.trim();
    const c = document.getElementById('cat-h').value;
    const r = document.getElementById('r-inp').value;
    const rt= document.getElementById('rt-h').value;
    const hasPhoto = document.getElementById('photo-drop').classList.contains('has-photo');
    const hasPhone = (document.getElementById('svc-phone-inp').value.trim() && document.getElementById('svc-phone-consent-hidden').value === '1');
    stepMark(1, t&&d ? 'done' : 'active');
    stepMark(2, c   ? 'done' : (t&&d?'active':'pending'));
    stepMark(3, (r||rt) ? 'done' : (c?'active':'pending'));
    stepMark(4, hasPhoto ? 'done' : ((r||rt)?'active':'pending'));
    stepMark(5, hasPhone ? 'done' : (hasPhoto?'active':'pending'));
    stepMark(6, (t&&d&&c) ? 'active' : 'pending');
}

// ── CHAR COUNTERS ────────────────────────────────
function initCounter(inpId, cntId, max) {
    const inp = document.getElementById(inpId);
    const cnt = document.getElementById(cntId);
    if (!inp||!cnt) return;
    function upd() {
        const n = inp.value.length;
        cnt.textContent = n + ' / ' + max;
        cnt.style.color = n > max*.9 ? 'var(--red)' : 'var(--text-3)';
    }
    inp.addEventListener('input', ()=>{upd();updatePrev();});
    upd();
}
initCounter('t-inp','tc',100);
initCounter('d-inp','dc',1000);

document.getElementById('d-inp').addEventListener('input', function(){
    this.style.height='auto';
    this.style.height=Math.min(this.scrollHeight,300)+'px';
});

// ── FORM VALIDATION ──────────────────────────────
document.getElementById('svc-form').addEventListener('submit', function(e) {
    const t = document.getElementById('t-inp').value.trim();
    const d = document.getElementById('d-inp').value.trim();
    const c = document.getElementById('cat-h').value;
    if (!t) { e.preventDefault(); alert('Please enter a service title.'); document.getElementById('t-inp').focus(); return; }
    if (!d) { e.preventDefault(); alert('Please add a description.'); document.getElementById('d-inp').focus(); return; }
    if (!c) { e.preventDefault(); alert('Please select a category.'); document.getElementById('cat-grid').scrollIntoView({behavior:'smooth',block:'center'}); return; }
    const btn = this.querySelector('.pub-btn');
    btn.innerHTML = '⏳ Publishing…'; btn.disabled = true;
});

function esc(t){const d=document.createElement('div');d.textContent=t;return d.innerHTML;}

// ── SERVICE PHOTO UPLOAD ─────────────────────────────
function handlePhotoSelect(input) {
    if (!input.files || !input.files[0]) return;
    const file = input.files[0];
    const reader = new FileReader();
    reader.onload = function(e) {
        document.getElementById('preview-img').src = e.target.result;
        document.getElementById('photo-preview').style.display = 'block';
        document.getElementById('photo-placeholder').style.display = 'none';
        document.getElementById('photo-drop').classList.add('has-photo');
        // Sidebar preview
        document.getElementById('pv-photo-img').src = e.target.result;
        document.getElementById('pv-photo-img').style.display = 'block';
        document.getElementById('pv-photo-empty').style.display = 'none';
        stepMark(4, 'done'); stepSync();
    };
    reader.readAsDataURL(file);
}
function removePhoto() {
    document.getElementById('svc-photo-inp').value = '';
    document.getElementById('preview-img').src = '';
    document.getElementById('photo-preview').style.display = 'none';
    document.getElementById('photo-placeholder').style.display = 'flex';
    document.getElementById('photo-drop').classList.remove('has-photo');
    // Sidebar preview
    document.getElementById('pv-photo-img').src = '';
    document.getElementById('pv-photo-img').style.display = 'none';
    document.getElementById('pv-photo-empty').style.display = 'inline';
    stepMark(4, 'active'); stepSync();
}
// Drag-and-drop support
(function(){
    const drop = document.getElementById('photo-drop');
    if (!drop) return;
    drop.addEventListener('dragover', function(e){ e.preventDefault(); drop.style.borderColor='var(--green)'; drop.style.background='var(--green-light)'; });
    drop.addEventListener('dragleave', function(){ drop.style.borderColor=''; drop.style.background=''; });
    drop.addEventListener('drop', function(e){
        e.preventDefault();
        drop.style.borderColor=''; drop.style.background='';
        const files = e.dataTransfer.files;
        if (files && files[0]) {
            const inp = document.getElementById('svc-photo-inp');
            // Create a DataTransfer to assign dropped file to input
            const dt = new DataTransfer();
            dt.items.add(files[0]);
            inp.files = dt.files;
            handlePhotoSelect(inp);
        }
    });
})();

// ── INIT ─────────────────────────────────────────
(function(){
    const selVal = <?=json_encode($sel_cat)?>;
    document.querySelectorAll('.cat-opt').forEach(o=>{
        if(o.querySelector('.c-name')?.textContent.trim()===selVal){
            const emoji=o.querySelector('.c-emoji').textContent;
            document.getElementById('pv-cat').innerHTML=`<span class="prev-cat-pill">${emoji} ${esc(selVal)}</span>`;
        }
    });
})();

updatePrev();
