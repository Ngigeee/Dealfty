document.getElementById('msg-search')?.addEventListener('input',function(){
    const q = this.value.toLowerCase().trim();
    document.querySelectorAll('.conv-card').forEach(el=>{
        const name    = el.dataset.name    || el.querySelector('.conv-name')?.textContent.toLowerCase()    || '';
        const item    = el.dataset.item    || '';
        const preview = el.querySelector('.conv-preview')?.textContent.toLowerCase() || '';
        el.style.display = (!q || name.includes(q) || item.includes(q) || preview.includes(q)) ? '' : 'none';
    });
});

// Auto-refresh every 20 seconds
let _refreshTimer = setInterval(function(){
    location.reload();
}, 20000);
document.addEventListener('click', function(){ clearInterval(_refreshTimer); });
