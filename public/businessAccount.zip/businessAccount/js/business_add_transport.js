function selV(val, el) {
    document.querySelectorAll('.v-card').forEach(o => o.classList.remove('on'));
    el.classList.add('on');
    document.getElementById('v-h').value = val;
    const h = document.getElementById('v-hint'); if (h) h.style.display = 'none';
    updSteps();
}
function selS(val, el) {
    document.querySelectorAll('.s-card').forEach(o => o.classList.remove('on'));
    el.classList.add('on');
    document.getElementById('s-h').value = val;
    updSteps();
}
function selA(val, el) {
    document.querySelectorAll('.av-card').forEach(o => o.classList.remove('on'));
    el.classList.add('on');
    el.querySelector('input').checked = true;
}
function tgNeg() {
    const c = document.getElementById('neg-chk');
    const r = document.getElementById('neg-row');
    c.checked = !c.checked;
    r.classList.toggle('on', c.checked);
}
function updSteps() {
    const hv = !!document.getElementById('v-h').value;
    const hs = !!document.getElementById('s-h').value;
    const b = document.querySelectorAll('.step-bubble');
    const l = document.querySelectorAll('.step-line');
    if (b.length < 5) return;
    b[0].className = 'step-bubble ' + (hv ? 'done' : 'active');
    if (l[0]) l[0].className = 'step-line ' + (hv ? 'done' : '');
    b[1].className = 'step-bubble ' + (hs ? 'done' : (hv ? 'active' : ''));
    if (l[1]) l[1].className = 'step-line ' + (hs ? 'done' : '');
    b[2].className = 'step-bubble ' + (hs ? 'active' : '');
}
document.getElementById('tp-form').addEventListener('submit', function(e) {
    if (!document.getElementById('v-h').value) {
        e.preventDefault(); alert('⚠️ Please select your vehicle type (Step 1).');
        document.querySelector('.v-grid').scrollIntoView({behavior:'smooth',block:'center'}); return;
    }
    if (!document.getElementById('s-h').value) {
        e.preventDefault(); alert('⚠️ Please select what service you offer (Step 2).');
        document.querySelector('.s-grid').scrollIntoView({behavior:'smooth',block:'center'}); return;
    }
    const t=this.querySelector('[name=title]').value.trim();
    const d=this.querySelector('[name=description]').value.trim();
    const l=this.querySelector('[name=location]').value.trim();
    const p=this.querySelector('[name=phone]').value.trim();
    if (!t){e.preventDefault();alert('⚠️ Please enter a listing title (Step 3).');return;}
    if (!d){e.preventDefault();alert('⚠️ Please add a description (Step 3).');return;}
    if (!l){e.preventDefault();alert('⚠️ Please enter areas you cover (Step 3).');return;}
    if (!p){e.preventDefault();alert('⚠️ Please enter your phone number (Step 5).');return;}
});
updSteps();
