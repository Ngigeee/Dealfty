// ── TOGGLE SWITCHES ───────────────────────────
function togSwitch(el, key) {
    const isOn = el.classList.toggle('on');
    const chk  = document.getElementById('chk-' + key);
    if (chk) chk.checked = isOn;
}

// ── PASSWORD STRENGTH ─────────────────────────
function checkStrength(pw) {
    const bar  = document.getElementById('pw-bar');
    const hint = document.getElementById('pw-hint');
    if (!bar) return;
    let score = 0;
    if (pw.length >= 8)  score++;
    if (pw.length >= 12) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;

    const levels = [
        [0,   '#e5e7eb', 'Too short'],
        [20,  '#EF4444', 'Very weak'],
        [40,  '#F59E0B', 'Weak'],
        [60,  '#F5A623', 'Fair'],
        [80,  '#22C55E', 'Strong'],
        [100, '#16A34A', 'Very strong 🔒'],
    ];
    const [pct, color, label] = levels[Math.min(score, levels.length-1)];
    bar.style.width    = pct + '%';
    bar.style.background = color;
    hint.textContent   = label;
    hint.style.color   = color;
}
