async function fillDashboardCards(url) {
  const res = await fetch(url);
  const data = await res.json();
  return data;
}

async function renderCards(container) {
  if (!container) return console.log("no container provided");

  container.innerHTML = "";

  const data = await fillDashboardCards("/business/get_dashboard_cards");

  if (!data) return console.log("error loading data");

  container.innerHTML = `
    <div class="stat-card sc-yellow anim a1">
      <div class="stat-bg-emoji">💰</div>
      <div class="stat-icon-wrap si-yellow">💰</div>
      <div class="stat-value">KSh ${data.revenue_count}</div>
      <div class="stat-label">Total Revenue</div>
      <span class="stat-badge sb-up">Lifetime</span>
    </div>

    <div class="stat-card sc-green anim a2">
      <div class="stat-bg-emoji">📦</div>
      <div class="stat-icon-wrap si-green">📦</div>
      <div class="stat-value">${data.listing_count}</div>
      <div class="stat-label">Active Listings</div>
      <span class="stat-badge sb-info">${data.listing_count} total</span>
    </div>

    <div class="stat-card sc-blue anim a3">
      <div class="stat-bg-emoji">🛒</div>
      <div class="stat-icon-wrap si-blue">🛒</div>
      <div class="stat-value">${data.orders_count}</div>
      <div class="stat-label">Orders Received</div>
      <span class="stat-badge sb-warn">${data.orders_count} orders</span>
    </div>

    <div class="stat-card sc-teal anim a4">
      <div class="stat-bg-emoji">💬</div>
      <div class="stat-icon-wrap si-teal">💬</div>
      <div class="stat-value">${data.messages_count}</div>
      <div class="stat-label">Unread Messages</div>
      <span class="stat-badge sb-new">${data.messages_count} messages</span>
    </div>
  `;
}

const cardContainer = document.getElementById("stats-result");
renderCards(cardContainer);
//update the messages to read


const chatLink = document.getElementById("chatLink");

const chatLink = document.getElementById("chatLink");

console.log("[INIT] chat script loaded");
console.log("[INIT] chatLink:", chatLink);

if (!chatLink) {
  console.warn("[WARN] chatLink not found in DOM");
}

if (chatLink) {
  chatLink.addEventListener("click", async (e) => {
    e.preventDefault();

    console.log("[CLICK] chat clicked");

    const otherUserId = chatLink.dataset.user;
    const listingId = chatLink.dataset.listing;
    const url = chatLink.href;

    console.log("[DATA] otherUserId:", otherUserId);
    console.log("[DATA] listingId:", listingId);
    console.log("[DATA] url:", url);

    try {
      console.log("[REQUEST] sending mark-read request...");

      const res = await fetch("/mark-read", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          otherUserId,
          listingId
        })
      });

      console.log("[RESPONSE] status:", res.status);

      const data = await res.json().catch(() => null);
      console.log("[RESPONSE] body:", data);

    } catch (err) {
      console.error("[ERROR] fetch failed:", err);
    }

    console.log("[REDIRECT] going to:", url);
    window.location.href = url;
  });
}
