
async function loginUser(email, password) {
  const emailEl = document.getElementById('email');
  const pwEl = document.getElementById('password');
  const eErr = document.getElementById('err-email');
  const pErr = document.getElementById('err-password');
  const eMsg = document.getElementById('err-email-msg');

  let ok = true;

  // Reset error states
  emailEl.classList.remove('invalid'); eErr.classList.remove('show');
  pwEl.classList.remove('invalid'); pErr.classList.remove('show');

  // Validation
  if (!email) {
    eMsg.textContent = 'Please enter your email address.';
    emailEl.classList.add('invalid'); eErr.classList.add('show'); ok = false;
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    eMsg.textContent = 'Please enter a valid email address.';
    emailEl.classList.add('invalid'); eErr.classList.add('show'); ok = false;
  }

  if (!password) {
    pwEl.classList.add('invalid'); pErr.classList.add('show'); ok = false;
  }

  if (!ok) return { error: 'Please fill all required fields correctly.' };

  // Show spinner
  document.getElementById('spinner').style.display = 'inline-block';
  document.getElementById('btnText').textContent = 'Signing in…';
  document.getElementById('loginBtn').disabled = true;

  try {
    const res = await fetch('/business/login_user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    // Hide spinner
    document.getElementById('spinner').style.display = 'none';
    document.getElementById('btnText').textContent = 'Log In';
    document.getElementById('loginBtn').disabled = false;

    return data;

  } catch (err) {
    console.error(err);
    document.getElementById('spinner').style.display = 'none';
    document.getElementById('btnText').textContent = 'Log In';
    document.getElementById('loginBtn').disabled = false;

    return { error: 'Server error. Try again later.' };
  }
}

async function handleLogin() {
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const alertDiv = document.querySelector('.alert');

  alertDiv.style.display = 'none';

  const result = await loginUser(email, password);

  if (result.error) {
    alertDiv.textContent = result.error;
    alertDiv.style.display = 'block';
    alertDiv.style.color = 'red';
  } else {
    // success, redirect
    window.location.href = '/business/dashboard';
  }
}

function togglePw() {
  const inp = document.getElementById('password');
  const ico = document.getElementById('eye-icon');
  const show = inp.type === 'password';
  inp.type = show ? 'text' : 'password';
}
