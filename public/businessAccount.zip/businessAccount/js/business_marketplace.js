// ── Filter drawer ─────────────────────────────────────────────────────────────
var _fCat='<?=htmlspecialchars($filter_cat,ENT_QUOTES)?>',
    _fPrice='<?=htmlspecialchars($filter_price,ENT_QUOTES)?>',
    _fRating='<?=htmlspecialchars($filter_rating,ENT_QUOTES)?>';

function openFilter(){
    document.getElementById('bmp-filter-overlay').classList.add('open');
    document.getElementById('bmp-filter-drawer').classList.add('open');
}
function closeFilter(){
    document.getElementById('bmp-filter-overlay').classList.remove('open');
    document.getElementById('bmp-filter-drawer').classList.remove('open');
}
function toggleCat(v){ _fCat=_fCat===v?'':v; refreshChips(); }
function togglePrice(v){ _fPrice=_fPrice===v?'':v; refreshChips(); }
function toggleRating(v){ _fRating=_fRating===v?'':v; refreshChips(); }
function refreshChips(){
    document.querySelectorAll('[data-cat]').forEach(function(el){ el.classList.toggle('active',el.dataset.cat===_fCat); });
    document.querySelectorAll('[data-price]').forEach(function(el){ el.classList.toggle('active',el.dataset.price===_fPrice); });
    document.querySelectorAll('[data-rating]').forEach(function(el){ el.classList.toggle('active',el.dataset.rating===_fRating); });
}
function applyFilters(){
    var q=document.getElementById('bmp-q').value.trim();
    var url='business_marketplace.php?';
    if(q) url+='q='+encodeURIComponent(q)+'&';
    if(_fCat) url+='cat='+encodeURIComponent(_fCat)+'&';
    if(_fPrice) url+='price='+encodeURIComponent(_fPrice)+'&';
    if(_fRating) url+='rating='+encodeURIComponent(_fRating)+'&';
    location.href=url.replace(/&$/,'');
}
// filter-dot indicator
document.addEventListener('DOMContentLoaded',function(){
    var dot=document.getElementById('filter-dot');
    if(dot&&(_fCat||_fPrice||_fRating)) dot.classList.add('show');
});

// ── Banner slider ─────────────────────────────────────────────────────────────
(function(){
    var slides=document.querySelectorAll('#bmp-promo .slide-bg');
    var dots=document.querySelectorAll('#bmp-promo .pdot');
    var banData=[
        {tag:'Top Rated Products',title:'Up to <span>40% OFF</span>',sub:'Exclusive deals on Dealfity — limited time only!',btn:'Shop Now →'},
        {tag:'New Arrivals',title:'Fresh <span>Listings</span>',sub:'Be the first to grab the latest products!',btn:'Browse New →'},
        {tag:'Best Sellers',title:'Hot <span>Picks</span>',sub:'Most loved items by Dealfity shoppers.',btn:'See Picks →'},
    ];
    var cur=0;
    function goSlide(n){
        slides.forEach(function(s,i){ s.classList.toggle('active',i===n); });
        dots.forEach(function(d,i){ d.classList.toggle('active',i===n); });
        var d=banData[n];
        var t=document.getElementById('ban-title'),s=document.getElementById('ban-sub');
        if(!t||!s) return;
        t.classList.add('fading'); s.classList.add('fading');
        setTimeout(function(){ t.innerHTML=d.title; s.textContent=d.sub; t.classList.remove('fading'); s.classList.remove('fading'); },400);
    }
    dots.forEach(function(d){ d.addEventListener('click',function(){ cur=parseInt(d.dataset.i); goSlide(cur); }); });
    setInterval(function(){ cur=(cur+1)%slides.length; goSlide(cur); },5000);
})();

// ── Flash deals countdown ─────────────────────────────────────────────────────
(function(){
    var total=2*3600+47*60+33;
    function tick(){
        total=Math.max(0,total-1);
        var h=Math.floor(total/3600), m=Math.floor((total%3600)/60), s=total%60;
        function pad(n){ return n<10?'0'+n:n; }
        var he=document.getElementById('fcd-h'),me=document.getElementById('fcd-m'),se=document.getElementById('fcd-s');
        if(he) he.textContent=pad(h);
        if(me) me.textContent=pad(m);
        if(se) se.textContent=pad(s);
    }
    setInterval(tick,1000);
})();
