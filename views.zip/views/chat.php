<?php
session_start();
try { require_once 'config.php'; } catch (Throwable $e) { $conn = null; }
if (empty($_SESSION['user_id'])) { header('Location: login.php'); exit; }

$user_id    = (int)$_SESSION['user_id'];
// ── Fetch unread count for notification badge ─────────────────────────────
$_notif_uid          = (int)($_SESSION['user_id'] ?? 0);
$unread_notif_count  = 0;
$last_msg_id_init    = 0;
if ($_notif_uid && $conn) {
    try {
        $r = $conn->prepare("SELECT COUNT(*) AS c FROM messages WHERE receiver_id=? AND is_read=0");
        $r->bind_param('i', $_notif_uid); $r->execute();
        $unread_notif_count += (int)($r->get_result()->fetch_assoc()['c'] ?? 0);
        $r->close();
        $r2 = $conn->prepare("SELECT COUNT(*) AS c FROM notifications WHERE user_id=? AND is_read=0");
        $r2->bind_param('i', $_notif_uid); $r2->execute();
        $unread_notif_count += (int)($r2->get_result()->fetch_assoc()['c'] ?? 0);
        $r2->close();
        $r3 = $conn->prepare("SELECT COALESCE(MAX(id),0) AS mid FROM messages WHERE receiver_id=?");
        $r3->bind_param('i', $_notif_uid); $r3->execute();
        $last_msg_id_init = (int)($r3->get_result()->fetch_assoc()['mid'] ?? 0);
        $r3->close();
    } catch (Throwable $e) {}
}

$user_name  = $_SESSION['user_name'] ?? 'User';
$first_name = explode(' ', trim($user_name))[0];
$chat_with  = (int)($_GET['user'] ?? $_GET['seller'] ?? 0);
$listing_id = (int)($_GET['listing'] ?? 0);

if (!$chat_with) { header('Location: messages.php'); exit; }

// ── AJAX: send message ────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'send') {
    header('Content-Type: application/json');
    $to   = (int)($_POST['to']  ?? 0);
    $body = trim($_POST['body'] ?? '');
    $lid  = (int)($_POST['lid'] ?? 0) ?: null;
    if (!$conn || !$to || $body === '') { echo json_encode(['ok'=>false]); exit; }
    try {
        $s = $conn->prepare("INSERT INTO messages (sender_id,receiver_id,listing_id,body,is_read,created_at) VALUES (?,?,?,?,0,NOW())");
        $s->bind_param('iiis', $user_id, $to, $lid, $body);
        $s->execute();
        $new_id = $conn->insert_id;
        $s->close();
        echo json_encode(['ok'=>true,'id'=>$new_id,'time'=>date('g:i A')]);
    } catch (Throwable $e) { echo json_encode(['ok'=>false,'err'=>$e->getMessage()]); }
    exit;
}

// ── AJAX: poll new messages ───────────────────────────────────────────────
if (isset($_GET['poll'])) {
    header('Content-Type: application/json');
    $since = (int)($_GET['since'] ?? 0);
    $rows  = [];
    if ($conn) {
        try {
            $r = $conn->prepare("SELECT m.id, m.sender_id, m.body, m.created_at FROM messages m WHERE m.id > ? AND ((m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?)) ORDER BY m.created_at ASC LIMIT 50");
            $r->bind_param('iiiii', $since, $user_id, $chat_with, $chat_with, $user_id);
            $r->execute();
            $res = $r->get_result();
            while ($row = $res->fetch_assoc()) {
                $row['is_me'] = ($row['sender_id'] == $user_id);
                $row['time']  = date('g:i A', strtotime($row['created_at']));
                $rows[] = $row;
            }
            $r->close();
            // Mark messages from chat_with as read
            $conn->query("UPDATE messages SET is_read=1 WHERE receiver_id=" . $user_id . " AND sender_id=" . $chat_with . " AND is_read=0");
        } catch (Throwable $e) {}
    }
    echo json_encode(['messages'=>$rows]);
    exit;
}

// Fetch chat partner
$partner = null;
if ($conn && $chat_with) {
    try {
        $r = $conn->prepare("SELECT id, name FROM users WHERE id=? LIMIT 1");
        $r->bind_param('i', $chat_with);
        $r->execute();
        $partner = $r->get_result()->fetch_assoc();
        $r->close();
    } catch(Throwable $e) {}
}
if (!$partner) {
    // Show a clear error instead of silent redirect
    die('<div style="font-family:sans-serif;padding:40px;text-align:center;color:#D94040">
        <div style="font-size:40px;margin-bottom:12px">⚠️</div>
        <strong>Could not load chat.</strong><br>
        User not found or database error.<br><br>
        <a href="messages.php" style="color:#2E9E3E;font-weight:700">← Back to Messages</a>
    </div>');
}

// ── FIX: Auto-detect listing_id from conversation history if not in URL ──
// When the recipient opens messages.php and clicks the conversation,
// this ensures the listing context is always restored.
if (!$listing_id && $conn) {
    try {
        $r = $conn->prepare("SELECT listing_id FROM messages WHERE ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)) AND listing_id IS NOT NULL ORDER BY id ASC LIMIT 1");
        $r->bind_param('iiii', $user_id, $chat_with, $chat_with, $user_id);
        $r->execute();
        $det = $r->get_result()->fetch_assoc();
        $r->close();
        if ($det) $listing_id = (int)$det['listing_id'];
    } catch (Throwable $e) {}
}

// Fetch listing details
$listing = null;
if ($conn && $listing_id) {
    try {
        $r = $conn->prepare("SELECT l.id, l.title, l.price, l.images, l.image, l.user_id AS seller_id, u.name AS seller_name FROM listings l JOIN users u ON u.id = l.user_id WHERE l.id=? LIMIT 1");
        $r->bind_param('i', $listing_id);
        $r->execute();
        $listing = $r->get_result()->fetch_assoc();
        $r->close();
        if ($listing) {
            $imgs = json_decode($listing['images'] ?? '[]', true);
            $listing['thumb'] = !empty($imgs[0]) ? $imgs[0] : ($listing['image'] ?? '');
        }
    } catch (Throwable $e) {}
}

// Determine roles: is the person we're chatting with the seller?
$chat_with_is_seller = $listing && ((int)$listing['seller_id'] === $chat_with);
$i_am_seller         = $listing && ((int)$listing['seller_id'] === $user_id);

// Fetch message history
$messages    = [];
$last_msg_id = 0;
if ($conn && $chat_with) {
    try {
        $r = $conn->prepare("SELECT m.id, m.sender_id, m.body, m.created_at, u.name AS sender_name FROM messages m JOIN users u ON u.id=m.sender_id WHERE (m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?) ORDER BY m.created_at ASC LIMIT 100");
        $r->bind_param('iiii', $user_id, $chat_with, $chat_with, $user_id);
        $r->execute();
        $res = $r->get_result();
        while ($row = $res->fetch_assoc()) {
            $row['is_me'] = ($row['sender_id'] == $user_id);
            $row['time']  = date('g:i A', strtotime($row['created_at']));
            $messages[] = $row;
        }
        $r->close();
        if (!empty($messages)) $last_msg_id = end($messages)['id'];
        // Mark received messages as read
        $conn->query("UPDATE messages SET is_read=1 WHERE receiver_id=" . $user_id . " AND sender_id=" . $chat_with . " AND is_read=0");
    } catch(Throwable $e) {}
}

$initials    = strtoupper(substr($partner['name'], 0, 2));
$me_initials = strtoupper(substr($user_name, 0, 2));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
<title>Chat with <?= htmlspecialchars($partner['name']) ?> &mdash; Dealfity</title>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@600;700;800;900&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
    --green:#2E9E3E;--green-dark:#1e7a2c;--green-light:#E8F5EA;
    --yellow:#F5A623;--blue:#1A5FA8;--red:#D94040;--gray:#8A96A8;
    --white:#fff;--bg:#F6F7FA;--text:#18191F;--text-2:#52576B;
    --border:#E8EBF0;--radius:14px;--radius-sm:10px;
    --shadow:0 2px 12px rgba(0,0,0,.06);
}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);-webkit-font-smoothing:antialiased;overflow-x:hidden}
a{text-decoration:none;color:inherit}

/* HEADER */
.chat-header{position:fixed;top:0;left:0;right:0;height:64px;background:var(--white);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 16px;gap:12px;z-index:300;box-shadow:0 1px 6px rgba(0,0,0,.04)}
.back-btn{width:36px;height:36px;border-radius:50%;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:20px;cursor:pointer;border:1px solid var(--border);flex-shrink:0;text-decoration:none;color:var(--text)}
.partner-av{width:44px;height:44px;border-radius:50%;background:var(--blue);display:flex;align-items:center;justify-content:center;font-family:'Nunito',sans-serif;font-weight:900;font-size:16px;color:#fff;overflow:hidden;flex-shrink:0;position:relative}
.partner-av img{width:100%;height:100%;object-fit:cover}
.partner-info{flex:1;min-width:0}
.partner-name{font-family:'Nunito',sans-serif;font-weight:800;font-size:15px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;gap:6px}
.role-badge{font-size:10px;font-weight:700;padding:2px 7px;border-radius:20px;white-space:nowrap;flex-shrink:0}
.role-seller{background:var(--green-light);color:var(--green-dark)}
.role-buyer{background:#E3EEF9;color:var(--blue)}
.partner-sub{font-size:12px;color:var(--gray);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.partner-sub strong{color:var(--green-dark)}
.header-actions{display:flex;align-items:center;gap:8px}
.icon-btn{width:36px;height:36px;border-radius:50%;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:18px;cursor:pointer;border:1px solid var(--border);transition:background .15s}
.icon-btn:hover{background:var(--green-light)}

/* LISTING BANNER */
.listing-banner{position:fixed;z-index:299;left:0;right:0;background:linear-gradient(90deg,#E8F5EA,#F0FAF2);border-bottom:1px solid #c3e6c9;display:flex;align-items:center;gap:10px;padding:8px 14px;box-shadow:0 2px 8px rgba(46,158,62,.08)}
.listing-banner-thumb{width:42px;height:42px;border-radius:9px;overflow:hidden;background:#fff;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:18px;border:1px solid #c3e6c9}
.listing-banner-thumb img{width:100%;height:100%;object-fit:cover}
.listing-banner-info{flex:1;min-width:0}
.listing-banner-title{font-family:Nunito,sans-serif;font-weight:700;font-size:12.5px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.listing-banner-price{font-family:Nunito,sans-serif;font-weight:900;font-size:13px;color:var(--green-dark)}
.listing-banner-view{font-size:12px;font-weight:700;color:var(--green-dark);background:#fff;border:1.5px solid var(--green);padding:5px 12px;border-radius:20px;white-space:nowrap;transition:all .15s}
.listing-banner-view:hover{background:var(--green);color:#fff}

/* MESSAGES */
.messages-wrap{padding-bottom:76px;min-height:100vh}
.messages-list{padding:14px;display:flex;flex-direction:column;gap:10px}
.msg-group{display:flex;flex-direction:column;gap:3px;max-width:78%}
.msg-group.me{align-self:flex-end;align-items:flex-end}
.msg-group.them{align-self:flex-start;align-items:flex-start}
.msg-sender-label{font-size:11px;font-weight:700;color:var(--blue);padding:0 6px;margin-bottom:2px}
.msg-bubble{position:relative;padding:11px 14px;border-radius:18px;font-size:14.5px;line-height:1.55;word-wrap:break-word;animation:msgPop .2s ease}
.msg-group.me .msg-bubble{background:linear-gradient(135deg,#2E9E3E,#1e7a2c);color:#fff;border-bottom-right-radius:4px}
.msg-group.them .msg-bubble{background:var(--white);color:var(--text);border:1px solid var(--border);border-bottom-left-radius:4px;box-shadow:var(--shadow)}
.msg-time{font-size:11px;color:var(--gray);margin-top:2px;padding:0 6px}
.msg-group.me .msg-time{color:var(--green-dark)}
.date-divider{text-align:center;padding:10px 0;font-size:12px;color:var(--gray);font-weight:600}
.date-pill{display:inline-block;background:var(--bg);padding:5px 14px;border-radius:20px;border:1px solid var(--border)}

/* TYPING INDICATOR */
.typing-indicator{display:none;align-items:center;gap:4px;padding:11px 14px;background:var(--white);border:1px solid var(--border);border-radius:16px;border-bottom-left-radius:4px;box-shadow:var(--shadow);max-width:75px;animation:msgPop .2s ease}
.typing-indicator.show{display:flex}
.typing-dot{width:8px;height:8px;border-radius:50%;background:var(--gray);animation:typingBounce 1.4s infinite}
.typing-dot:nth-child(2){animation-delay:.2s}
.typing-dot:nth-child(3){animation-delay:.4s}

/* INPUT BAR */
.input-bar{position:fixed;bottom:0;left:0;right:0;background:var(--white);border-top:1px solid var(--border);padding:10px 16px;display:flex;gap:10px;align-items:flex-end;z-index:300;box-shadow:0 -2px 12px rgba(0,0,0,.06)}
.input-wrap{flex:1;display:flex;align-items:flex-end;gap:8px;background:var(--bg);border:1.5px solid var(--border);border-radius:24px;padding:8px 12px;transition:border-color .15s}
.input-wrap:focus-within{border-color:var(--green)}
.attach-btn{width:32px;height:32px;border-radius:50%;background:transparent;border:none;display:flex;align-items:center;justify-content:center;font-size:20px;cursor:pointer;color:var(--gray);flex-shrink:0}
.msg-input{flex:1;border:none;background:transparent;font-size:14.5px;font-family:'DM Sans',sans-serif;color:var(--text);outline:none;resize:none;max-height:100px;line-height:1.5;padding:4px 0}
.msg-input::placeholder{color:var(--gray)}
.send-btn{width:44px;height:44px;border-radius:50%;background:var(--green);border:none;display:flex;align-items:center;justify-content:center;font-size:20px;cursor:pointer;flex-shrink:0;transition:all .15s;color:#fff;box-shadow:0 3px 12px rgba(46,158,62,.3)}
.send-btn:hover{background:var(--green-dark);transform:scale(1.05)}
.send-btn:disabled{background:#ccc;opacity:.6;cursor:not-allowed;transform:scale(1);box-shadow:none}

/* QUICK ACTIONS */
.quick-actions{display:flex;gap:6px;padding:0 14px 10px;overflow-x:auto;scrollbar-width:none}
.quick-actions::-webkit-scrollbar{display:none}
.quick-btn{display:inline-flex;align-items:center;gap:6px;padding:7px 14px;background:var(--white);border:1.5px solid var(--border);border-radius:20px;font-size:13px;font-weight:600;color:var(--text-2);cursor:pointer;white-space:nowrap;transition:all .15s;flex-shrink:0}
.quick-btn:hover{background:var(--green-light);border-color:var(--green);color:var(--green-dark)}

@keyframes msgPop{from{opacity:0;transform:scale(.88) translateY(4px)}to{opacity:1;transform:scale(1) translateY(0)}}
@keyframes typingBounce{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-6px)}}

@media(max-width:768px){
    .input-bar{padding-bottom:env(safe-area-inset-bottom,10px)}
}
@media(min-width:769px){
    .messages-wrap{max-width:800px;margin:0 auto}
    .input-bar{max-width:800px;left:50%;transform:translateX(-50%)}
    .listing-banner{max-width:800px;left:50%;transform:translateX(-50%)}
}

/* ══ DEALFITY FAB ════════════════════════════════════════ */
.dfab-wrap{position:fixed;right:18px;bottom:76px;z-index:500;pointer-events:none}
.dfab-wrap *{pointer-events:all}
.dfab-btn{
  width:54px;height:54px;border-radius:50%;
  background:linear-gradient(145deg,#34b84a,#1e7a2c);
  border:3px solid #fff;
  box-shadow:0 4px 20px rgba(30,122,44,.45);
  display:flex;align-items:center;justify-content:center;
  cursor:pointer;outline:none;
  transition:transform .3s cubic-bezier(.34,1.56,.64,1),background .25s,box-shadow .25s;
  position:relative;z-index:501;
}
.dfab-btn:hover{box-shadow:0 6px 26px rgba(30,122,44,.55)}
.dfab-btn.open{
  background:linear-gradient(145deg,#f05252,#b91c1c);
  transform:rotate(45deg);
  box-shadow:0 4px 20px rgba(185,28,28,.45);
}
.dfab-cross{position:relative;width:20px;height:20px}
.dfab-cross span{position:absolute;background:#fff;border-radius:3px;transition:all .3s}
.dfab-cross .dfc-h{width:20px;height:2.5px;top:50%;left:0;transform:translateY(-50%)}
.dfab-cross .dfc-v{width:2.5px;height:20px;left:50%;top:0;transform:translateX(-50%)}
/* Radial nodes */
.dfab-node{
  position:absolute;right:0;bottom:0;
  display:flex;flex-direction:column;align-items:center;gap:5px;
  opacity:0;pointer-events:none;
  transition:opacity .22s ease,transform .3s cubic-bezier(.34,1.56,.64,1);
}
.dfab-node.n-ai   {transform:translate(60px,80px)   scale(.5);transition-delay:0s}
.dfab-node.n-msg  {transform:translate(50px,10px)   scale(.5);transition-delay:.04s}
.dfab-node.n-supp {transform:translate(0px,-50px)   scale(.5);transition-delay:.08s}
.dfab-wrap.open .dfab-node{opacity:1;pointer-events:all}
.dfab-wrap.open .dfab-node.n-ai  {transform:translate(-92px, 80px) scale(1);transition-delay:.06s}
.dfab-wrap.open .dfab-node.n-msg {transform:translate(-112px,10px) scale(1);transition-delay:.12s}
.dfab-wrap.open .dfab-node.n-supp{transform:translate(-82px,-60px) scale(1);transition-delay:.18s}
.dfab-circle{
  width:52px;height:52px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;font-size:22px;
  border:3px solid #fff;box-shadow:0 6px 20px rgba(0,0,0,.22);
  cursor:pointer;transition:transform .18s,box-shadow .18s;
}
.dfab-circle:hover{transform:scale(1.1);box-shadow:0 8px 26px rgba(0,0,0,.32)}
.dfab-circle.c-ai  {background:#7B3FBE}
.dfab-circle.c-msg {background:#1A5FA8}
.dfab-circle.c-spp {background:#0D9488}
.dfab-label{
  background:#183020;color:#fff;
  font-family:'Nunito',sans-serif;font-weight:800;font-size:11px;
  padding:4px 11px;border-radius:20px;
  box-shadow:0 3px 10px rgba(0,0,0,.28);pointer-events:none;white-space:nowrap;
}
/* Scrim */
.dfab-scrim{
  position:fixed;inset:0;z-index:499;
  background:rgba(10,20,14,.5);
  opacity:0;visibility:hidden;
  transition:opacity .22s,visibility .22s;
}
.dfab-scrim.open{opacity:1;visibility:visible}
/* ── SLIDE PANEL ── */
.dfab-panel{
  position:fixed;top:0;bottom:0;left:-100%;
  width:72%;max-width:360px;
  z-index:600;background:#fff;
  border-radius:0 24px 24px 0;
  box-shadow:4px 0 40px rgba(0,0,0,.22);
  transition:left .3s cubic-bezier(.4,0,.2,1);
  display:flex;flex-direction:column;overflow:hidden;
}
.dfab-panel.open{left:0}
.dfab-panel-header{
  background:linear-gradient(135deg,#1B6B2F,#2E9E3E 60%,#3CB84B);
  padding:50px 20px 20px;flex-shrink:0;position:relative;
}
.dfab-panel-close{
  position:absolute;top:14px;right:14px;
  width:32px;height:32px;border-radius:50%;
  background:rgba(255,255,255,.2);border:none;
  color:#fff;font-size:18px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  transition:background .15s;
}
.dfab-panel-close:hover{background:rgba(255,255,255,.35)}
.dfab-panel-av{width:46px;height:46px;border-radius:50%;background:rgba(255,255,255,.22);border:2px solid rgba(255,255,255,.4);display:flex;align-items:center;justify-content:center;font-size:22px;margin-bottom:10px}
.dfab-panel-title{font-family:'Nunito',sans-serif;font-weight:900;font-size:17px;color:#fff;margin-bottom:3px}
.dfab-panel-sub{font-size:12px;color:rgba(255,255,255,.75)}
.dfab-panel-body{flex:1;overflow-y:auto}
.dfab-section-lbl{font-size:10px;font-weight:800;color:#8A96A8;text-transform:uppercase;letter-spacing:.8px;padding:16px 18px 6px}
.dfab-item{
  display:flex;align-items:center;gap:13px;padding:13px 18px;
  cursor:pointer;text-decoration:none;color:#18191F;
  transition:background .15s;border:none;background:none;width:100%;font-family:inherit;
}
.dfab-item:hover{background:#F3F5F9}
.dfab-item-icon{width:42px;height:42px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.dfab-item-body{flex:1;text-align:left}
.dfab-item-title{font-family:'Nunito',sans-serif;font-weight:800;font-size:14px;color:#18191F;margin-bottom:1px}
.dfab-item-sub{font-size:11.5px;color:#8A96A8}
.dfab-item-arrow{font-size:20px;color:#ccc;font-weight:300}
.dfab-divider{height:1px;background:#F0F2F6;margin:2px 18px}
.dfab-panel-footer{padding:14px 18px;border-top:1px solid #F0F2F6;flex-shrink:0;text-align:center;font-size:11px;color:#8A96A8}
/* inner page */
.dfab-page{display:none;flex:1;flex-direction:column;height:100%;overflow:hidden}
.dfab-page.show{display:flex}
.dfab-page-bar{display:flex;align-items:center;gap:10px;padding:11px 14px;border-bottom:1px solid #F0F2F6;flex-shrink:0}
.dfab-page-back{width:34px;height:34px;border-radius:50%;background:#F3F5F9;border:none;font-size:22px;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#52576B;line-height:1;transition:background .15s}
.dfab-page-back:hover{background:#E8F5EA;color:#2E9E3E}
.dfab-page-name{font-family:'Nunito',sans-serif;font-weight:800;font-size:14px;color:#18191F;flex:1}
.dfab-page-badge{font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;white-space:nowrap}
.dfab-page-iframe{border:none;flex:1;width:100%;background:#F3F5F9}
/* FAB notification badge */
.dfab-notif-badge{
  position:absolute;top:-4px;right:-4px;
  min-width:18px;height:18px;border-radius:9px;
  background:#D94040;color:#fff;
  font-family:'Nunito',sans-serif;font-weight:900;font-size:9px;
  display:flex;align-items:center;justify-content:center;
  padding:0 4px;border:2px solid #fff;
  pointer-events:none;line-height:1;
}
.dfab-circle{position:relative}
/* Panel item badge */
.dfab-item-badge{
  min-width:20px;height:20px;border-radius:10px;
  background:#D94040;color:#fff;
  font-family:'Nunito',sans-serif;font-weight:900;font-size:10px;
  display:inline-flex;align-items:center;justify-content:center;
  padding:0 5px;margin-right:4px;
}

/* ════════════════════════════════════════════════════════ */

</style>
</head>
<body>

<?php
// Calculate header offsets
$header_h  = 64;
$banner_h  = $listing ? 58 : 0;
$total_top = $header_h + $banner_h;
?>

<!-- HEADER -->
<div class="chat-header">
    <a class="back-btn" href="messages.php">&#8249;</a>
    <div class="partner-av" style="background:<?= $chat_with_is_seller ? '#2E9E3E' : '#1A5FA8' ?>">
        <?= $initials ?>
    </div>
    <div class="partner-info">
        <div class="partner-name">
            <?= htmlspecialchars($partner['name']) ?>
            <?php if ($listing && $chat_with_is_seller): ?>
            <span class="role-badge role-seller">🏪 Seller</span>
            <?php elseif ($listing && $i_am_seller): ?>
            <span class="role-badge role-buyer">🛍️ Buyer</span>
            <?php endif; ?>
        </div>
        <div class="partner-sub">
            <?php if ($listing): ?>
            About: <strong><?= htmlspecialchars(mb_substr($listing['title'],0,40)) ?><?= mb_strlen($listing['title'])>40?'…':'' ?></strong>
            <?php else: ?>
            Dealfity Chat
            <?php endif; ?>
        </div>
    </div>
    <div class="header-actions">
        <div class="icon-btn" title="Call (coming soon)" onclick="alert('Call feature coming soon!')">📞</div>
    </div>
</div>

<!-- LISTING BANNER -->
<?php if ($listing): ?>
<div class="listing-banner" style="top:<?= $header_h ?>px">
    <div class="listing-banner-thumb">
        <?php if(!empty($listing['thumb'])): ?>
        <img src="<?= htmlspecialchars($listing['thumb']) ?>" alt=""/>
        <?php else: ?>📦<?php endif; ?>
    </div>
    <div class="listing-banner-info">
        <div class="listing-banner-title"><?= htmlspecialchars($listing['title']) ?></div>
        <div class="listing-banner-price">KSh <?= number_format($listing['price']) ?></div>
    </div>
    <a class="listing-banner-view" href="listing_detail.php?id=<?= $listing_id ?>">View ›</a>
</div>
<?php endif; ?>

<!-- MESSAGES AREA -->
<div class="messages-wrap" style="padding-top:<?= $total_top + 10 ?>px">
    <!-- Quick reply chips -->
    <div class="quick-actions">
        <div class="quick-btn" onclick="sendQuick('Is this still available?')"><span>✅</span>Still available?</div>
        <div class="quick-btn" onclick="sendQuick('What is the best price?')"><span>💰</span>Best price?</div>
        <div class="quick-btn" onclick="sendQuick('Can we meet today?')"><span>📍</span>Meet today?</div>
        <div class="quick-btn" onclick="sendQuick('Do you deliver?')"><span>🚚</span>Delivery?</div>
        <?php if ($listing && $chat_with_is_seller): ?>
        <div class="quick-btn" onclick="sendQuick('I am interested in buying this. Is it still available?')"><span>🤝</span>I want to buy</div>
        <?php endif; ?>
    </div>

    <div class="messages-list" id="messages-list">
        <div class="date-divider"><span class="date-pill">Today</span></div>

        <?php if (empty($messages)): ?>
        <div id="empty-state" style="text-align:center;padding:50px 24px;color:var(--gray)">
            <div style="font-size:44px;margin-bottom:10px">👋</div>
            <div style="font-family:Nunito,sans-serif;font-weight:800;font-size:16px;color:var(--text);margin-bottom:6px">
                Say hello to <?= htmlspecialchars($partner['name']) ?>!
            </div>
            <?php if($listing): ?>
            <div style="font-size:13px;color:var(--text-2)">
                Asking about: <strong><?= htmlspecialchars($listing['title']) ?></strong>
            </div>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <?php foreach($messages as $msg): ?>
        <div class="msg-group <?= $msg['is_me'] ? 'me' : 'them' ?>" data-id="<?= $msg['id'] ?>">
            <?php if(!$msg['is_me']): ?>
            <div class="msg-sender-label"><?= htmlspecialchars($partner['name']) ?></div>
            <?php endif; ?>
            <div class="msg-bubble"><?= nl2br(htmlspecialchars($msg['body'])) ?></div>
            <div class="msg-time"><?= $msg['time'] ?><?= $msg['is_me'] ? ' ✓✓' : '' ?></div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>

        <!-- Typing indicator slot -->
        <div class="msg-group them">
            <div class="typing-indicator" id="typing-indicator">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        </div>
    </div>
</div>

<!-- INPUT BAR -->
<div class="input-bar">
    <div class="input-wrap">
        <button class="attach-btn" onclick="attachFile()" title="Attach image">📎</button>
        <textarea class="msg-input" id="msg-input" placeholder="Type a message…" rows="1"></textarea>
    </div>
    <button class="send-btn" id="send-btn" onclick="sendMessage()" disabled title="Send">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 9L11 13" stroke="white" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>
</div>

<script>
const CHAT_WITH  = <?= (int)$chat_with ?>;
const LISTING_ID = <?= (int)$listing_id ?>;
let   lastMsgId  = <?= (int)$last_msg_id ?>;
const ME_INIT    = <?= json_encode($me_initials) ?>;
const P_INIT     = <?= json_encode($initials) ?>;
const P_NAME     = <?= json_encode($partner['name']) ?>;

const msgInput = document.getElementById('msg-input');
const sendBtn  = document.getElementById('send-btn');
const msgsList = document.getElementById('messages-list');
const typingEl = document.getElementById('typing-indicator');

// Auto-grow textarea
msgInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 100) + 'px';
    sendBtn.disabled = !this.value.trim();
});

// Send on Enter (Shift+Enter = newline)
msgInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (!sendBtn.disabled) sendMessage();
    }
});

function sendMessage() {
    const text = msgInput.value.trim();
    if (!text) return;
    msgInput.value = '';
    msgInput.style.height = 'auto';
    sendBtn.disabled = true;

    // Remove empty-state banner
    const es = document.getElementById('empty-state');
    if (es) es.remove();

    // Optimistically show the bubble immediately
    appendBubble({ body: text, is_me: true, time: nowTime() }, 0);
    scrollBottom();

    const fd = new FormData();
    fd.append('action', 'send');
    fd.append('to', CHAT_WITH);
    fd.append('body', text);
    fd.append('lid', LISTING_ID);

    fetch('chat.php?user=' + CHAT_WITH + '&listing=' + LISTING_ID, { method: 'POST', body: fd })
        .then(r => r.json())
        .then(d => {
            if (d.ok && d.id > lastMsgId) lastMsgId = d.id;
        })
        .catch(() => {});
}

function sendQuick(text) {
    msgInput.value = text;
    sendMessage();
}

function appendBubble(msg, id) {
    // Avoid duplicate bubbles (same id already in DOM)
    if (id && document.querySelector('[data-id="' + id + '"]')) return;

    const div = document.createElement('div');
    div.className = 'msg-group ' + (msg.is_me ? 'me' : 'them');
    if (id) div.dataset.id = id;

    const senderLabel = !msg.is_me
        ? `<div class="msg-sender-label">${esc(P_NAME)}</div>`
        : '';

    div.innerHTML = senderLabel
        + `<div class="msg-bubble">${esc(msg.body).replace(/\n/g, '<br>')}</div>`
        + `<div class="msg-time">${msg.time}${msg.is_me ? ' ✓✓' : ''}</div>`;

    // Insert before typing indicator wrapper
    typingEl.closest('.msg-group').insertAdjacentElement('beforebegin', div);
}

// Poll every 3 seconds for new incoming messages
setInterval(function() {
    fetch('chat.php?user=' + CHAT_WITH + '&listing=' + LISTING_ID + '&poll=1&since=' + lastMsgId)
        .then(r => r.json())
        .then(d => {
            if (!d.messages || !d.messages.length) return;
            let hasNew = false;
            d.messages.forEach(m => {
                // Only append messages from the other person (ours are shown optimistically)
                if (!m.is_me) {
                    const es = document.getElementById('empty-state');
                    if (es) es.remove();
                    appendBubble(m, m.id);
                    hasNew = true;
                }
                if (m.id > lastMsgId) lastMsgId = m.id;
            });
            if (hasNew) scrollBottom();
        })
        .catch(() => {});
}, 3000);

function scrollBottom() {
    setTimeout(() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' }), 80);
}

function nowTime() {
    const d = new Date(), h = d.getHours() % 12 || 12, m = String(d.getMinutes()).padStart(2,'0');
    return h + ':' + m + ' ' + (d.getHours() >= 12 ? 'PM' : 'AM');
}

function esc(t) {
    const d = document.createElement('div');
    d.textContent = t;
    return d.innerHTML;
}

function attachFile() {
    const input = document.createElement('input');
    input.type = 'file'; input.accept = 'image/*';
    input.onchange = e => { if (e.target.files[0]) alert('Image upload coming soon!'); };
    input.click();
}

// Auto-send "Buy Now" intent message if coming from listing page
<?php if (!empty($_GET['intent']) && $_GET['intent'] === 'buy' && $listing && empty($messages)): ?>
(function(){
    const buyMsg = 'Hi! I would like to buy "<?= addslashes(htmlspecialchars($listing['title'])) ?>" for KSh <?= number_format($listing['price']) ?>. Is it still available?';
    setTimeout(function(){ msgInput.value = buyMsg; msgInput.dispatchEvent(new Event('input')); msgInput.focus(); }, 500);
})();
<?php endif; ?>

// Scroll to bottom on load
scrollBottom();

// ══ DEALFITY FAB ══════════════════════════════════════════
(function(){
var _open = false;
var _pages = {
    ai:       {name:'AI Assistant',  badge:'AI',      badgeColor:'#7B3FBE', badgeBg:'#F3EFFE', src:'ai.php'},
    messages: {name:'Messages',      badge:'Chat',    badgeColor:'#1A5FA8', badgeBg:'#E3EEF9', src:'messages.php'},
    support:  {name:'Support',       badge:'Help',    badgeColor:'#0D9488', badgeBg:'#E1F5EE', src:'support.php'},
};

window.dfabToggle = function(){
    _open = !_open;
    document.getElementById('dfab-wrap').classList.toggle('open',_open);
    document.getElementById('dfab-btn').classList.toggle('open',_open);
    document.getElementById('dfab-scrim').classList.toggle('open',_open);
};
window.dfabClose = function(){
    _open = false;
    document.getElementById('dfab-wrap').classList.remove('open');
    document.getElementById('dfab-btn').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
};
window.dfabOpen = function(type){
    dfabClose();
    var p = _pages[type];
    if(!p) return;
    document.getElementById('dfab-page-name').textContent = p.name;
    var badge = document.getElementById('dfab-page-badge');
    badge.textContent = p.badge;
    badge.style.background = p.badgeBg;
    badge.style.color = p.badgeColor;
    // Load iframe
    var iframe = document.getElementById('dfab-iframe');
    if(iframe.dataset.loaded !== p.src){
        iframe.src = p.src;
        iframe.dataset.loaded = p.src;
    }
    document.getElementById('dfab-menu').style.display = 'none';
    document.getElementById('dfab-page').classList.add('show');
    document.getElementById('dfab-panel').classList.add('open');
    document.getElementById('dfab-scrim').classList.add('open');
};
window.dfabBack = function(){
    document.getElementById('dfab-menu').style.display = 'block';
    document.getElementById('dfab-page').classList.remove('show');
    document.getElementById('dfab-iframe').src = 'about:blank';
    document.getElementById('dfab-iframe').dataset.loaded = '';
};
window.dfabPanelClose = function(){
    document.getElementById('dfab-panel').classList.remove('open');
    document.getElementById('dfab-scrim').classList.remove('open');
    setTimeout(function(){
        document.getElementById('dfab-menu').style.display = 'block';
        document.getElementById('dfab-page').classList.remove('show');
        document.getElementById('dfab-iframe').src = 'about:blank';
        document.getElementById('dfab-iframe').dataset.loaded = '';
    }, 320);
};
document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){dfabClose();dfabPanelClose();}
});
})();
// ══ END DEALFITY FAB ══════════════════════════════════════

// ══ LIVE NOTIFICATION BADGE POLLING ══════════════════════
<?php if (!empty($_SESSION['user_id'])): ?>
(function(){
var lastMsgId = <?= (int)$last_msg_id_init ?>;
var totalUnread = <?= (int)$unread_notif_count ?>;

function setAllBadges(count) {
    var tb = document.getElementById('topbar-notif-badge');
    if (tb) { tb.textContent = count > 99 ? '99+' : count; tb.style.display = count > 0 ? 'flex' : 'none'; }
    var fb = document.getElementById('fab-msg-badge');
    if (fb) { fb.textContent = count > 99 ? '99+' : count; fb.style.display = count > 0 ? 'flex' : 'none'; }
    var pb = document.getElementById('fab-panel-msg-badge');
    if (pb) { pb.textContent = count > 99 ? '99+' : count; pb.style.display = count > 0 ? 'inline-flex' : 'none'; }
    var btn = document.getElementById('dfab-btn');
    if (btn) { btn.style.boxShadow = count > 0 ? '0 4px 20px rgba(30,122,44,.45),0 0 0 4px rgba(217,64,64,.3)' : '0 4px 20px rgba(30,122,44,.45)'; }
}
function pollNotifications() {
    fetch('notifications.php?poll_messages=1&since=' + lastMsgId)
        .then(function(r){ return r.json(); })
        .then(function(d) {
            if (!d.messages || !d.messages.length) return;
            var n = d.messages.filter(function(m){ return m.id > lastMsgId; });
            if (!n.length) return;
            n.forEach(function(m){ if (m.id > lastMsgId) lastMsgId = m.id; });
            totalUnread += n.length;
            setAllBadges(totalUnread);
        }).catch(function(){});
}
setAllBadges(totalUnread);
setInterval(pollNotifications, 10000);
})();
<?php endif; ?>
// ══ END LIVE NOTIFICATION BADGE POLLING ══════════════════

</script>

<!-- ── DEALFITY FAB ─────────────────────────────────── -->
<div class="dfab-wrap" id="dfab-wrap">
    <div class="dfab-node n-ai">
        <div class="dfab-circle c-ai" onclick="dfabOpen('ai')">✨</div>
        <span class="dfab-label">AI</span>
    </div>
    <div class="dfab-node n-msg">
        <div class="dfab-circle c-msg" onclick="dfabOpen('messages')">💬<?php if ($unread_notif_count > 0): ?><span class="dfab-notif-badge" id="fab-msg-badge"><?= $unread_notif_count > 99 ? '99+' : $unread_notif_count ?></span><?php else: ?><span class="dfab-notif-badge" id="fab-msg-badge" style="display:none"></span><?php endif; ?></div>
        <span class="dfab-label">Messages</span>
    </div>
    <div class="dfab-node n-supp">
        <div class="dfab-circle c-spp" onclick="dfabOpen('support')">🎧</div>
        <span class="dfab-label">Support</span>
    </div>
    <button class="dfab-btn" id="dfab-btn" onclick="dfabToggle()" aria-label="Quick menu">
        <div class="dfab-cross"><span class="dfc-h"></span><span class="dfc-v"></span></div>
    </button>
</div>
<div class="dfab-scrim" id="dfab-scrim" onclick="dfabClose()"></div>

<!-- ── SLIDE PANEL ────────────────────────────────────── -->
<div class="dfab-panel" id="dfab-panel">

    <!-- Main menu -->
    <div id="dfab-menu">
        <div class="dfab-panel-header">
            <button class="dfab-panel-close" onclick="dfabPanelClose()">✕</button>
            <div class="dfab-panel-av">🤖</div>
            <div class="dfab-panel-title">Dealfity Assistant</div>
            <div class="dfab-panel-sub">AI · Messages · Support</div>
        </div>
        <div class="dfab-panel-body">
            <div class="dfab-section-lbl">Quick Access</div>
            <button class="dfab-item" onclick="dfabOpen('ai')">
                <div class="dfab-item-icon" style="background:#F3EFFE">✨</div>
                <div class="dfab-item-body">
                    <div class="dfab-item-title">AI Assistant</div>
                    <div class="dfab-item-sub">Ask anything about products</div>
                </div>
                <span class="dfab-item-arrow">›</span>
            </button>
            <div class="dfab-divider"></div>
            <button class="dfab-item" onclick="dfabOpen('messages')">
                <div class="dfab-item-icon" style="background:#E3EEF9">💬</div>
                <div class="dfab-item-body">
                    <div class="dfab-item-title">Messages</div>
                    <div class="dfab-item-sub">Chat with sellers &amp; buyers</div>
                </div>
                <?php if ($unread_notif_count > 0): ?><span class="dfab-item-badge" id="fab-panel-msg-badge"><?= $unread_notif_count > 99 ? '99+' : $unread_notif_count ?></span><?php else: ?><span class="dfab-item-badge" id="fab-panel-msg-badge" style="display:none"></span><?php endif; ?>
                <span class="dfab-item-arrow">›</span>
            </button>
            <div class="dfab-divider"></div>
            <button class="dfab-item" onclick="dfabOpen('support')">
                <div class="dfab-item-icon" style="background:#E1F5EE">🎧</div>
                <div class="dfab-item-body">
                    <div class="dfab-item-title">Support</div>
                    <div class="dfab-item-sub">Help, FAQs &amp; contact us</div>
                </div>
                <span class="dfab-item-arrow">›</span>
            </button>
        </div>
        <div class="dfab-panel-footer">Powered by Dealfity</div>
    </div>

    <!-- Inner page -->
    <div class="dfab-page" id="dfab-page">
        <div class="dfab-page-bar">
            <button class="dfab-page-back" onclick="dfabBack()">‹</button>
            <span class="dfab-page-name" id="dfab-page-name">Page</span>
            <span class="dfab-page-badge" id="dfab-page-badge"></span>
        </div>
        <iframe class="dfab-page-iframe" id="dfab-iframe" src="about:blank" title="Panel"></iframe>
    </div>

</div>
<!-- ── END DEALFITY FAB ───────────────────────────────── -->
</body>
</html>
