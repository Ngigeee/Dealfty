const { queryDB } = require("./dbHelpers");

/**
 * DASHBOARD STATS (single source of truth)
 */
async function getcountListingsofLoggedIN(loggedInUser) {
  try {
    const [
      revenueRes,
      listingRes,
      ordersRes,
      messagesRes,
      conversations,
      by_cat,
      recent_listings
    ] = await Promise.all([
      queryDB(
        "SELECT SUM(total_amount) AS total FROM orders WHERE seller_id=?",
        [loggedInUser]
      ),

      queryDB(
        "SELECT COUNT(*) AS total FROM listings WHERE user_id=?",
        [loggedInUser]
      ),

      queryDB(
        "SELECT COUNT(*) AS total FROM orders WHERE seller_id=?",
        [loggedInUser]
      ),

      queryDB(
        "SELECT COUNT(*) AS total FROM messages WHERE receiver_id=? AND is_read=?",
        [loggedInUser, 0]
      ),

      queryDB(
        `SELECT 
            m.sender_id,
            m.listing_id,
            u.name AS sender_name,
            u.avatar,
            COUNT(*) AS message_count,
            MAX(m.created_at) AS last_message_time
         FROM messages m
         JOIN users u ON u.id = m.sender_id
         WHERE m.receiver_id = ? AND is_read=?
         GROUP BY m.sender_id, u.name, u.avatar, m.listing_id
         ORDER BY last_message_time DESC`,
        [loggedInUser, 0]
      ),

      queryDB(
        `SELECT category, COUNT(*) AS cnt 
         FROM listings 
         WHERE user_id = ? 
         GROUP BY category`,
        [loggedInUser]
      ),

      queryDB(
        `SELECT * 
         FROM listings 
         WHERE user_id = ? 
         ORDER BY created_at DESC 
         LIMIT 5`,
        [loggedInUser]
      )
    ]);

    // ----------------------------
    // RAW VALUES (safe extraction)
    // ----------------------------
    const revenue = revenueRes?.[0]?.total ?? 0;
    const listings = listingRes?.[0]?.total ?? 0;
    const orders = ordersRes?.[0]?.total ?? 0;
    const unreadMessages = messagesRes?.[0]?.total ?? 0;

    // ----------------------------
    // DERIVED METRICS (reusable)
    // ----------------------------
    const avg_order = orders > 0 ? revenue / orders : 0;

    const conversion_rate =
      listings > 0 ? (orders / listings) * 100 : 0;

    const active = listings; // adjust if you later add status filtering

    return {
      // raw stats
      revenue_count: revenue,
      listing_count: listings,
      orders_count: orders,
      messages_count: unreadMessages,

      // relational data
      messages: conversations ?? [],
      category: by_cat ?? [],
      recents: recent_listings ?? [],

      // derived stats (IMPORTANT for dashboard reuse)
      avg_order,
      conversion_rate,
      active
    };

  } catch (err) {
    console.error("Dashboard count error:", err);

    return {
      revenue_count: 0,
      listing_count: 0,
      orders_count: 0,
      messages_count: 0,
      messages: [],
      category: [],
      recents: [],

      // derived safe defaults
      avg_order: 0,
      conversion_rate: 0,
      active: 0
    };
  }
}

/**
 * MARK MESSAGES AS READ
 */
async function markMessagesAsRead(receiverId, senderId, listingId) {
  try {
    return await queryDB(
      `UPDATE messages 
       SET seen = 1, is_read = 1
       WHERE receiver_id = ? 
         AND sender_id = ? 
         AND listing_id = ?`,
      [receiverId, senderId, listingId]
    );
  } catch (err) {
    console.error("Mark messages error:", err);
    throw err;
  }
}

/**
 * UPDATE LISTING
 */
async function updateListing(listingId, userId, data) {
  try {
    const { title, price, category } = data;

    return await queryDB(
      `UPDATE listings 
       SET title = ?, price = ?, category = ? 
       WHERE id = ? AND user_id = ?`,
      [title, price, category, listingId, userId]
    );

  } catch (err) {
    console.error("Update listing error:", err);
    throw err;
  }
}

module.exports = {
  getcountListingsofLoggedIN,
  markMessagesAsRead,
  updateListing
};
