const nodemailer=require("nodemailer");

async function sendVerificationEmail(email, link,token) {
  try {
    if (process.env.NODE_ENV !== "production") {

      const testAccount = await nodemailer.createTestAccount();

      const transporter = nodemailer.createTransport({
        host: "smtp.ethereal.email",
        port: 587,
        auth: {
          user: testAccount.user,
          pass: testAccount.pass
        }
      });

      const info = await transporter.sendMail({
        from: '"Dealfty" <no-reply@dealfty.com>',
        to: email,
        subject: "Verify Account",
        html: `<a href="${link}">Verify</a>`
      });

      console.log("Preview URL:", nodemailer.getTestMessageUrl(info));
      return true;
    }

    // production logic here...

  } catch (err) {
    console.error(err);
    return false;
  }
}

// ==========================================
// ✅ VALIDATION FUNCTION (PURE)
// ==========================================
function validateInputs(name, email, password, terms, age) {
  if (!name || !email || !password) {
    return "All required fields must be filled";
  }

  // Email regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return "Invalid email format";
  }

  if (password.length < 6) {
    return "Password must be at least 6 characters";
  }

  if (!terms || !age) {
    return "Accept terms and confirm age";
  }

  return null;
}
//middleware for authorization
function requireAuth(req, res, next) {
  if (!req.session?.user_id) {
    return res.redirect("/unauthorized");
  }
  next();
}

function formatFullDate(date = new Date()) {
  return new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric"
  }).format(date);
}
function getTimeOfDay(date = new Date()) {
  const hour = date.getHours();

  if (hour < 12) return "Morning";
  if (hour < 17) return "Afternoon";
  return "Evening";
}
module.exports={validateInputs,sendVerificationEmail,requireAuth,formatFullDate,getTimeOfDay};
