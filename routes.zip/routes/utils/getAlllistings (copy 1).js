const { queryDB } = require("./dbHelpers");


async function getcountListingsofLoggedIN(loggedInUser) {
  try {
    const [
      revenueCount,
      listingCount,
      ordersCount,
      messagesCount,
      conversations,
      by_cat,
      recent_listings
    ] = await Promise.all([
      queryDB(
        "SELECT SUM(total_amount) AS total FROM orders WHERE seller_id=?",
        [loggedInUser]
      ),
      queryDB(
        "SELECT COUNT(*) AS total FROM listings WHERE user_id=?",
        [loggedInUser]
      ),
      queryDB(
        "SELECT COUNT(*) AS total FROM orders WHERE seller_id=?",
        [loggedInUser]
      ),
      queryDB(
        "SELECT COUNT(*) AS total FROM messages WHERE receiver_id=? AND is_read=?",
        [loggedInUser, 0]
      ),
      queryDB(
        `SELECT 
  m.sender_id,m.listing_id,
  u.name AS sender_name,
  u.avatar,
  COUNT(*) AS message_count,
  MAX(m.created_at) AS last_message_time
FROM messages m
JOIN users u ON u.id = m.sender_id
WHERE m.receiver_id = ? and is_read=?
GROUP BY m.sender_id, u.name, u.avatar
ORDER BY last_message_time DESC;`,
        [loggedInUser,0]
      ),
      queryDB(
        "SELECT category, COUNT(*) AS cnt FROM listings WHERE user_id = ? GROUP BY category",
        [loggedInUser]
      ),
      queryDB(
        "SELECT * FROM listings WHERE user_id = ? ORDER BY created_at DESC LIMIT 5",
        [loggedInUser]
      )
    ]);

    return {
      revenue_count: revenueCount?.[0]?.total ?? 0,
      listing_count: listingCount?.[0]?.total ?? 0,
      orders_count: ordersCount?.[0]?.total ?? 0,
      messages_count: messagesCount?.[0]?.total ?? 0,
      messages: conversations ?? [],
      category:by_cat ?? [],
      recents:recent_listings,
    };

  } catch (err) {
    console.error("Dashboard count error:", err);

    return {
      revenue_count: 0,
      listing_count: 0,
      orders_count: 0,
      messages_count: 0,
      messages: []
    };
  }
}

async function markMessagesAsRead(receiverId, senderId, listingId) {
  return new Promise((resolve, reject) => {
    db.query(
      `UPDATE messages 
       SET seen = 1 
       WHERE receiver_id = ? 
         AND sender_id = ? 
         AND listing_id = ? AND is_read=?`,
      [receiverId, senderId, listingId,1],
      (err, result) => {
        if (err) return reject(err);
        resolve(result);
      }
    );
  });
}

async function updateListing(listingId, userId, data) {
  try {
    const { title, price, category } = data;

    const result = await queryDB(
      `UPDATE listings 
       SET title = ?, price = ?, category = ? 
       WHERE id = ? AND user_id = ?`,
      [title, price, category, listingId, userId]
    );

    return result;
  } catch (err) {
    console.error("Update listing error:", err);
    throw err;
  }
}
module.exports = { getcountListingsofLoggedIN, markMessagesAsRead };
