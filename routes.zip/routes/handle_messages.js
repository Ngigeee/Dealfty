// routes/handle_messages.js
const express = require("express");
const { Server } = require("socket.io");
const { markMessagesAsRead } = require("./utils/getAlllistings");

module.exports = (db, sessionMiddleware, server) => {
  const router = express.Router();
  const io = new Server(server);

  const onlineUsers = new Map(); // userId -> socket

  io.use((socket, next) => {
    sessionMiddleware(socket.request, {}, next);
  });

  io.on("connection", (socket) => {
    const session = socket.request.session;
    if (!session || !session.user_id) return socket.disconnect(true);

    const userId = session.user_id;
    onlineUsers.set(userId, socket);
    console.log("User connected:", userId, socket.id);

    socket.on("chat message", (data) => {
      const { receiver_id, listing_id, msg } = data;
      if (!receiver_id || !listing_id || !msg) return;

      const insertQuery = `
        INSERT INTO messages
        (sender_id, receiver_id, listing_id, body, delivered, seen, created_at)
        VALUES (?, ?, ?, ?, 0, 0, NOW())
      `;

      db.query(insertQuery, [userId, receiver_id, listing_id, msg], (err, result) => {
        if (err) return socket.emit("error", "Error sending message");

        const messageId = result.insertId;

        socket.emit("message status", { id: messageId, status: "sent" });

        const notificationQuery = `
          INSERT INTO notifications
          (user_id, from_user, title,listing_id, type, body, is_read, created_at)
          VALUES (?, ?, "You have received a message",?, ?, ?, 0, NOW())
        `;

        db.query(
          notificationQuery,
          [receiver_id, userId, listing_id, "message", msg],
          (notifErr) => {
            if (notifErr) {
              console.error("Notification insert error:", notifErr);
            }
          }
        );

        const receiverSocket = onlineUsers.get(Number(receiver_id));
        const session = socket.request.session;
        if (receiverSocket) {
          receiverSocket.emit("chat message", {
            id: messageId,
            sender_id: userId,
           sender_name: session.user_name,
            body: msg,
            listing_id,
          });

          db.query("UPDATE messages SET delivered=1 WHERE id=?", [messageId]);
          socket.emit("message status", { id: messageId, status: "delivered" });

          receiverSocket.emit("new notification", {
            type: "message",
            from_user_id: userId,
            listing_id,
            message: msg,
          });
        }
      });
    });

    socket.on("message seen", (data) => {
      const { messageId } = data;
      if (!messageId) return;

      db.query("UPDATE messages SET seen=1 WHERE id=?", [messageId], (err) => {
        if (err) return console.error(err);

        db.query("SELECT sender_id FROM messages WHERE id=?", [messageId], (err, results) => {
          if (err || results.length === 0) return;

          const senderId = results[0].sender_id;
          const senderSocket = onlineUsers.get(Number(senderId));
          if (senderSocket) {
            senderSocket.emit("message status", { id: messageId, status: "seen" });
          }
        });
      });
    });

    socket.on("disconnect", () => {
      onlineUsers.delete(userId);
      console.log("User disconnected:", userId);
    });
  });

  router.get("/getmessagesbtwUsers", (req, res) => {
    const userId = req.session.user_id;
    const withUser = parseInt(req.query.withUser);
    const listingId = parseInt(req.query.listingId);

    if (!userId) return res.status(401).json({ error: "Unauthorized" });

    if (!withUser || !listingId) {
      return res.status(400).json({ error: "Missing parameters" });
    }

    const messagesQuery = `
      SELECT 
        m.id,
        m.sender_id,
        m.receiver_id,
        m.body,
        m.delivered,
        m.seen,
        m.created_at,
        u.name AS sender_name,
        u.profile_pic
      FROM messages m
      JOIN users u ON u.id = m.sender_id
      WHERE m.listing_id = ?
        AND ((m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?))
      ORDER BY m.created_at ASC
      LIMIT 50
    `;

    db.query(
      messagesQuery,
      [listingId, userId, withUser, withUser, userId],
      (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results || []);
      }
    );
  });

  router.get("/details", (req, res) => {
    const sellerId = parseInt(req.query.user);
    const listingId = parseInt(req.query.listing);

    if (!sellerId || !listingId) {
      return res.status(400).json({ error: "Missing parameters" });
    }

    const sql = `
      SELECT 
        u.id AS seller_id,
        u.name AS seller_name,
        u.account_type,
        u.profile_pic,
        l.id AS listing_id,
        l.title,
        l.price,
        l.image
      FROM users u
      JOIN listings l ON l.user_id = u.id
      WHERE u.id = ? AND l.id = ?
      LIMIT 1
    `;

    db.query(sql, [sellerId, listingId], (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      if (!results.length) return res.status(404).json({ error: "Not found" });

      res.json(results[0]);
    });
  });
  
  


  return { chatApp: router, io };
};
