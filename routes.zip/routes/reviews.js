const express = require("express");
const router = express.Router();

module.exports = (db) => {

  // GET /seller/reviews?id=<seller_id>
  router.get("/seller/reviews", (req, res) => {
    const sellerId = parseInt(req.query.id);
    if (!sellerId) return res.status(400).json({ error: "Missing seller ID" });

    const sql = `
      SELECT sr.rating, sr.review, sr.created_at, u.name AS reviewer_name
      FROM seller_reviews sr
      JOIN users u ON u.id = sr.reviewer_id
      WHERE sr.seller_id = ?
      ORDER BY sr.created_at DESC
      LIMIT 20
    `;

    db.query(sql, [sellerId], (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(results);
    });
  });

  // GET /reviews/mine
  router.get("/reviews/mine", (req, res) => {
    const sellerId = parseInt(req.query.seller_id);
    const listingId = parseInt(req.query.listing_id);
    const userId = req.session.user_id;

    if (!userId) {
      return res.status(401).json({ error: "Not logged in" });
    }

    if (!sellerId || !listingId) {
      return res.status(400).json({ error: "Missing parameters" });
    }

    const sql = `
      SELECT rating, review
      FROM seller_reviews
      WHERE seller_id = ? AND listing_id = ? AND reviewer_id = ?
      LIMIT 1
    `;

    db.query(sql, [sellerId, listingId, userId], (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ review: results[0] || null });
    });
  });

  // POST /reviews
  router.post("/reviews", (req, res) => {
    const { seller_id, listing_id, rating, review } = req.body;
    const user_id = req.session.user_id;

    if (!user_id) {
      return res.status(401).json({ error: "Please login to submit a review" });
    }

    if (!seller_id || !listing_id || !rating) {
      return res.status(400).json({ error: "Missing parameters" });
    }

    const sql = `
      INSERT INTO seller_reviews (seller_id, reviewer_id, listing_id, rating, review)
      VALUES (?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        rating = VALUES(rating),
        review = VALUES(review),
        created_at = NOW()
    `;

    db.query(sql, [seller_id, user_id, listing_id, rating, review], (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Review saved" });
    });
  });

  return router;
};
