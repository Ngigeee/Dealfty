const express = require("express");
const router = express.Router();
const { queryDB } = require("./utils/dbHelpers");
const { requireAuth } = require("./utils/functions");

// ------------------------------
// Static data
// ------------------------------
const categoryIcons = {
  Plumbing: "🔧",
  Electrical: "💡",
  Cleaning: "🧹",
  Painting: "🎨",
  "IT Support": "💻",
  Carpentry: "🪚",
  Welding: "🛠️",
  Mechanic: "🚗",
  Other: "🧰"
};

const categoryColors = [
  "#dff3e3",
  "#fff0cc",
  "#d9ecff",
  "#f3ddff",
  "#e7f7ef",
  "#ffe4e1",
  "#e8f0fe",
  "#fef3c7"
];

// ------------------------------
// Helpers
// ------------------------------
function mapProfessionalRow(row = {}) {
  return {
    id: Number(row.id || 0),
    user_id: Number(row.user_id || 0),
    category: row.category || "",
    description: row.description || "",
    location: row.location || "",
    pricing: row.pricing || "",
    category_icon: categoryIcons[row.category] || "🧰"
  };
}

// ------------------------------
// Page route
// ------------------------------
router.get("/professionals", (req, res) => {
  try {
    return res.render("professionals", {
      userName: req.session?.user_name || null,
      user_id: req.session?.user_id || null,
      title: "Hire Professionals"
    });
  } catch (error) {
    console.error("GET /professionals error:", error);
    return res.status(500).send("Could not load professionals page.");
  }
});

// ------------------------------
// API: bootstrap categories
// ------------------------------
router.get("/professionals/api/bootstrap", async (req, res) => {
  try {
    const rows = await queryDB(
      `
      SELECT DISTINCT category
      FROM professionals
      WHERE category IS NOT NULL
        AND TRIM(category) <> ''
      ORDER BY category ASC
      `
    );

    const categories = rows.map((row, index) => ({
      label: row.category,
      icon: categoryIcons[row.category] || "🧰",
      bg: categoryColors[index % categoryColors.length]
    }));

    return res.json({
      ok: true,
      categories
    });
  } catch (error) {
    console.error("GET /professionals/api/bootstrap error:", error);
    return res.status(500).json({
      ok: false,
      message: "Could not load professionals page data."
    });
  }
});

// ------------------------------
// API: list professionals
// frontend should call:
// /professionals/api/list?q=...&cat=...
// ------------------------------
router.get("/professionals/api/list", async (req, res) => {
  const q = String(req.query.q || "").trim();
  const cat = String(req.query.cat || "").trim();

  try {
    const where = ["1=1"];
    const params = [];

    if (q) {
      where.push(`(
        category LIKE ?
        OR description LIKE ?
        OR location LIKE ?
        OR pricing LIKE ?
      )`);
      const like = `%${q}%`;
      params.push(like, like, like, like);
    }

    if (cat) {
      where.push("category = ?");
      params.push(cat);
    }

    const sql = `
      SELECT
        id,
        user_id,
        category,
        description,
        location,
        pricing
      FROM professionals
      WHERE ${where.join(" AND ")}
      ORDER BY id DESC
    `;

    const rows = await queryDB(sql, params);
    const professionals = rows.map(mapProfessionalRow);

    return res.json({
      ok: true,
      professionals,
      count: professionals.length
    });
  } catch (error) {
    console.error("GET /professionals/api/list error:", error);
    return res.status(500).json({
      ok: false,
      message: "Could not load professionals."
    });
  }
});

// ------------------------------
// API: create professional
// frontend should POST to:
// /professionals/api/upload
// ------------------------------
router.post("/professionals/api/upload", requireAuth, async (req, res) => {
  try {
    const userId = req.session?.user_id || null;

    const category = String(req.body.category || "").trim();
    const description = String(req.body.description || "").trim();
    const location = String(req.body.location || "").trim();
    const pricing = String(req.body.pricing || "").trim();

    if (!userId) {
      return res.status(401).json({
        ok: false,
        message: "You must be logged in."
      });
    }

    if (!category) {
      return res.status(400).json({
        ok: false,
        message: "Category is required."
      });
    }

    if (!description) {
      return res.status(400).json({
        ok: false,
        message: "Description is required."
      });
    }

    if (!location) {
      return res.status(400).json({
        ok: false,
        message: "Location is required."
      });
    }

    if (!pricing) {
      return res.status(400).json({
        ok: false,
        message: "Pricing is required."
      });
    }

    await queryDB(
      `
      INSERT INTO professionals
      (
        user_id,
        category,
        description,
        location,
        pricing
      )
      VALUES (?,?,?,?,?)
      `,
      [userId, category, description, location, pricing]
    );

    return res.json({
      ok: true,
      message: "Professional published successfully."
    });
  } catch (error) {
    console.error("POST /professionals/api/upload error:", error);
    return res.status(500).json({
      ok: false,
      message: "Could not publish professional."
    });
  }
});

module.exports = router;
