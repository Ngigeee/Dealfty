const express = require("express");
const router = express.Router();
const axios = require("axios");
const { queryDB } = require("./utils/dbHelpers");
const { requireAuth } = require("./utils/functions");

// ------------------------------
// Static data
// ------------------------------
const kenyaCounties = [
  "Baringo","Bomet","Bungoma","Busia","Elgeyo-Marakwet","Embu","Garissa",
  "Homa Bay","Isiolo","Kajiado","Kakamega","Kericho","Kiambu","Kilifi",
  "Kirinyaga","Kisii","Kisumu","Kitui","Kwale","Laikipia","Lamu","Machakos",
  "Makueni","Mandera","Marsabit","Meru","Migori","Mombasa","Murang'a",
  "Nairobi","Nakuru","Nandi","Narok","Nyamira","Nyandarua","Nyeri",
  "Samburu","Siaya","Taita-Taveta","Tana River","Tharaka-Nithi","Trans Nzoia",
  "Turkana","Uasin Gishu","Vihiga","Wajir","West Pokot"
];

const subCountyMap = {
  Nairobi: ["Westlands","Dagoretti North","Dagoretti South","Langata","Kibra","Roysambu","Kasarani","Ruaraka","Embakasi South","Embakasi North","Embakasi Central","Embakasi East","Embakasi West","Makadara","Kamukunji","Starehe","Mathare"],
  Kiambu: ["Gatundu North","Gatundu South","Githunguri","Juja","Kabete","Kiambaa","Kiambu","Kikuyu","Limuru","Ruiru","Thika Town","Lari"]
};

const pricing = {
  BASE: {
    motorcycle: { standard: 300, express: 450 },
    car_van: { standard: 800, express: 1200 },
    truck: { standard: 1500, express: 2200 }
  },
  PER_KM: {
    motorcycle: { standard: 35, express: 50 },
    car_van: { standard: 70, express: 95 },
    truck: { standard: 120, express: 160 }
  },
  SIZE_M: {
    small: 1,
    medium: 1.2,
    large: 1.5,
    xlarge: 1.9
  }
};

// ------------------------------
// Helpers
// ------------------------------
function safeFirstName(name = "User") {
  return String(name).trim().split(" ")[0] || "User";
}

function validateDelivery(body) {
  const errors = [];

  if (!body.pickup) errors.push("Pickup required");
  if (!body.dropoff) errors.push("Dropoff required");
  if (!body.package_desc) errors.push("Package description required");
  if (!body.recipient_name) errors.push("Recipient name required");
  if (!body.recipient_phone) errors.push("Recipient phone required");

  return errors;
}

function computeCost({ vehicle, service, package_size, distanceKm }) {
  if (package_size === "xl") package_size = "xlarge";

  const base = pricing.BASE?.[vehicle]?.[service] || 300;
  const perKm = pricing.PER_KM?.[vehicle]?.[service] || 35;
  const mult = pricing.SIZE_M?.[package_size] || 1;

  return Math.round((base + perKm * distanceKm) * mult);
}

// ------------------------------
// API: bootstrap
// ------------------------------
router.get("/transport/api/bootstrap", requireAuth, async (req, res) => {
  try {
    const userId = req.session.user_id;
    const name = req.session.user_name || "User";

    return res.json({
      ok: true,
      user: {
        id: userId,
        name,
        firstName: safeFirstName(name)
      },
      counties: kenyaCounties,
      subCountyMap,
      pricing
    });
  } catch (err) {
    return res.status(500).json({ ok: false, message: "Bootstrap failed" });
  }
});

// ------------------------------
// API: counties
// ------------------------------
router.get("/transport/api/counties", requireAuth, (req, res) => {
  res.json({ ok: true, counties: kenyaCounties });
});

// ------------------------------
// API: subcounties
// ------------------------------
router.get("/transport/api/subcounties/:county", requireAuth, (req, res) => {
  const county = req.params.county;
  res.json({
    ok: true,
    subcounties: subCountyMap[county] || []
  });
});

// ------------------------------
// API: search locations
// ------------------------------
router.get("/transport/api/search", requireAuth, async (req, res) => {
  const q = req.query.q;
  if (!q) return res.json({ ok: true, results: [] });

  try {
    const { data } = await axios.get("https://nominatim.openstreetmap.org/search", {
      params: {
        q,
        format: "json",
        limit: 5,
        countrycodes: "ke"
      },
      headers: { "User-Agent": "app" }
    });

    const results = data.map(i => ({
      name: i.display_name,
      lat: Number(i.lat),
      lng: Number(i.lon)
    }));

    res.json({ ok: true, results });

  } catch {
    res.status(500).json({ ok: false, message: "Search failed" });
  }
});

// ------------------------------
// API: reverse geocode
// ------------------------------
router.get("/transport/api/reverse", requireAuth, async (req, res) => {
  const { lat, lng } = req.query;

  try {
    const { data } = await axios.get("https://nominatim.openstreetmap.org/reverse", {
      params: {
        lat,
        lon: lng,
        format: "json"
      }
    });

    res.json({
      ok: true,
      address: data.display_name
    });

  } catch {
    res.status(500).json({ ok: false });
  }
});

// ------------------------------
// API: route + cost
// ------------------------------
router.post("/transport/api/route", requireAuth, async (req, res) => {
  const { pickupLat, pickupLng, dropoffLat, dropoffLng, vehicle, service, package_size } = req.body;

  try {
    const url = `https://router.project-osrm.org/route/v1/driving/${pickupLng},${pickupLat};${dropoffLng},${dropoffLat}`;

    const { data } = await axios.get(url);

    const route = data.routes[0];
    const distanceKm = route.distance / 1000;
    const durationMin = Math.round(route.duration / 60);

    const cost = computeCost({
      vehicle,
      service,
      package_size,
      distanceKm
    });

    res.json({
      ok: true,
      distanceKm,
      durationMin,
      estimatedCost: cost,
      geometry: route.geometry
    });

  } catch {
    res.status(500).json({ ok: false, message: "Route failed" });
  }
});

// ------------------------------
// API: create request
// ------------------------------
router.post("/transport/api/request", requireAuth, async (req, res) => {
  const userId = req.session.user_id;
  const body = req.body;

  const errors = validateDelivery(body);
  if (errors.length) {
    return res.status(400).json({
      ok: false,
      errors
    });
  }

  try {
    await queryDB(
      `INSERT INTO transport_requests
      (user_id,pickup_location,dropoff_location,vehicle_type,service_type,
       pickup_datetime,package_description,package_size,recipient_name,
       recipient_phone,notes,status,estimated_cost,created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,'pending',?,NOW())`,
      [
        userId,
        body.pickup,
        body.dropoff,
        body.vehicle,
        body.service,
        body.datetime,
        body.package_desc,
        body.package_size === "xl" ? "xlarge" : body.package_size,
        body.recipient_name,
        body.recipient_phone,
        body.notes,
        body.estimated_cost
      ]
    );

    res.json({
      ok: true,
      message: "Request created successfully"
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({
      ok: false,
      message: "Failed to save request"
    });
  }
});

module.exports = router;
