const express = require("express");
const router = express.Router();
const { queryDB } = require("../utils/dbHelpers");
const { requireAuth } = require("../utils/functions");

router.get("/api/business/messages", requireAuth, async (req, res) => {
  try {
    const userId = req.session.user_id;

    const sql = `
      SELECT
        latest.id,
        latest.sender_id,
        latest.receiver_id,
        latest.listing_id,
        latest.body AS last_msg,
        latest.created_at,
        latest.is_read,
        latest.delivered,
        latest.seen,

        grouped.other_user_id,
        grouped.message_count,
        grouped.unread_count,

        CASE
          WHEN latest.sender_id = ? THEN 1
          ELSE 0
        END AS sent_by_me,

        COALESCE(u.name, CONCAT('User ', grouped.other_user_id)) AS other_name,
        u.account_type AS other_type,

        l.title AS listing_title,
        l.price AS listing_price,
        l.type AS listing_type,
        COALESCE(l.main_photo, l.image, l.service_icon) AS listing_thumb

      FROM (
        SELECT
          CASE
            WHEN m.sender_id = ? THEN m.receiver_id
            ELSE m.sender_id
          END AS other_user_id,

          MAX(m.id) AS latest_message_id,
          COUNT(*) AS message_count,

          SUM(
            CASE
              WHEN m.receiver_id = ? AND m.is_read = 0 THEN 1
              ELSE 0
            END
          ) AS unread_count

        FROM messages m
        WHERE m.sender_id = ? OR m.receiver_id = ?
        GROUP BY
          CASE
            WHEN m.sender_id = ? THEN m.receiver_id
            ELSE m.sender_id
          END
      ) grouped

      INNER JOIN messages latest
        ON latest.id = grouped.latest_message_id

      LEFT JOIN users u
        ON u.id = grouped.other_user_id

      LEFT JOIN listings l
        ON l.id = latest.listing_id

      ORDER BY latest.created_at DESC
    `;

    const conversations = await queryDB(sql, [
      userId, // sent_by_me
      userId, // CASE other_user_id
      userId, // unread_count
      userId, // WHERE sender_id
      userId, // WHERE receiver_id
      userId  // GROUP BY CASE
    ]);

    return res.status(200).json({
      statuscode: "success",
      conversations
    });
  } catch (error) {
    console.error("business messages error:", error);
    return res.status(500).json({
      statuscode: "error",
      message: error.message || "Failed to load conversations."
    });
  }
});

module.exports = router;
