const express=require("express");
const bcrypt = require("bcrypt"); 
const crypto = require("crypto");
const {validateInputs,sendVerificationEmail,requireAuth} = require("./functions");
const router=express.Router();

module.exports= (db)=>{
// ==========================================
// ✅ REGISTER API (FETCH TARGET)
// ==========================================
router.post("/register_user", async (req, res) => {
  
  try {
    const { name, email, password, phone, terms, age } = req.body;

    // ✅ Validate input
    const error = validateInputs(name, email, password, terms, age);
    if (error) {
      return res.status(400).json({ error });
    }

    // ✅ Check if email exists
    const checkQuery = "SELECT id FROM users WHERE email = ?";
    db.query(checkQuery, [email], async (err, results) => {
      if (err) {
        return res.status(500).json({ error: "Database error" });
      }

      if (results.length > 0) {
        return res.status(400).json({ error: "Email already registered" });
      }

      // ✅ Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      //generate token
      
      let token= crypto.randomBytes(16).toString("hex");
      

      // ✅ Insert user
      const insertQuery =
        "INSERT INTO users (name, email, password, phone,token) VALUES (?, ?, ?, ?,?)";

      db.query(
        insertQuery,
        [name, email, hashedPassword, phone,token],
        async (err, result) => {
          if (err) {
            return res.status(500).json({ error: "Insert failed" });
          }

          try {
      const link = `http://localhost:3000/verify_sent?email=${encodeURIComponent(email)}&token=${token}`;
      
      await sendVerificationEmail(email, link,token);

      return res.redirect(`/verify?email=${email}`);

    } catch (emailErr) {
      console.error("Email error:", emailErr);

      // still allow user creation even if email fails
      return res.redirect(`/verify_sent?email=${email}`);
    }
        }
      );
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

//verify email

router.post("/email_verification", (req, res) => {
  const { email, token } = req.body;

  if (!email || !token) {
    return res.status(400).json({ status: "fail", message: "Email or token not present" });
  }

  const sql = "SELECT token, email_verified FROM users WHERE email = ?";
  db.query(sql, [email], (err, results) => {
    if (err) {
      return res.status(500).json({ status: "fail", message: "Database error" });
    }

    if (results.length === 0) {
      return res.status(400).json({ status: "fail", message: "User not found" });
    }

    const user = results[0];

    if (user.email_verified) {
      return res.status(200).json({ status: "success", message: "Email already verified" });
    }

    if (user.token !== token) {
      return res.status(400).json({ status: "fail", message: "Invalid token" });
    }

    // ✅ Update email_verified and account_type
    const updateDB = "UPDATE users SET email_verified = ?, account_type = ? WHERE email = ? AND token = ?";
    db.query(updateDB, [1, "individual", email, token], (err, updateResult) => {
      if (err) {
        return res.status(500).json({ status: "fail", message: "Error verifying email" });
      }

      if (updateResult.affectedRows > 0) {
        return res.status(200).json({ status: "success", message: "Email verified successfully" });
      } else {
        return res.status(400).json({ status: "fail", message: "Failed to update user" });
      }
    });
  });
});



return router;
}
