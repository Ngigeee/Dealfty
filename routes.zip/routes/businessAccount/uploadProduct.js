const express = require("express");
const path = require("path");
const multer = require("multer");

const router = express.Router();
const { queryDB } = require("../utils/dbHelpers");
const {validateInputs,sendVerificationEmail,requireAuth,formatFullDate,getTimeOfDay} = require("../utils/functions");
// storage config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "public/uploads/products");
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueName + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

router.post(
  "/upload_product",requireAuth,
  upload.array("photos[]", 10),
  async (req, res) => {
    try {
      const userId = req.session.user_id;

      const {
        title = "",
        description = "",
        sku = "",
        quantity = 0,
        category = "",
        condition = "",
        price = 0,
        original_price = 0,
        negotiable = "0",
        location = "",
        delivery = "0",
        pickup = "0",
        contact_phone = "",
        phone_consent = "0"
      } = req.body;

      if (!title.trim() || !description.trim() || !category.trim() || !price) {
        return res.status(400).json({
          statuscode: "error",
          message: "Required fields are missing"
        });
      }

      let mainPhoto = null;

      if (req.files && req.files.length > 0) {
        mainPhoto = req.files[0].filename;
      }

      const productResult = await queryDB(
        `INSERT INTO listings
        (
          user_id,
          title,
          description,
          sku,
          quantity,
          category,
          \`condition\`,
          price,
          original_price,
          negotiable,
          location,
          delivery,
          pickup,
          contact_phone,
          phone_consent,
          main_photo,
          created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          userId,
          title.trim(),
          description.trim(),
          sku.trim(),
          Number(quantity) || 0,
          category.trim(),
          condition.trim(),
          Number(price) || 0,
          Number(original_price) || 0,
          negotiable === "1" ? 1 : 0,
          location.trim(),
          delivery === "1" ? 1 : 0,
          pickup === "1" ? 1 : 0,
          contact_phone.trim(),
          phone_consent === "1" ? 1 : 0,
          mainPhoto
        ]
      );

      const listingId = productResult.insertId;

      if (req.files && req.files.length > 0) {
        for (const file of req.files) {
          await queryDB(
            `INSERT INTO listings (listing_id, images, created_at)
             VALUES (?, ?, NOW())`,
            [listingId, file.filename]
          );
        }
      }

      return res.json({
        statuscode: "success",
        message: "Product uploaded successfully",
        listing_id: listingId
      });
    } catch (err) {
      console.error(err);
      return res.status(500).json({
        statuscode: "error",
        message: "Server error while uploading product"
      });
    }
  }
);

module.exports = router;
