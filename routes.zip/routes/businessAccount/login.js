const express=require("express");
const bcrypt = require("bcrypt"); 
const router=express.Router();

module.exports=(db)=>{

//login user
router.post("/login_user", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Please make sure no field is empty" });
  }

  const loginSQL = "SELECT id,name, password, email FROM users WHERE email = ? AND account_type = 'business'";

  db.query(loginSQL, [email], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error while logging in" });

    if (results.length === 0) {
      return res.status(400).json({ error: "User not found" });
    }

    const user = results[0];

    // bcrypt.compare is async, so we pass a callback
    bcrypt.compare(password, user.password, (err, isMatch) => {
      if (err) return res.status(500).json({ error: "Error checking password" });

      if (!isMatch) {
        return res.status(400).json({ error: "Password is incorrect" });
      }
       
      // Save user session
      req.session.user_id = user.id;
      req.session.user_name = user.name;
      return res.status(200).json({ message: "Login successful" });
      
    });
  });
});
 //check log in status
router.get("/isLoggedIN", (req, res) => {
  const isLoggedIn = !!(req.session.user_id && req.session.user_name);

  res.json({ loggedIn: isLoggedIn });
});


return router;
}
