const express = require("express");
const bcrypt = require("bcrypt");
const router = express.Router();
const { queryDB } = require("../utils/dbHelpers");
const { requireAuth } = require("../utils/functions");

// GET page
router.get("/settings", requireAuth, async (req, res) => {
  try {
    const userId = req.session.user_id;
    const active_tab = req.query.tab || "account";

    const users = await queryDB(
      "SELECT id, name, email, phone, created_at, password FROM users WHERE id = ? LIMIT 1",
      [userId]
    );

    const profiles = await queryDB(
      "SELECT * FROM business_profiles WHERE user_id = ? LIMIT 1",
      [userId]
    );

    const user = users[0] || {};
    const profile = profiles[0] || {};

    const memberSince = user.created_at
      ? new Date(user.created_at).toLocaleString("en-US", {
          month: "long",
          year: "numeric"
        })
      : "";

    const biz_name = profile.business_name || user.name || "";

    return res.render("businessAccount/business_settings", {
      error: null,
      success: null,
      active_tab,
      user,
      profile,
      biz_name,
      memberSince,
      userAgent: req.headers["user-agent"] || "",
      ipAddress: req.ip || ""
    });
  } catch (error) {
    console.error("GET /settings error:", error);

    return res.status(500).render("businessAccount/business_settings", {
      error: "Failed to load settings page",
      success: null,
      active_tab: req.query.tab || "account",
      user: {},
      profile: {},
      biz_name: "",
      memberSince: "",
      userAgent: req.headers["user-agent"] || "",
      ipAddress: req.ip || ""
    });
  }
});

// ACCOUNT
router.post("/settings/account", requireAuth, async (req, res) => {
  try {
    const userId = req.session.user_id;
    const { name, email, phone } = req.body;

    if (!name || !email) {
      return res.status(400).json({ message: "Name and email are required" });
    }

    await queryDB(
      "UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?",
      [name.trim(), email.trim(), phone?.trim() || null, userId]
    );

    return res.json({ message: "Account details updated successfully" });
  } catch (error) {
    console.error("POST /settings/account error:", error);
    return res.status(500).json({ message: "Failed to update account details" });
  }
});

// PASSWORD
router.post("/settings/password", requireAuth, async (req, res) => {
  try {
    const userId = req.session.user_id;
    const { current_password, new_password, confirm_password } = req.body;

    if (!current_password || !new_password || !confirm_password) {
      return res.status(400).json({ message: "All password fields are required" });
    }

    if (new_password.length < 8) {
      return res.status(400).json({ message: "New password must be at least 8 characters" });
    }

    if (new_password !== confirm_password) {
      return res.status(400).json({ message: "New passwords do not match" });
    }

    const users = await queryDB(
      "SELECT password FROM users WHERE id = ? LIMIT 1",
      [userId]
    );

    const user = users[0];

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const match = await bcrypt.compare(current_password, user.password);
    if (!match) {
      return res.status(400).json({ message: "Current password is incorrect" });
    }

    const hashedPassword = await bcrypt.hash(new_password, 10);

    await queryDB(
      "UPDATE users SET password = ? WHERE id = ?",
      [hashedPassword, userId]
    );

    return res.json({ message: "Password changed successfully" });
  } catch (error) {
    console.error("POST /settings/password error:", error);
    return res.status(500).json({ message: "Failed to change password" });
  }
});

// NOTIFICATIONS
router.post("/settings/notifications", requireAuth, async (req, res) => {
  try {
    const userId = req.session.user_id;

    const {
      notif_new_order = 0,
      notif_new_message = 0,
      notif_order_status = 0,
      notif_low_stock = 0,
      notif_marketing = 0
    } = req.body;

    await queryDB(
      `UPDATE business_profiles
       SET notif_new_order = ?, notif_new_message = ?, notif_order_status = ?, notif_low_stock = ?, notif_marketing = ?
       WHERE user_id = ?`,
      [
        Number(notif_new_order),
        Number(notif_new_message),
        Number(notif_order_status),
        Number(notif_low_stock),
        Number(notif_marketing),
        userId
      ]
    );

    return res.json({ message: "Notification preferences saved successfully" });
  } catch (error) {
    console.error("POST /settings/notifications error:", error);
    return res.status(500).json({ message: "Failed to save notification settings" });
  }
});

// STORE
router.post("/settings/store", requireAuth, async (req, res) => {
  try {
    const userId = req.session.user_id;

    const {
      auto_reply = 0,
      show_phone = 0,
      allow_offers = 0,
      min_order = 0,
      delivery_days = "",
      store_notice = ""
    } = req.body;

    await queryDB(
      `UPDATE business_profiles
       SET auto_reply = ?, show_phone = ?, allow_offers = ?, min_order = ?, delivery_days = ?, store_notice = ?
       WHERE user_id = ?`,
      [
        Number(auto_reply),
        Number(show_phone),
        Number(allow_offers),
        Number(min_order),
        delivery_days || null,
        store_notice || null,
        userId
      ]
    );

    return res.json({ message: "Store settings saved successfully" });
  } catch (error) {
    console.error("POST /settings/store error:", error);
    return res.status(500).json({ message: "Failed to save store settings" });
  }
});

// DEACTIVATE
router.post("/settings/deactivate", requireAuth, async (req, res) => {
  try {
    const userId = req.session.user_id;
    const { confirm_text } = req.body;

    if (confirm_text !== "DEACTIVATE") {
      return res.status(400).json({ message: "Confirmation text is incorrect" });
    }

    await queryDB(
      "UPDATE business_profiles SET account_status = 'inactive' WHERE user_id = ?",
      [userId]
    );

    return res.json({ message: "Business account deactivated successfully" });
  } catch (error) {
    console.error("POST /settings/deactivate error:", error);
    return res.status(500).json({ message: "Failed to deactivate account" });
  }
});

module.exports = router;
