const express = require("express");
const path = require("path");
const multer = require("multer");

const router = express.Router();
const { queryDB } = require("../utils/dbHelpers");
const {
  requireAuth
} = require("../utils/functions");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "public/uploads/products");
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueName + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

router.post(
  "/upload_service",
  requireAuth,
  upload.single("service_photo"),
  async (req, res) => {
    try {
      const userId = req.session.user_id;

      const {
        title = "",
        description = "",
        category = "",
        location = "",
        duration = "",
        rate = 0,
        rate_type = "per job",
        negotiable = "0",
        contact_phone = "",
        phone_consent = "0"
      } = req.body;

      if (!title.trim() || !description.trim() || !category.trim()) {
        return res.status(400).json({
          statuscode: "error",
          message: "Required fields are missing"
        });
      }

      let mainPhoto = null;

      if (req.file) {
        mainPhoto = req.file.filename;
      }

      const productResult = await queryDB(
        `INSERT INTO listings
        (
          user_id,
          title,
          description,
          category,
          price,
          negotiable,
          location,
          contact_phone,
          phone_consent,
          main_photo,
          type,
          created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          userId,
          title.trim(),
          description.trim(),
          category.trim(),
          Number(rate) || 0,
          negotiable === "1" ? 1 : 0,
          location.trim(),
          contact_phone.trim(),
          phone_consent === "1" ? 1 : 0,
          mainPhoto,
          "service"
        ]
      );

      return res.json({
        statuscode: "success",
        message: "service uploaded successfully",
        listing_id: productResult.insertId
      });
    } catch (err) {
      console.error(err);
      return res.status(500).json({
        statuscode: "error",
        message: "Server error while uploading service"
      });
    }
  }
);

module.exports = router;
