const express = require("express");
const router = express.Router();
const { queryDB } = require("../utils/dbHelpers");
const { requireAuth } = require("../utils/functions");

/*
  GET /api/business/profile
*/
router.get("/api/business/profile", requireAuth, async (req, res) => {
  try {
    const userId = req.session.user_id;

    let profileRows = await queryDB(
      `
      SELECT
        id,
        user_id,
        business_name,
        category,
        phone,
        email,
        location,
        description,
        logo,
        is_verified,
        created_at,
        status
      FROM business_profiles
      WHERE user_id = ?
      LIMIT 1
      `,
      [userId]
    );

    if (!profileRows.length) {
      await queryDB(
        `
        INSERT INTO business_profiles (
          user_id,
          business_name,
          phone,
          status,
          is_verified
        )
        VALUES (?, ?, ?, 'pending', 'no')
        `,
        [userId, "My Business", ""]
      );

      profileRows = await queryDB(
        `
        SELECT
          id,
          user_id,
          business_name,
          category,
          phone,
          email,
          location,
          description,
          logo,
          is_verified,
          created_at,
          status
        FROM business_profiles
        WHERE user_id = ?
        LIMIT 1
        `,
        [userId]
      );
    }

    const profile = profileRows[0] || {};

    const listingRows = await queryDB(
      `SELECT COUNT(*) AS total FROM listings WHERE user_id = ?`,
      [userId]
    );

    const orderRows = await queryDB(
      `SELECT COUNT(*) AS total FROM orders WHERE seller_id = ?`,
      [userId]
    );

    const messageRows = await queryDB(
      `
      SELECT COUNT(*) AS total
      FROM messages
      WHERE sender_id = ? OR receiver_id = ?
      `,
      [userId, userId]
    );

    return res.status(200).json({
      statuscode: "success",
      profile,
      stats: {
        listings: Number(listingRows[0]?.total || 0),
        orders: Number(orderRows[0]?.total || 0),
        messages: Number(messageRows[0]?.total || 0)
      }
    });
  } catch (error) {
    console.error("business profile get error:", error);
    return res.status(500).json({
      statuscode: "error",
      message: "Failed to load business profile."
    });
  }
});

/*
  POST /api/business/profile
*/
router.post("/api/business/profile", requireAuth, async (req, res) => {
  try {
    const userId = req.session.user_id;

    let {
      business_name = "",
      category = "",
      phone = "",
      email = "",
      location = "",
      description = ""
    } = req.body;

    business_name = String(business_name).trim();
    category = String(category).trim();
    phone = String(phone).trim();
    email = String(email).trim();
    location = String(location).trim();
    description = String(description).trim();

    if (!business_name) {
      return res.status(400).json({
        statuscode: "error",
        message: "Business name is required."
      });
    }

    const existing = await queryDB(
      `SELECT id FROM business_profiles WHERE user_id = ? LIMIT 1`,
      [userId]
    );

    if (existing.length) {
      await queryDB(
        `
        UPDATE business_profiles
        SET
          business_name = ?,
          category = ?,
          phone = ?,
          email = ?,
          location = ?,
          description = ?
        WHERE user_id = ?
        `,
        [business_name, category, phone, email, location, description, userId]
      );
    } else {
      await queryDB(
        `
        INSERT INTO business_profiles (
          user_id,
          business_name,
          category,
          phone,
          email,
          location,
          description,
          is_verified,
          status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, 'no', 'pending')
        `,
        [userId, business_name, category, phone, email, location, description]
      );
    }

    const profileRows = await queryDB(
      `
      SELECT
        id,
        user_id,
        business_name,
        category,
        phone,
        email,
        location,
        description,
        logo,
        is_verified,
        created_at,
        status
      FROM business_profiles
      WHERE user_id = ?
      LIMIT 1
      `,
      [userId]
    );

    const listingRows = await queryDB(
      `SELECT COUNT(*) AS total FROM listings WHERE user_id = ?`,
      [userId]
    );

    const orderRows = await queryDB(
      `SELECT COUNT(*) AS total FROM orders WHERE seller_id = ?`,
      [userId]
    );

    const messageRows = await queryDB(
      `
      SELECT COUNT(*) AS total
      FROM messages
      WHERE sender_id = ? OR receiver_id = ?
      `,
      [userId, userId]
    );

    return res.status(200).json({
      statuscode: "success",
      message: "Business profile saved successfully.",
      profile: profileRows[0] || {},
      stats: {
        listings: Number(listingRows[0]?.total || 0),
        orders: Number(orderRows[0]?.total || 0),
        messages: Number(messageRows[0]?.total || 0)
      }
    });
  } catch (error) {
    console.error("business profile save error:", error);
    return res.status(500).json({
      statuscode: "error",
      message: "Failed to save business profile."
    });
  }
});

module.exports = router;
