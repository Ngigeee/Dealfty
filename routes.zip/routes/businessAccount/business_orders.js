const express = require("express");
const router = express.Router();
const { queryDB } = require("../utils/dbHelpers");
const { requireAuth } = require("../utils/functions");

/*
  GET /api/business/orders/stats?q=
*/
router.get("/api/business/orders/stats", requireAuth, async (req, res) => {
  try {
    const sellerId = req.session.user_id;
    const q = String(req.query.q || "").trim();

    let searchSql = "";
    const searchParams = [sellerId];

    if (q) {
      searchSql = `
        AND (
          CAST(id AS CHAR) LIKE ?
          OR CAST(buyer_id AS CHAR) LIKE ?
          OR CAST(listing_id AS CHAR) LIKE ?
          OR CAST(seller_id AS CHAR) LIKE ?
          OR note LIKE ?
          OR status LIKE ?
        )
      `;
      const like = `%${q}%`;
      searchParams.push(like, like, like, like, like, like);
    }

    const statsSql = `
      SELECT
        COUNT(*) AS all_orders,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending,
        SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) AS confirmed,
        SUM(CASE WHEN status = 'shipped' THEN 1 ELSE 0 END) AS shipped,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled,
        SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END) AS total_revenue
      FROM orders
      WHERE seller_id = ?
      ${searchSql}
    `;

    const rows = await queryDB(statsSql, searchParams);
    const row = rows[0] || {};

    return res.json({
      stats: {
        all: Number(row.all_orders || 0),
        pending: Number(row.pending || 0),
        confirmed: Number(row.confirmed || 0),
        shipped: Number(row.shipped || 0),
        completed: Number(row.completed || 0),
        cancelled: Number(row.cancelled || 0),
        total_revenue: Number(row.total_revenue || 0)
      }
    });
  } catch (error) {
    console.error("orders stats error:", error);
    return res.status(500).json({ message: "Failed to load order stats." });
  }
});

/*
  GET /api/business/orders?status=&q=&page=&limit=
*/
router.get("/api/business/orders", requireAuth, async (req, res) => {
  try {
    const sellerId = req.session.user_id;
    const status = String(req.query.status || "all").trim();
    const q = String(req.query.q || "").trim();
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.max(parseInt(req.query.limit, 10) || 10, 1);
    const offset = (page - 1) * limit;

    const allowedStatuses = ["all", "pending", "confirmed", "shipped", "completed", "cancelled"];
    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({ message: "Invalid status filter." });
    }

    let whereSql = `WHERE seller_id = ?`;
    const params = [sellerId];

    if (status !== "all") {
      whereSql += ` AND status = ?`;
      params.push(status);
    }

    if (q) {
      whereSql += `
        AND (
          CAST(id AS CHAR) LIKE ?
          OR CAST(buyer_id AS CHAR) LIKE ?
          OR CAST(listing_id AS CHAR) LIKE ?
          OR CAST(seller_id AS CHAR) LIKE ?
          OR note LIKE ?
          OR status LIKE ?
        )
      `;
      const like = `%${q}%`;
      params.push(like, like, like, like, like, like);
    }

    const countSql = `
      SELECT COUNT(*) AS total
      FROM orders
      ${whereSql}
    `;

    const countRows = await queryDB(countSql, params);
    const totalCount = Number(countRows[0]?.total || 0);
    const totalPages = Math.ceil(totalCount / limit);

    const dataSql = `
      SELECT
        id,
        buyer_id,
        listing_id,
        total_amount,
        status,
        total,
        seller_id,
        created_at,
        note
      FROM orders
      ${whereSql}
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `;

    const dataParams = [...params, limit, offset];
    const orders = await queryDB(dataSql, dataParams);

    return res.json({
      orders,
      page,
      total_pages: totalPages,
      total_count: totalCount
    });
  } catch (error) {
    console.error("orders list error:", error);
    return res.status(500).json({ message: "Failed to load orders." });
  }
});

/*
  PATCH /api/business/orders/:id/status
  body: { status: "confirmed" }
*/
router.patch("/api/business/orders/:id/status", requireAuth, async (req, res) => {
  try {
    const sellerId = req.session.user_id;
    const orderId = parseInt(req.params.id, 10);
    const status = String(req.body.status || "").trim();

    const allowedStatuses = ["pending", "confirmed", "shipped", "completed", "cancelled"];
    if (!orderId || Number.isNaN(orderId)) {
      return res.status(400).json({ message: "Invalid order ID." });
    }

    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({ message: "Invalid status value." });
    }

    const existingRows = await queryDB(
      `SELECT id, status, seller_id FROM orders WHERE id = ? AND seller_id = ? LIMIT 1`,
      [orderId, sellerId]
    );

    if (!existingRows.length) {
      return res.status(404).json({ message: "Order not found." });
    }

    await queryDB(
      `UPDATE orders SET status = ? WHERE id = ? AND seller_id = ?`,
      [status, orderId, sellerId]
    );

    return res.json({
      message: `Order status updated to ${status}.`
    });
  } catch (error) {
    console.error("order update error:", error);
    return res.status(500).json({ message: "Failed to update order status." });
  }
});

module.exports = router;
