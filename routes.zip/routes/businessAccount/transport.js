const express = require("express");
const router = express.Router();
const { requireAuth } = require("../utils/functions");
const { queryDB } = require("../utils/dbHelpers");

router.post("/upload_transport", requireAuth, async (req, res) => {
  try {
    const userId = req.session.user_id;

    let {
      vehicle_type = "",
      service_type = "",
      title = "",
      description = "",
      location = "",
      plate = "",
      capacity = "",
      rate = "",
      rate_type = "",
      negotiable = 0,
      phone = "",
      availability = ""
    } = req.body;

    vehicle_type = String(vehicle_type).trim();
    service_type = String(service_type).trim();
    title = String(title).trim();
    description = String(description).trim();
    location = String(location).trim();
    plate = String(plate).trim();
    capacity = String(capacity).trim();
    rate_type = String(rate_type).trim();
    phone = String(phone).trim();
    availability = String(availability).trim();
    negotiable = Number(negotiable) ? 1 : 0;
    rate = rate === "" ? 0 : Number(rate);

    if (!vehicle_type) {
      return res.status(400).json({ message: "Vehicle type is required." });
    }

    if (!service_type) {
      return res.status(400).json({ message: "Service type is required." });
    }

    if (!title) {
      return res.status(400).json({ message: "Title is required." });
    }

    if (!description) {
      return res.status(400).json({ message: "Description is required." });
    }

    if (!location) {
      return res.status(400).json({ message: "Location is required." });
    }

    if (!phone) {
      return res.status(400).json({ message: "Phone number is required." });
    }

    if (Number.isNaN(rate) || rate < 0) {
      return res.status(400).json({ message: "Rate must be a valid number." });
    }

    const sql = `
      INSERT INTO transport_listings (
        user_id,
        vehicle_type,
        service_type,
        title,
        description,
        location,
        plate,
        capacity,
        rate,
        rate_type,
        negotiable,
        phone,
        availability,
        created_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    `;

    await queryDB(sql, [
      userId,
      vehicle_type,
      service_type,
      title,
      description,
      location,
      plate,
      capacity,
      rate,
      rate_type,
      negotiable,
      phone,
      availability
    ]);

    return res.status(200).json({
      message: "Transport listing uploaded successfully."
    });

  } catch (error) {
    console.error("upload_transport error:", error);
    return res.status(500).json({
      message: "Server error. Please try again."
    });
  }
});

module.exports = router;
