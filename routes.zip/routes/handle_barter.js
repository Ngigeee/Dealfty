const express = require("express");
const router = express.Router();
const path = require("path");
const multer = require("multer");
const { queryDB } = require("./utils/dbHelpers");
const { requireAuth } = require("./utils/functions");

// ------------------------------
// Upload config
// ------------------------------
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "public/uploads/barter");
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueName + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

// ------------------------------
// Static data
// ------------------------------
const categories = [
  "Phones",
  "Electronics",
  "Fashion",
  "Furniture",
  "Vehicles",
  "Home",
  "Services",
  "Farm",
  "Books",
  "Beauty",
  "Sports",
  "Other"
];

const catIcons = {
  Phones: "📱",
  Electronics: "💻",
  Fashion: "👕",
  Furniture: "🛋️",
  Vehicles: "🚗",
  Home: "🏠",
  Services: "🛠️",
  Farm: "🌾",
  Books: "📚",
  Beauty: "💄",
  Sports: "⚽",
  Other: "📦"
};

// ------------------------------
// Helpers
// ------------------------------
function timeAgo(dateValue) {
  const date = new Date(dateValue);
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);

  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
  if (seconds < 2592000) return `${Math.floor(seconds / 604800)}w ago`;

  return date.toLocaleDateString("en-KE", {
    year: "numeric",
    month: "short",
    day: "numeric"
  });
}

async function getUnreadNotifCount(userId) {
  if (!userId) return 0;

  try {
    const msgCount = await queryDB(
      "SELECT COUNT(*) AS c FROM messages WHERE receiver_id=? AND is_read=0",
      [userId]
    );

    const notifCount = await queryDB(
      "SELECT COUNT(*) AS c FROM notifications WHERE user_id=? AND is_read=0",
      [userId]
    );

    return Number(msgCount?.[0]?.c || 0) + Number(notifCount?.[0]?.c || 0);
  } catch (_) {
    return 0;
  }
}

function mapOfferRow(row = {}) {
  const createdAt = row.created_at || new Date();
  const ownerName = row.owner_name || row.user_name || "User";
  const isNew = (Date.now() - new Date(createdAt).getTime()) < 86400000;

  return {
    id: Number(row.id || 0),
    user_id: Number(row.user_id || 0),
    owner_name: ownerName,
    owner_initial: String(ownerName).trim().charAt(0).toUpperCase() || "U",
    offer_title: row.offer_title || "",
    offer_description: row.offer_description || "",
    want_title: row.want_title || "",
    want_description: row.want_description || "",
    category: row.category || "",
    category_icon: catIcons[row.category] || "📦",
    location: row.location || "",
    image: row.image || "",
    status: row.status || "active",
    created_at: createdAt,
    updated_at: row.updated_at || null,
    time_ago: timeAgo(createdAt),
    is_new: isNew
  };
}

// ------------------------------
// API: bootstrap
// ------------------------------
router.get("/barter/api/bootstrap", async (req, res) => {
  try {
    const userId = req.session?.user_id || null;
    const loggedIn = !!userId;
    const unreadNotifCount = await getUnreadNotifCount(userId);

    return res.json({
      ok: true,
      logged_in: loggedIn,
      unread_notif_count: unreadNotifCount,
      categories,
      cat_icons: catIcons
    });
  } catch (error) {
    console.error("GET /barter/api/bootstrap error:", error);
    return res.status(500).json({
      ok: false,
      message: "Could not load barter page data."
    });
  }
});

// ------------------------------
// API: list offers
// ------------------------------
router.get("/barter/api/offers", async (req, res) => {
  const q = String(req.query.q || "").trim();
  const cat = String(req.query.cat || "").trim();

  try {
    const where = ["bo.status <> 'deleted'"];
    const params = [];

    if (q) {
      where.push(`(
        bo.offer_title LIKE ?
        OR bo.offer_description LIKE ?
        OR bo.want_title LIKE ?
        OR bo.want_description LIKE ?
        OR bo.location LIKE ?
        OR u.name LIKE ?
      )`);
      const like = `%${q}%`;
      params.push(like, like, like, like, like, like);
    }

    if (cat) {
      where.push("bo.category = ?");
      params.push(cat);
    }

    const sql = `
      SELECT
        bo.id,
        bo.user_id,
        bo.offer_title,
        bo.offer_description,
        bo.want_title,
        bo.want_description,
        bo.category,
        bo.location,
        bo.image,
        bo.status,
        bo.created_at,
        bo.updated_at,
        u.name AS user_name
      FROM barter_offers bo
      LEFT JOIN users u ON bo.user_id = u.id
      WHERE ${where.join(" AND ")}
      ORDER BY bo.id DESC
    `;

    const rows = await queryDB(sql, params);
    const offers = rows.map(mapOfferRow);

    return res.json({
      ok: true,
      offers,
      count: offers.length,
      is_sample: false
    });
  } catch (error) {
    console.error("GET /barter/api/offers error:", error);
    return res.status(500).json({
      ok: false,
      message: "Could not load barter offers."
    });
  }
});

// ------------------------------
// API: create offer
// ------------------------------
router.post(
  "/barter/api/upload",
  requireAuth,
  upload.single("offer_image"),
  async (req, res) => {
    try {
      const userId = req.session.user_id;

      const offerTitle = String(req.body.offer_title || "").trim();
      const offerDesc = String(req.body.offer_desc || "").trim();
      const wantTitle = String(req.body.want_title || "").trim();
      const wantDesc = String(req.body.want_desc || "").trim();
      const category = String(req.body.category || "").trim();
      const location = String(req.body.location || "").trim();
      const image = req.file ? `/uploads/barter/${req.file.filename}` : "";

      if (!offerTitle) {
        return res.status(400).json({
          ok: false,
          message: "Offer title is required."
        });
      }

      if (!wantTitle) {
        return res.status(400).json({
          ok: false,
          message: "What you want is required."
        });
      }

      await queryDB(
        `INSERT INTO barter_offers
        (
          user_id,
          offer_title,
          offer_description,
          want_title,
          want_description,
          category,
          location,
          image,
          status,
          created_at,
          updated_at
        )
        VALUES (?,?,?,?,?,?,?,?, 'active', NOW(), NOW())`,
        [
          userId,
          offerTitle,
          offerDesc,
          wantTitle,
          wantDesc,
          category,
          location,
          image
        ]
      );

      return res.json({
        ok: true,
        message: "Barter offer published successfully."
      });
    } catch (error) {
      console.error("POST /barter/api/offers error:", error);
      return res.status(500).json({
        ok: false,
        message: "Could not publish barter offer."
      });
    }
  }
);

module.exports = router;
