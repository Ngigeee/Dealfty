const express = require("express");
const router = express.Router();

module.exports = (db) => {

  //get the listings of the items
// GET /api/listings
router.get("/api/popular", (req, res) => {
  const userId = req.session.user_id || 0;
  const loggedIn = !!req.session.user_id;

  const sql = `
    SELECT
      l.id, l.title, l.price, l.image, l.images,
      l.location, l.category, l.condition,
      u.name AS seller_name,
      u.account_type,
      bp.business_name,
      bp.is_verified AS biz_verified,
      (SELECT COUNT(*) FROM orders      WHERE listing_id = l.id) AS order_count,
      (SELECT COUNT(*) FROM saved_items WHERE listing_id = l.id) AS save_count,
      (SELECT COUNT(*) FROM messages    WHERE listing_id = l.id) AS msg_count,
      (
        (SELECT COUNT(*) FROM orders      WHERE listing_id = l.id) * 5 +
        (SELECT COUNT(*) FROM saved_items WHERE listing_id = l.id) * 3 +
        (SELECT COUNT(*) FROM messages    WHERE listing_id = l.id) * 2 +
        IF(l.created_at >= NOW() - INTERVAL 14 DAY, 10, 0)
      ) AS trend_score
    FROM listings l
    JOIN users u ON u.id = l.user_id
    LEFT JOIN business_profiles bp
      ON bp.user_id = l.user_id AND bp.status = 'active'
    WHERE l.status = 'active'
      AND l.user_id != ?
    ORDER BY trend_score DESC, l.created_at DESC
    LIMIT 6
  `;

  db.query(sql, [userId], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });

    const items = results.map(item => ({
      id: item.id,
      title: item.title,
      price: item.price,
      category: item.category,
      thumb: item.image,
      seller_name: item.seller_name,
      business_name: item.business_name,
      account_type: item.account_type,
      biz_verified: item.biz_verified,
      order_count: item.order_count, // ✅ use real values now
      save_count: item.save_count,
      location: item.location
    }));

    res.json({ items, loggedIn });
  });
});
//get listing details
router.get("/listing/details", (req, res) => {
  const id = parseInt(req.query.id);
  if (!id) return res.status(400).json({ error: "Missing id" });

  const sql = `
    SELECT 
      l.*, 
      u.name AS seller_name, 
      u.account_type AS seller_type, 
      u.id AS seller_id,
      COALESCE(l.contact_phone, '') AS contact_phone
    FROM listings l 
    JOIN users u ON u.id = l.user_id 
    WHERE l.id = ? 
    LIMIT 1
  `;

  db.query(sql, [id], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!results.length) return res.status(404).json({ error: "Listing not found" });

    const listing = results[0];

    // parse images
    let images = [];
    if (listing.images) {
      try { images = JSON.parse(listing.images); } catch {}
    }
    if (!images.length && listing.image) images = [listing.image];

    const categoryMap = {
      'Electronics':'📱','Clothing':'👕','Food':'🍎','Furniture':'🪑',
      'Vehicles':'🚗','Services':'🔧','Books':'📚','Beauty':'💄',
      'Sports':'⚽','Other':'📦','default':'📦'
    };
    const emoji = categoryMap[listing.category] || categoryMap['default'];

    let attributes = [];
    if (listing.attributes) {
      try { attributes = JSON.parse(listing.attributes); } catch {}
    }

    // determine if current logged-in user is owner
    const isOwner = req.user && req.user.id === listing.user_id;

    res.json({ listing, images, emoji, attributes, isOwner });
  });
});

router.get("/api/all_listings", (req, res) => {
  const userId = req.session.user_id || 0;
  const loggedIn = !!req.session.user_id;

  const sql = `
    SELECT
      l.id, l.title, l.price, l.image, l.images,
      l.location, l.category, l.condition,
      u.name AS seller_name,
      u.account_type,
      bp.business_name,
      bp.is_verified AS biz_verified,
      (SELECT COUNT(*) FROM orders      WHERE listing_id = l.id) AS order_count,
      (SELECT COUNT(*) FROM saved_items WHERE listing_id = l.id) AS save_count,
      (SELECT COUNT(*) FROM messages    WHERE listing_id = l.id) AS msg_count,
      (
        (SELECT COUNT(*) FROM orders      WHERE listing_id = l.id) * 5 +
        (SELECT COUNT(*) FROM saved_items WHERE listing_id = l.id) * 3 +
        (SELECT COUNT(*) FROM messages    WHERE listing_id = l.id) * 2 +
        IF(l.created_at >= NOW() - INTERVAL 14 DAY, 10, 0)
      ) AS trend_score
    FROM listings l
    JOIN users u ON u.id = l.user_id
    LEFT JOIN business_profiles bp
      ON bp.user_id = l.user_id AND bp.status = 'active'
    WHERE l.status = 'active'
      AND l.user_id != ?
    ORDER BY trend_score DESC, l.created_at DESC
    
  `;

  db.query(sql, [userId], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });

    const items = results.map(item => ({
      id: item.id,
      title: item.title,
      price: item.price,
      category: item.category,
      thumb: item.image,
      seller_name: item.seller_name,
      business_name: item.business_name,
      account_type: item.account_type,
      biz_verified: item.biz_verified,
      order_count: item.order_count, // ✅ use real values now
      save_count: item.save_count,
      location: item.location
    }));

    res.json({ items, loggedIn });
  });
});


//products  routes

// Get full listing details (including seller info, images, attributes, contact)
router.get("/api/all_listings", (req, res) => {
  const userId = req.session.user_id || 0;
  const loggedIn = !!req.session.user_id;
  
  // Clean the input: remove whitespace and lowercase it
  const type = (req.query.type || "all").trim().toLowerCase();

  let statusFilter = "";
  const params = [userId];

  // Logic Check: Only apply filter if type is NOT "all"
  if (type === "trending") {
    statusFilter = "AND LOWER(TRIM(l.listing_status)) = 'trending'";
  } else if (type === "featured") {
    statusFilter = "AND LOWER(TRIM(l.listing_status)) = 'featured'";
  } else if (type === "trending_featured") {
    statusFilter = "AND LOWER(TRIM(l.listing_status)) IN ('trending', 'featured')";
  } else if (type !== "all") {
    // Safety Net: if a type like 'xyz' is passed, return nothing instead of everything
    statusFilter = "AND 1=0"; 
  }

  const sql = `
    SELECT
      l.id,
      l.title,
      l.price,
      l.image,
      l.images,
      l.location,
      l.category,
      l.condition,
      l.listing_status,

      u.name AS seller_name,
      u.account_type,

      bp.business_name,
      bp.is_verified AS biz_verified,

      COALESCE(o.order_count, 0) AS order_count,
      COALESCE(s.save_count, 0) AS save_count,
      COALESCE(m.msg_count, 0) AS msg_count,

      (
        COALESCE(o.order_count, 0) * 5 +
        COALESCE(s.save_count, 0) * 3 +
        COALESCE(m.msg_count, 0) * 2 +
        IF(l.created_at >= NOW() - INTERVAL 14 DAY, 10, 0)
      ) AS trend_score

    FROM listings l
    JOIN users u
      ON u.id = l.user_id

    LEFT JOIN (
      SELECT listing_id, COUNT(*) AS order_count
      FROM orders
      GROUP BY listing_id
    ) o ON o.listing_id = l.id

    LEFT JOIN (
      SELECT listing_id, COUNT(*) AS save_count
      FROM saved_items
      GROUP BY listing_id
    ) s ON s.listing_id = l.id

    LEFT JOIN (
      SELECT listing_id, COUNT(*) AS msg_count
      FROM messages
      GROUP BY listing_id
    ) m ON m.listing_id = l.id

    LEFT JOIN (
      SELECT bp1.user_id, bp1.business_name, bp1.is_verified
      FROM business_profiles bp1
      INNER JOIN (
        SELECT user_id, MAX(id) AS max_id
        FROM business_profiles
        WHERE status = 'active'
        GROUP BY user_id
      ) bp2 ON bp2.user_id = bp1.user_id AND bp2.max_id = bp1.id
      WHERE bp1.status = 'active'
    ) bp ON bp.user_id = l.user_id

    WHERE l.status = 'active'
      AND l.user_id != ?
      ${statusFilter}

    ORDER BY trend_score DESC, l.created_at DESC
  `;

  db.query(sql, params, (err, results) => {
    if (err) {
      console.error("Database error:", err);
      return res.status(500).json({ error: "Database error" });
    }

    const items = results.map(item => ({
      id: item.id,
      title: item.title,
      price: item.price,
      category: item.category,
      thumb: item.image,
      seller_name: item.seller_name,
      business_name: item.business_name,
      account_type: item.account_type,
      biz_verified: item.biz_verified,
      order_count: item.order_count,
      save_count: item.save_count,
      location: item.location,
      listing_status: item.listing_status
    }));

    res.json({ items, loggedIn });
  });
});


//fetch images of product clicked
router.get("/listing/images", (req, res) => {
  const id = parseInt(req.query.id);

  if (!id) {
    return res.status(400).json({ error: "Invalid ID" });
  }

  db.query(
    "SELECT images, image, category FROM listings WHERE id=?",
    [id],
    (err, results) => {
      if (err) return res.status(500).json({ error: err });

      if (!results.length) return res.json({ images: [] });

      let images = [];

      // Try JSON images
      if (results[0].images) {
        try {
          const parsed = JSON.parse(results[0].images);
          if (Array.isArray(parsed)) images = parsed;
        } catch {}
      }

      // Fallback single image
      if (!images.length && results[0].image) {
        images = [results[0].image];
      }

      // ✅ Category emoji map
      const catEmoji = {
        Electronics: "📱",
        Clothing: "👕",
        Food: "🍎",
        Furniture: "🪑",
        Vehicles: "🚗",
        Services: "🔧",
        Books: "📚",
        Beauty: "💄",
        Sports: "⚽",
        Other: "📦",
        default: "📦"
      };

      const category = results[0].category || "default";
      const emoji = catEmoji[category] || catEmoji["default"];

      // ✅ Final response
      res.json({
        images,
        emoji
      });
    }
  );
});




router.get("/listing/related", (req, res) => {
  const id = parseInt(req.query.id);

  db.query(
    "SELECT category FROM listings WHERE id=?",
    [id],
    (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      if (!results.length) return res.json([]);

      const category = results[0].category;

      db.query(
        `SELECT id, title, price, images,  category
         FROM listings
         WHERE category=? AND id != ?
         ORDER BY created_at DESC
         LIMIT 4`,
        [category, id],
        (err, rows) => {
          if (err) return res.status(500).json({ error: err.message });

          const catEmojiMap = {
            Electronics: "📱",
            Clothing: "👕",
            Food: "🍎",
            Furniture: "🪑",
            Vehicles: "🚗",
            Services: "🔧",
            Books: "📚",
            Beauty: "💄",
            Sports: "⚽",
            Other: "📦",
            default: "📦"
          };

          const data = rows.map(row => {
            let firstImage = "";
            if (row.images) {
              try {
                const parsed = JSON.parse(row.images);
                if (Array.isArray(parsed) && parsed.length) firstImage = parsed[0];
              } catch {}
            }
            if (!firstImage && row.image) firstImage = row.image;

            return {
              ...row,
              first_image: firstImage,
              emoji: catEmojiMap[row.category] || catEmojiMap.default
            };
          });

          res.json(data);
        }
      );
    }
  );
});

//interested listings
router.get("/listing/interested", (req, res) => {
  const id = parseInt(req.query.id);
  if (!id) return res.status(400).json({ error: "Missing id" });

  db.query(
    "SELECT category, user_id FROM listings WHERE id=?",
    [id],
    (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      if (!results.length) return res.json([]);

      const listing = results[0];
      const category = listing.category;
      const sellerId = listing.user_id;

      db.query(
        `SELECT l.id, l.title, l.price, l.images, l.image, l.category, l.user_id,
                u.name AS seller_name,
                CASE WHEN l.user_id = ? THEN 1 ELSE 0 END AS same_seller
         FROM listings l
         JOIN users u ON u.id = l.user_id
         WHERE l.id != ? AND l.status = 'active'
           AND (l.category = ? OR l.user_id = ?)
         ORDER BY same_seller DESC, l.created_at DESC
         LIMIT 6`,
        [sellerId, id, category, sellerId],
        (err, rows) => {
          if (err) return res.status(500).json({ error: err.message });

          const catEmojiMap = {
            Electronics: "📱",
            Clothing: "👕",
            Food: "🍎",
            Furniture: "🪑",
            Vehicles: "🚗",
            Services: "🔧",
            Books: "📚",
            Beauty: "💄",
            Sports: "⚽",
            Other: "📦",
            default: "📦"
          };

          const data = rows.map(row => {
            let firstImage = "";
            if (row.images) {
              try {
                const parsed = JSON.parse(row.images);
                if (Array.isArray(parsed) && parsed.length) firstImage = parsed[0];
              } catch {}
            }
            if (!firstImage && row.image) firstImage = row.image;

            return {
              ...row,
              first_image: firstImage,
              emoji: catEmojiMap[row.category] || catEmojiMap.default
            };
          });

          res.json(data);
        }
      );
    }
  );
});

  return router;
};
