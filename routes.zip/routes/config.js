const mysql = require("mysql2");
require("dotenv").config();

const db = mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",      // 'user', not 'username'
  password: process.env.DB_PASS || "",      
  database: process.env.DB_NAME || "kimani_store"
});

db.connect((err) => {
  if (err) {
    console.error("Error connecting to database:", err);
  } else {
    console.log("Database connection successful");
  }
});

module.exports = db;
